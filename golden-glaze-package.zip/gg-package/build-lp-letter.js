const fs = require('fs');
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, LevelFormat, PageOrientation,
  BorderStyle, WidthType, ShadingType, HeadingLevel, PageNumber, PageBreak
} = require('docx');

const GOLD = '8B6E10';
const GOLD_DEEP = 'A87618';
const INK = '1A1208';
const TEXT = '4A3825';
const MUTED = '8B6E3D';
const CARD_BG = 'F8EFD7';
const BORDER = 'D4C09B';

const border = { style: BorderStyle.SINGLE, size: 4, color: BORDER };
const borders = { top: border, bottom: border, left: border, right: border };

const P = (text, opts = {}) => new Paragraph({
  spacing: { before: opts.before ?? 120, after: opts.after ?? 120, line: 320 },
  alignment: opts.align,
  children: [new TextRun({ text, size: 22, color: TEXT, font: 'Calibri', ...opts })]
});

const Bold = (text) => new TextRun({ text, bold: true, size: 22, color: INK, font: 'Calibri' });
const Plain = (text) => new TextRun({ text, size: 22, color: TEXT, font: 'Calibri' });
const Italic = (text) => new TextRun({ text, italics: true, size: 22, color: TEXT, font: 'Calibri' });

const Eyebrow = (text) => new Paragraph({
  spacing: { before: 240, after: 100 },
  children: [new TextRun({ text, bold: true, size: 18, color: GOLD_DEEP, font: 'Calibri', allCaps: true, characterSpacing: 50 })]
});

const Mixed = (...runs) => new Paragraph({
  spacing: { before: 120, after: 120, line: 320 },
  children: runs
});

const Bullet = (text) => new Paragraph({
  numbering: { reference: 'bullets', level: 0 },
  spacing: { before: 80, after: 80, line: 300 },
  children: [new TextRun({ text, size: 22, color: TEXT, font: 'Calibri' })]
});

const Cell = (text, opts = {}) => new TableCell({
  borders,
  width: { size: opts.width || 3120, type: WidthType.DXA },
  shading: opts.shade ? { fill: opts.shade, type: ShadingType.CLEAR, color: 'auto' } : undefined,
  margins: { top: 100, bottom: 100, left: 140, right: 140 },
  children: [new Paragraph({
    alignment: opts.align || AlignmentType.LEFT,
    children: [new TextRun({
      text, bold: opts.bold || false, size: opts.size || 20,
      color: opts.color || TEXT, font: opts.mono ? 'Consolas' : 'Calibri',
      italics: opts.italics || false,
    })]
  })]
});

const HCell = (text, width) => Cell(text, { width, bold: true, size: 18, color: INK, shade: CARD_BG });

// ============================================================
// LP UPDATE LETTER — DOCX
// ============================================================

const children = [
  // Letterhead
  new Paragraph({
    spacing: { before: 0, after: 0 },
    children: [new TextRun({ text: 'GOLDEN GLAZE HOLDINGS', bold: true, size: 24, color: GOLD_DEEP, font: 'Calibri', characterSpacing: 60 })]
  }),
  new Paragraph({
    spacing: { before: 0, after: 0 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: GOLD_DEEP, space: 4 } },
    children: [new TextRun({ text: 'Dallas-Fort Worth · A specialty bakery roll-up', italics: true, size: 18, color: MUTED, font: 'Calibri' })]
  }),

  P('', { before: 400 }),

  // Date and recipient
  P('May 2026', { color: MUTED }),
  P(''),
  Mixed(Plain('Dear '), Bold('[LP NAME]'), Plain(',')),

  // Opening
  Mixed(
    Plain('It\'s been eight months since the first wire hit the bank for Arlington. Eight months, seven shops, fourteen partners, and a lot of donuts. We wanted to write to you directly — not through paperwork or a portal — because the next chapter of this business depends on you, and we want you to hear from us first.'),
  ),

  // Section 1: How your shop is doing
  Eyebrow('How your shop is doing'),
  P('First, the numbers. Your investment is in '),
  Mixed(Bold('[SHOP NAME] '), Plain('which we acquired in '), Bold('[ACQUISITION DATE]'), Plain('. At the time, monthly revenue was around '), Bold('[STARTING MRR]'), Plain('. Today, eight months in:')),

  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [3120, 3120, 3120],
    rows: [
      new TableRow({ children: [
        HCell('Metric', 3120), HCell('At acquisition', 3120), HCell('Today', 3120)
      ]}),
      new TableRow({ children: [
        Cell('Monthly revenue (net)', { width: 3120 }),
        Cell('[STARTING MRR]', { width: 3120, mono: true, bold: true }),
        Cell('[CURRENT MRR]', { width: 3120, mono: true, bold: true, color: GOLD_DEEP })
      ]}),
      new TableRow({ children: [
        Cell('Annualized run-rate', { width: 3120 }),
        Cell('[STARTING ARR]', { width: 3120, mono: true, bold: true }),
        Cell('[CURRENT ARR]', { width: 3120, mono: true, bold: true, color: GOLD_DEEP })
      ]}),
      new TableRow({ children: [
        Cell('Conservative valuation', { width: 3120 }),
        Cell('Purchase price', { width: 3120, italics: true, color: MUTED }),
        Cell('[CURRENT VALUATION]', { width: 3120, mono: true, bold: true, color: GOLD_DEEP })
      ]}),
    ]
  }),

  P('The turnaround playbook is working. We bought tired shops, walked in our master bakers, retrained staff, fixed hours, cleaned up the brand, and let demand find us. The numbers above reflect real revenue from real customers — not marketing spend, not subsidized growth.'),

  // Section 2: The bigger picture
  Eyebrow('Where we are as a whole'),
  P('Across the seven shops, we are now at approximately $1.5M in gross annual run-rate. Fourteen of you have invested a combined $380K in cash. We have hired a master baker (Pheak), brought in a strategic FOH operator (Chanda), and are in conversation to hire a 15-year multi-unit operations manager (Jonathan) once we have the capital to make a competitive offer.'),

  P('The fundamentals are working. But we have a structural problem that we need your help to solve.'),

  // Section 3: The structural challenge
  Eyebrow('What we need to do next'),
  P('The seven-LLC structure that got us here cannot get us where we are going. Specifically:'),
  Bullet('A Series A investor will not write checks to seven separate LLCs.'),
  Bullet('A private equity or strategic buyer at exit pays one wire to one entity. Fragmented structures get discounted heavily.'),
  Bullet('The shared infrastructure we need to build — centralized kitchen, brand identity, Golden POS technology — has nowhere to live without a parent entity.'),
  Bullet('Securities compliance across 14 partners in three separate vehicles is impractical and creates audit risk for everyone.'),

  P('The solution is what we are calling the roll-up: consolidating all seven shop LLCs under a single Delaware holding company, Golden Glaze Holdings LLC.'),

  // Section 4: What this means for you
  Eyebrow('What this means for you'),
  P('You are not being asked to invest additional capital. You are not being asked to take on additional risk. You are being asked to consent to exchanging your interest in '),
  Mixed(Bold('[SHOP NAME] '), Plain('LLC for a proportionate interest in Golden Glaze Holdings LLC.')),

  Mixed(Bold('Why this is good for you: ')),
  Bullet('Diversification. Today your investment is concentrated in one shop. After the rollup, you have proportionate exposure to all seven shops plus everything we build on top — centralized kitchen, brand, technology, franchise system.'),
  Bullet('Tax-free contribution. Under §721 of the Internal Revenue Code, the exchange of LLC interests for holding company interests is tax-free. You owe nothing at the rollup itself.'),
  Bullet('Capital floor protection. We are introducing a capital floor as part of the rollup paperwork. At exit, you receive the GREATER of (a) your proportionate equity share in the holding company, OR (b) your original investment back. You cannot lose your principal at any reasonable exit valuation.'),

  P('For the [ARLINGTON LPs ONLY] section: We are honoring the 10% per year preferred return commitment from the original Arlington deal as an extended floor. At a 5-year hold to exit, your floor is $37,500 per $25K invested (simple interest). At any reasonable exit, your equity share will substantially exceed this floor — the floor exists to provide certainty in the unlikely downside scenario.', { italics: true, color: MUTED }),

  Mixed(Bold('Why this is good for the business: ')),
  Bullet('A single holding company is what institutional capital invests in. The rollup unlocks our ability to raise growth capital and build the platform.'),
  Bullet('The shared services — centralized kitchen, brand, technology — start generating value across every shop simultaneously.'),
  Bullet('At exit, a clean cap table is worth 20-30% more than a fragmented one. That premium accrues to you proportionally.'),

  // Section 5: The path forward
  Eyebrow('The path forward'),
  P('Over the next six to twelve months, we will work with corporate counsel and tax advisors to execute the rollup carefully and correctly. Each shop comes in as lender consents, landlord consents, and your signatures clear individually. There is no all-or-nothing deadline that pressures anyone.'),

  P('We are also raising approximately $1M in SAFE capital from a small group of new outside investors — including one anchor of approximately $500K — to fund the legal work, hire the operations manager, and build the centralized kitchen. This capital comes in fresh; it does not displace any of you.'),

  P('Within twelve months of the SAFE close, we plan to raise a Series A of approximately $1M at $4M pre-money. This is the institutional round that puts the platform on real growth footing. By Year 4, we are modeling a $80-120M exit window to a private equity firm or strategic acquirer.'),

  // Section 6: What we are asking for
  Eyebrow('What we are asking for, in order'),

  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [1872, 7488],
    rows: [
      new TableRow({ children: [HCell('Ask', 1872), HCell('What it involves', 7488)]}),
      new TableRow({ children: [
        Cell('Now', { width: 1872, bold: true, mono: true, color: GOLD_DEEP }),
        Cell('A 30-minute conversation, in person or by phone. We want to walk you through this letter, answer your questions, and hear your concerns directly. No paperwork at this stage.', { width: 7488 })
      ]}),
      new TableRow({ children: [
        Cell('Next 2 weeks', { width: 1872, bold: true, mono: true, color: GOLD_DEEP }),
        Cell('An accreditation questionnaire from our securities counsel. This is a regulatory requirement under Reg D 506(b) — the rules that govern private securities like yours. The questionnaire is short. Returning it costs nothing and protects all of us at later capital events.', { width: 7488 })
      ]}),
      new TableRow({ children: [
        Cell('Next 60-90 days', { width: 1872, bold: true, mono: true, color: GOLD_DEEP }),
        Cell('The formal consent paperwork to exchange your LLC interest for holding company interest. Reviewed by your own counsel if you would like, at your discretion. We will pay for a session with our corporate counsel to walk you through it if that is helpful.', { width: 7488 })
      ]}),
    ]
  }),

  // Section 7: Closing
  Eyebrow('A closing thought'),
  P('When we asked you for $25K or $30K eight months ago, we made a promise: we would build something real, treat your money with care, and tell you the truth about how it was going. We have tried our best to live up to that promise.'),

  P('This rollup is not a pivot or a reset. It is the next logical step. The structure has to evolve because the business is succeeding. We would not be writing this letter if the seven shops were not working — we would be returning your capital.'),

  P('We are still in the early innings. The next four years are the real test. But the foundation is solid, the team is strong, and the path to a meaningful exit for everyone — including you — is more visible today than it was eight months ago.'),

  P('Thank you for trusting us with your capital. We do not take it for granted.'),

  P('', { before: 240 }),
  P('Warmly,'),
  P(''),
  Mixed(Bold('Youyou')),
  P('Co-founder & COO, Golden Glaze Holdings', { color: MUTED, italics: true }),
  P('', { before: 120 }),
  Mixed(Bold('Jack Wong')),
  P('Founder & CEO, Golden Glaze Holdings', { color: MUTED, italics: true }),

  // Section 8: Footnote
  new Paragraph({ children: [new PageBreak()] }),

  Eyebrow('Appendix · Frequently asked questions'),

  Mixed(Bold('Will I owe taxes on the rollup itself?')),
  P('No. The exchange is structured under §721 of the Internal Revenue Code as a tax-free contribution. You exchange one partnership interest for another. No realization event for tax purposes.'),

  Mixed(Bold('What if I do not want to participate?')),
  P('We will work with you. Our preference is unanimous consent because it produces the cleanest cap table and the simplest paperwork. If you ultimately decline, we will explore alternatives — including a buyout of your interest at the conservative valuation, paid from SAFE or Series A proceeds. We are not pressuring anyone into anything.'),

  Mixed(Bold('Who decides what the holding company does?')),
  P('Strategic decisions and major transactions are made by the founder team (Jack, Youyou, Peiyun, Max) with input from the operating partner (Muypin) and strategic advisors (Luke, Chanda, Jonathan, Lam). LPs are passive partners — you do not have day-to-day decision rights, but you retain pro-rata equity exposure and standard minority protections in the operating agreement.'),

  Mixed(Bold('How do I know the valuations are fair?')),
  P('We deliberately set the shop-level valuations conservatively — at approximately 0.85-0.92× annual revenue. The industry median for donut shops on BizBuySell is 0.50× revenue. Our valuations sit slightly above median because of demonstrated turnaround performance, but well below where institutional buyers will eventually price us. Conservative valuations protect everyone in this room and create upside for the next round of capital.'),

  Mixed(Bold('When do I get my money back?')),
  P('Distributions happen at exit. Our target is Year 4 (approximately mid-2030). The exit window is $80-120M for a private equity or strategic acquirer. At those valuations, your equity share materially exceeds the capital floor. At the floor itself, you receive your original investment back (plus pref for Arlington LPs). Either way, you are protected.'),

  Mixed(Bold('What is the worst-case scenario?')),
  P('We owe you honesty here. The worst case is that the platform stalls — we cannot raise Series A, we cannot find a buyer, growth flattens. In that case, the holding company continues to operate the seven shops, distributing profits to partners over time. You would receive distributions from operations rather than an exit. The shops generate cash; they do not zero out. You would not lose your principal at any reasonable scenario.'),

  Mixed(Bold('Can I talk to your counsel?')),
  P('Yes. Once the formal consent paperwork is drafted, we will offer every LP a session with our corporate counsel to walk through the documents. You should also feel free to engage your own counsel — we will pay reasonable costs for a single review if you would like one.'),

  Mixed(Bold('What should I do right now?')),
  P('Reply to this letter (or call us). Schedule the 30-minute conversation. Mark anything in this letter that you want to discuss. Ask anything that worries you. We would rather address concerns now than at the paperwork stage.'),

  P('', { before: 400 }),
  P('This letter is confidential and intended for the named recipient only. It is not an offer of securities and does not constitute legal, tax, or financial advice. Please consult your own advisors regarding the matters described.', { italics: true, size: 18, color: MUTED, align: AlignmentType.CENTER }),
];

const doc = new Document({
  styles: {
    default: { document: { run: { font: 'Calibri', size: 22 } } }
  },
  numbering: {
    config: [
      { reference: 'bullets',
        levels: [{ level: 0, format: LevelFormat.BULLET, text: '•', alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
    ]
  },
  sections: [{
    properties: {
      page: {
        size: { width: 12240, height: 15840 },
        margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 }
      }
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          alignment: AlignmentType.RIGHT,
          children: [new TextRun({ text: 'GOLDEN GLAZE HOLDINGS · CONFIDENTIAL', size: 16, color: MUTED, font: 'Calibri', characterSpacing: 40 })]
        })]
      })
    },
    footers: {
      default: new Footer({
        children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({ text: 'Page ', size: 16, color: MUTED, font: 'Calibri' }),
            new TextRun({ children: [PageNumber.CURRENT], size: 16, color: MUTED, font: 'Calibri' }),
            new TextRun({ text: ' of ', size: 16, color: MUTED, font: 'Calibri' }),
            new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 16, color: MUTED, font: 'Calibri' }),
          ]
        })]
      })
    },
    children
  }]
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync('/home/claude/gg-package/docs/04-LP-Update-Letter.docx', buffer);
  console.log('✓ LP update letter built');
});
