// Golden Glaze Investor Pitch Deck
// Single deck designed for both small ($30K) and anchor ($500K) SAFE investors
// Speaker notes differentiate the talk track per audience

const PptxGenJS = require('pptxgenjs');
const pres = new PptxGenJS();

// Deck setup
pres.layout = 'LAYOUT_WIDE'; // 13.333 x 7.5 inches
pres.author = 'Golden Glaze Holdings';
pres.company = 'Golden Glaze Holdings LLC';
pres.title = 'Golden Glaze — Strategic Investment Deck';

// Brand palette
const C = {
  ink: '1A1208',
  text: '4A3825',
  muted: '8B6E3D',
  cream: 'FAF6EA',
  card: 'F8EFD7',
  gold: 'D99C2B',
  goldDeep: 'A87618',
  goldSoft: 'F5E2B8',
  white: 'FFFFFF',
  accent: 'B85042',
};

const FONT_DISPLAY = 'Georgia';   // headlines
const FONT_BODY = 'Calibri';      // body
const FONT_MONO = 'Consolas';     // numbers

// ============================================================
// SLIDE 1 — COVER (dark, dramatic)
// ============================================================
const s1 = pres.addSlide();
s1.background = { color: C.ink };

// Top eyebrow
s1.addText('STRATEGIC INVESTMENT MEMORANDUM · MAY 2026', {
  x: 0.6, y: 0.5, w: 12.1, h: 0.4,
  fontFace: FONT_BODY, fontSize: 11, color: C.gold, bold: true, charSpacing: 4,
});

// Brand mark
s1.addText('Golden Glaze', {
  x: 0.6, y: 2.5, w: 12.1, h: 1.6,
  fontFace: FONT_DISPLAY, fontSize: 88, color: C.cream, bold: true, italic: true,
});

s1.addText('A 7-shop specialty bakery roll-up. The platform to a $80-120M exit.', {
  x: 0.6, y: 4.3, w: 12.1, h: 0.8,
  fontFace: FONT_BODY, fontSize: 22, color: C.goldSoft, italic: true,
});

// Footer info
s1.addText('Confidential · Prepared for investor review · Do not distribute', {
  x: 0.6, y: 6.7, w: 12.1, h: 0.3,
  fontFace: FONT_BODY, fontSize: 10, color: C.muted, charSpacing: 2,
});

s1.addNotes(`OPENER: Welcome the investor by name. Set context.

For SMALL SAFE ($30K participants):
"Thanks for the time. I'm going to walk you through how we got from zero to 7 shops in 8 months, where we're going, and how the $30K SAFE fits in. Should take 25-30 minutes — I want plenty of time for your questions at the end."

For ANCHOR SAFE ($500K investor):
"Thanks for the time. This is going to be a 45-60 minute conversation. I'll walk through the architecture, the team, the math, and the comps — and then I want to dig into your specific concerns. The $500K anchor is the most important wire in this round, and the relationship matters more than the dollars."

Both audiences: ground them quickly. We are a real operating business, not a deck.`);

// ============================================================
// SLIDE 2 — THE BUSINESS IN ONE PARAGRAPH
// ============================================================
const s2 = pres.addSlide();
s2.background = { color: C.cream };

s2.addText('Golden Glaze in one paragraph', {
  x: 0.6, y: 0.6, w: 12.1, h: 0.6,
  fontFace: FONT_DISPLAY, fontSize: 32, color: C.ink, bold: true,
});

s2.addText([
  { text: 'We acquired ', options: { fontFace: FONT_BODY, fontSize: 24, color: C.text } },
  { text: '7 underperforming donut shops across Dallas-Fort Worth in 8 months', options: { fontFace: FONT_BODY, fontSize: 24, color: C.ink, bold: true } },
  { text: ', stabilized them through operational turnaround, and are now executing the roll-up to consolidate into ', options: { fontFace: FONT_BODY, fontSize: 24, color: C.text } },
  { text: 'a single platform under one brand', options: { fontFace: FONT_BODY, fontSize: 24, color: C.ink, bold: true } },
  { text: '. Current run-rate: ', options: { fontFace: FONT_BODY, fontSize: 24, color: C.text } },
  { text: '~$1.5M gross ARR', options: { fontFace: FONT_BODY, fontSize: 24, color: C.goldDeep, bold: true } },
  { text: '. Target exit: ', options: { fontFace: FONT_BODY, fontSize: 24, color: C.text } },
  { text: '$80-120M in 4 years', options: { fontFace: FONT_BODY, fontSize: 24, color: C.goldDeep, bold: true } },
  { text: ' via PE or strategic acquisition.', options: { fontFace: FONT_BODY, fontSize: 24, color: C.text } },
], {
  x: 0.6, y: 1.8, w: 12.1, h: 3.0,
  valign: 'top', lineSpacingMultiple: 1.4,
});

// Three pillar callouts
const pillars = [
  { y: 5.2, label: 'WHAT', value: '7 shops, $1.5M ARR', sub: 'DFW · founder-led roll-up' },
  { y: 5.2, label: 'WHEN', value: '4 yrs to exit', sub: 'PE / strategic at $80-120M' },
  { y: 5.2, label: 'WHY NOW', value: '$300K SAFE', sub: '$2M cap · 20% discount · MFN' },
];

pillars.forEach((p, i) => {
  const x = 0.6 + i * 4.1;
  s2.addShape('rect', {
    x, y: p.y, w: 3.9, h: 1.6,
    fill: { color: C.card },
    line: { color: C.gold, width: 1 },
  });
  s2.addText(p.label, {
    x: x + 0.3, y: p.y + 0.2, w: 3.5, h: 0.3,
    fontFace: FONT_BODY, fontSize: 10, color: C.goldDeep, bold: true, charSpacing: 3,
  });
  s2.addText(p.value, {
    x: x + 0.3, y: p.y + 0.55, w: 3.5, h: 0.6,
    fontFace: FONT_DISPLAY, fontSize: 22, color: C.ink, bold: true,
  });
  s2.addText(p.sub, {
    x: x + 0.3, y: p.y + 1.15, w: 3.5, h: 0.3,
    fontFace: FONT_BODY, fontSize: 12, color: C.muted, italic: true,
  });
});

s2.addNotes(`Hit the three callouts in order. Don't elaborate yet — these are the headlines, we'll unpack each.

For both audiences: After this slide, they should know exactly what we do, what stage we're at, and what we're asking for. If anything is unclear, pause and address it before moving on.`);

// ============================================================
// SLIDE 3 — THE PORTFOLIO TODAY
// ============================================================
const s3 = pres.addSlide();
s3.background = { color: C.white };

s3.addText('Where we are today', {
  x: 0.6, y: 0.5, w: 12.1, h: 0.5,
  fontFace: FONT_DISPLAY, fontSize: 32, color: C.ink, bold: true,
});

s3.addText('Seven shops, four founder-funded, three LP-funded. Eight months of acquisitions, all turned around.', {
  x: 0.6, y: 1.1, w: 12.1, h: 0.4,
  fontFace: FONT_BODY, fontSize: 14, color: C.muted, italic: true,
});

// Top stats row
const tStats = [
  { label: 'STORES', val: '7', sub: 'in 8 months' },
  { label: 'GROSS ARR', val: '~$1.5M', sub: '$126K/mo · pre-merchant-fees' },
  { label: 'AGGREGATE VALUE', val: '$1.20M', sub: 'conservative @ 0.9× rev' },
  { label: 'ACTIVE LPs', val: '14', sub: '$380K cash deployed' },
];
tStats.forEach((s, i) => {
  const x = 0.6 + i * 3.05;
  s3.addText(s.label, {
    x, y: 1.7, w: 2.85, h: 0.3,
    fontFace: FONT_BODY, fontSize: 10, color: C.muted, bold: true, charSpacing: 3,
  });
  s3.addText(s.val, {
    x, y: 2.0, w: 2.85, h: 0.7,
    fontFace: FONT_DISPLAY, fontSize: 38, color: C.goldDeep, bold: true,
  });
  s3.addText(s.sub, {
    x, y: 2.8, w: 2.85, h: 0.3,
    fontFace: FONT_BODY, fontSize: 11, color: C.text,
  });
});

// Shop table
s3.addTable([
  [
    { text: 'Shop', options: { bold: true, color: C.white, fill: { color: C.ink }, fontSize: 12, fontFace: FONT_BODY } },
    { text: 'Acquired', options: { bold: true, color: C.white, fill: { color: C.ink }, fontSize: 12, fontFace: FONT_BODY } },
    { text: 'MRR start', options: { bold: true, color: C.white, fill: { color: C.ink }, fontSize: 12, fontFace: FONT_BODY, align: 'right' } },
    { text: 'MRR now', options: { bold: true, color: C.white, fill: { color: C.ink }, fontSize: 12, fontFace: FONT_BODY, align: 'right' } },
    { text: 'Funding', options: { bold: true, color: C.white, fill: { color: C.ink }, fontSize: 12, fontFace: FONT_BODY } },
    { text: 'Valuation', options: { bold: true, color: C.white, fill: { color: C.ink }, fontSize: 12, fontFace: FONT_BODY, align: 'right' } },
  ],
  ['Arlington', 'Sep 2025', '$18K', '$30K', '8 LPs × $25K', '$330K'],
  ['NRH (Rufe Snow)', 'Sep 2025', '$3K', '$11K', 'joint w/ Arl', '$110K'],
  ['Fort Worth', 'Oct 2025', '$17K', '$22.5K', '4 LPs × $30K', '$230K'],
  ['Grapevine', 'Nov 2025', '$12K', '$18K', '2 of 4 LPs', '$190K'],
  ['Carrollton', 'Feb 2026', '—', '$10K', 'founder-funded', '$140K'],
  ['Dallas (Frankford)', 'Feb 2026', '—', '$10K', 'founder-funded', '$120K'],
  ['Bluemound', 'Apr 2026', '$0', '$8K', 'founder-funded', '$80K'],
].map((row, i) => {
  if (i === 0) return row;
  return row.map((cell, j) => ({
    text: String(cell),
    options: {
      fontSize: 11, fontFace: FONT_BODY,
      color: j === 5 ? C.goldDeep : C.text,
      bold: j === 0 || j === 5,
      align: (j === 2 || j === 3 || j === 5) ? 'right' : 'left',
      fill: { color: i % 2 ? C.cream : C.white },
    }
  }));
}), {
  x: 0.6, y: 3.5, w: 12.1, h: 3.5,
  colW: [2.1, 1.5, 1.5, 1.5, 2.6, 1.5, 1.4],
  fontSize: 11,
  border: { type: 'solid', color: C.card, pt: 0.5 },
});

s3.addNotes(`Walk through the table. Key talking points:

1. "Acquired" column tells the velocity story. 8 months, 7 shops. That's institutional-grade dealflow execution.

2. "MRR start" vs "MRR now" tells the turnaround story. Arlington went from $18K to $30K (+67%). NRH from $3K to $11K (+267%). This is where the value creation lives.

3. "Funding" mix shows risk management. We don't depend on any single LP cohort. Three different shop structures, all working.

4. "Valuation" column is conservative — 0.83-0.92× revenue. BizBuySell median is 0.50× for donut shops. We're slightly above median because of demonstrated turnaround.

For SMALL SAFE: focus on the growth story. The numbers tell themselves.
For ANCHOR SAFE: emphasize the conservative valuations — leaves them upside. Mention Grapevine has 2 LPs open ($60K) — we could absorb their participation here at SAFE-cap terms instead.`);

// ============================================================
// SLIDE 4 — THE TURNAROUND PLAYBOOK
// ============================================================
const s4 = pres.addSlide();
s4.background = { color: C.cream };

s4.addText('The turnaround playbook', {
  x: 0.6, y: 0.5, w: 12.1, h: 0.5,
  fontFace: FONT_DISPLAY, fontSize: 32, color: C.ink, bold: true,
});

s4.addText('How we lift a tired donut shop from $3K MRR to $11K MRR in 90 days.', {
  x: 0.6, y: 1.05, w: 12.1, h: 0.4,
  fontFace: FONT_BODY, fontSize: 14, color: C.muted, italic: true,
});

const playbook = [
  { num: '01', title: 'Acquire under-performing', body: 'Tired ownership, deferred maintenance, broken recipes. We target shops at 0.4-0.8× revenue — below market median.' },
  { num: '02', title: 'Recipe & quality reset', body: 'Master baker walks in, retrains staff, locks in consistent product. Customer feedback turns within 2 weeks.' },
  { num: '03', title: 'Operations cleanup', body: 'Hours optimization, staff scheduling, POS upgrade, supplier consolidation. Margin recovery without revenue lift.' },
  { num: '04', title: 'Brand + customer pull', body: 'Light branding refresh, signage, social presence. Modest marketing spend amplifies the operational fixes.' },
  { num: '05', title: 'Stabilize + repeat', body: 'Once shop is steady at the new run-rate, redirect operator attention to next acquisition. The playbook compounds.' },
];

playbook.forEach((p, i) => {
  const y = 1.8 + i * 1.0;
  // Number in circle
  s4.addShape('ellipse', {
    x: 0.6, y, w: 0.8, h: 0.8,
    fill: { color: C.gold },
    line: { color: C.gold, width: 0 },
  });
  s4.addText(p.num, {
    x: 0.6, y: y + 0.15, w: 0.8, h: 0.5,
    fontFace: FONT_MONO, fontSize: 18, color: C.ink, bold: true, align: 'center',
  });
  // Content
  s4.addText(p.title, {
    x: 1.7, y: y + 0.05, w: 11.0, h: 0.4,
    fontFace: FONT_DISPLAY, fontSize: 18, color: C.ink, bold: true,
  });
  s4.addText(p.body, {
    x: 1.7, y: y + 0.4, w: 11.0, h: 0.5,
    fontFace: FONT_BODY, fontSize: 13, color: C.text,
  });
});

s4.addNotes(`This is the heart of the value creation story. The playbook is repeatable. Each new acquisition follows the same 5-step pattern.

Key message: "We are not buying donut shops. We are buying distressed businesses with a proven turnaround mechanism. The unit economics work because we acquire below market and lift performance by 50-200%."

For both audiences: ask if they want to see specific before/after numbers for any shop. NRH ($3K → $11K) is the most dramatic example.`);

// ============================================================
// SLIDE 5 — THE TEAM
// ============================================================
const s5 = pres.addSlide();
s5.background = { color: C.white };

s5.addText('The team behind the playbook', {
  x: 0.6, y: 0.5, w: 12.1, h: 0.5,
  fontFace: FONT_DISPLAY, fontSize: 32, color: C.ink, bold: true,
});

s5.addText('Three things most QSR roll-ups have one of. We have all three.', {
  x: 0.6, y: 1.05, w: 12.1, h: 0.4,
  fontFace: FONT_BODY, fontSize: 14, color: C.muted, italic: true,
});

const threeThings = [
  { num: '01', pillar: 'Institutional pedigree', detail: 'Jack — VP, Asset & Wealth Management at Goldman Sachs.\nUU — SVP, Data Analytics at top-tier consulting firm.\nNot career restaurant operators trying to find capital.\nCapital and data operators choosing to run restaurants.' },
  { num: '02', pillar: 'Real engineering capability', detail: 'Peiyun — co-founder, working software engineer.\nBuilding Golden POS in parallel with operations.\nCustomer loyalty, demand forecasting, data infrastructure.\nMost QSR roll-ups outsource this and pay vendors forever.' },
  { num: '03', pillar: 'Donut industry expertise', detail: 'Muypin — existing shop owner, full-time on ops.\nPheak — master baker, 10+ years.\nChanda — master FOH operator with her own shop.\nJonathan — 15+ yrs multi-unit production floor leadership.' },
];

threeThings.forEach((t, i) => {
  const x = 0.6 + i * 4.1;
  const y = 1.7;
  s5.addShape('rect', {
    x, y, w: 3.9, h: 5.1,
    fill: { color: C.cream },
    line: { color: C.card, width: 1 },
  });
  s5.addText(t.num, {
    x: x + 0.3, y: y + 0.3, w: 3.5, h: 0.4,
    fontFace: FONT_MONO, fontSize: 12, color: C.goldDeep, bold: true,
  });
  s5.addText(t.pillar, {
    x: x + 0.3, y: y + 0.7, w: 3.5, h: 0.9,
    fontFace: FONT_DISPLAY, fontSize: 18, color: C.ink, bold: true,
  });
  s5.addText(t.detail, {
    x: x + 0.3, y: y + 1.8, w: 3.5, h: 3.0,
    fontFace: FONT_BODY, fontSize: 12, color: C.text, lineSpacingMultiple: 1.5,
  });
});

s5.addNotes(`This slide is where you sell THE TEAM. Make sure every founder is namable and credible.

Key narrative: "Most QSR roll-ups are MBAs trying to operate businesses they don't fundamentally understand. We're operators who happened to have institutional and engineering backgrounds. That's the difference."

For ANCHOR SAFE: emphasize Jonathan as the institutional-grade ops hire. PE diligence will ask "who runs operations as you scale to 30+ shops?" — Jonathan is the credible answer.

For BOTH: if asked about Youyou's current consulting job, the answer is "going full-time at HoldCo formation, plan in place."`);

// ============================================================
// SLIDE 6 — VISION: THE PLATFORM
// ============================================================
const s6 = pres.addSlide();
s6.background = { color: C.cream };

s6.addText('The platform thesis', {
  x: 0.6, y: 0.5, w: 12.1, h: 0.5,
  fontFace: FONT_DISPLAY, fontSize: 32, color: C.ink, bold: true,
});

s6.addText('Four revenue pillars stacked on the same operational footprint. Each at a different exit multiple.', {
  x: 0.6, y: 1.05, w: 12.1, h: 0.4,
  fontFace: FONT_BODY, fontSize: 14, color: C.muted, italic: true,
});

const pillars2 = [
  { num: '01', title: 'Owned + Franchised Stores', mult: '6-10× EBITDA', body: '15-20 owned flagships + 30-50 franchisees by Year 4. Royalty income at 80%+ margin. Franchisee capital funds growth.' },
  { num: '02', title: 'Centralized Kitchen + B2B', mult: '6-8× EBITDA', body: 'Mandatory supply for all stores + wholesale to local coffee shops, hotels, schools, corporate accounts.' },
  { num: '03', title: 'Specialty Supply / Mix IP', mult: '8-12× EBITDA', body: 'Year 5+ business. Proprietary mixes licensed to other bakeries. Adjacent to Dawn Foods, not competing.' },
  { num: '04', title: 'Tech Platform · Golden POS', mult: '5-8× ARR', body: 'Internal POS + demand forecasting + customer data. Eventually licensed externally to other QSR operators.' },
];

pillars2.forEach((p, i) => {
  const x = 0.6 + (i % 2) * 6.1;
  const y = 1.7 + Math.floor(i / 2) * 2.7;
  s6.addShape('rect', {
    x, y, w: 5.9, h: 2.5,
    fill: { color: C.white },
    line: { color: C.gold, width: 1 },
  });
  s6.addText(p.num, {
    x: x + 0.35, y: y + 0.25, w: 1.5, h: 0.3,
    fontFace: FONT_MONO, fontSize: 11, color: C.goldDeep, bold: true,
  });
  s6.addText(p.mult, {
    x: x + 4.0, y: y + 0.25, w: 1.7, h: 0.3,
    fontFace: FONT_MONO, fontSize: 11, color: C.goldDeep, bold: true, align: 'right',
  });
  s6.addText(p.title, {
    x: x + 0.35, y: y + 0.65, w: 5.2, h: 0.5,
    fontFace: FONT_DISPLAY, fontSize: 20, color: C.ink, bold: true,
  });
  s6.addText(p.body, {
    x: x + 0.35, y: y + 1.2, w: 5.2, h: 1.2,
    fontFace: FONT_BODY, fontSize: 12, color: C.text, lineSpacingMultiple: 1.4,
  });
});

s6.addNotes(`The platform thesis is what makes this a $80-120M exit candidate instead of a $10M strategic acquisition.

Walk through each pillar:
- Pillar 1 is the foundation. The owned stores generate the brand and the recipe IP.
- Pillar 2 is the multiplier. Once we have 15+ stores, the kitchen has volume to sell wholesale and dramatically improves margins.
- Pillar 3 is the ambition. Mix IP is a high-multiple asset adjacent to Dawn Foods.
- Pillar 4 is the wedge. Tech platform makes us defensible AND becomes its own revenue line.

For ANCHOR SAFE: this is where to spend time. They want to see that we have a vision beyond "more donut shops." The 4-pillar structure is the answer.

For SMALL SAFE: lighter touch on this slide. They mostly care about pillar 1.`);

// ============================================================
// SLIDE 7 — TARGET EXIT
// ============================================================
const s7 = pres.addSlide();
s7.background = { color: C.ink };

s7.addText('The path to exit', {
  x: 0.6, y: 0.5, w: 12.1, h: 0.5,
  fontFace: FONT_DISPLAY, fontSize: 32, color: C.cream, bold: true,
});

s7.addText('Two exit windows modeled. Year 4 = PE / strategic. Year 7 = full Shipley scale.', {
  x: 0.6, y: 1.05, w: 12.1, h: 0.4,
  fontFace: FONT_BODY, fontSize: 14, color: C.goldSoft, italic: true,
});

// Two big windows side by side
const exitData = [
  { label: 'YEAR 4 EXIT WINDOW', value: '$80-120M', sub: 'PE or strategic acquisition', detail: '25-35 shops · $10-15M ARR · 6-10× multiple · Reach Krispy Kreme JAB-era trajectory or Dave\'s Hot Chicken Roark pace.' },
  { label: 'YEAR 7 SHIPLEY SCALE', value: '$200-400M', sub: 'Franchise platform + supply', detail: '100+ stores or meaningful wholesale. Shipley Do-Nuts sold to Levine Leichtman at this scale July 2025.' },
];

exitData.forEach((e, i) => {
  const x = 0.6 + i * 6.1;
  s7.addShape('rect', {
    x, y: 1.8, w: 5.9, h: 4.5,
    fill: { color: C.text },
    line: { color: C.gold, width: 1 },
  });
  s7.addText(e.label, {
    x: x + 0.4, y: 2.0, w: 5.1, h: 0.3,
    fontFace: FONT_BODY, fontSize: 11, color: C.gold, bold: true, charSpacing: 3,
  });
  s7.addText(e.value, {
    x: x + 0.4, y: 2.5, w: 5.1, h: 1.4,
    fontFace: FONT_DISPLAY, fontSize: 56, color: C.cream, bold: true,
  });
  s7.addText(e.sub, {
    x: x + 0.4, y: 4.1, w: 5.1, h: 0.5,
    fontFace: FONT_DISPLAY, fontSize: 18, color: C.goldSoft, italic: true,
  });
  s7.addText(e.detail, {
    x: x + 0.4, y: 4.8, w: 5.1, h: 1.4,
    fontFace: FONT_BODY, fontSize: 13, color: 'D4C09B', lineSpacingMultiple: 1.5,
  });
});

s7.addText('These are not unicorn fantasies. Every comp listed reached these valuations on real revenue, not pre-revenue hype.', {
  x: 0.6, y: 6.5, w: 12.1, h: 0.5,
  fontFace: FONT_BODY, fontSize: 13, color: C.goldSoft, italic: true, align: 'center',
});

s7.addNotes(`Spend real time here. This is what they're investing in.

For ANCHOR SAFE: this is the show-stopper slide. Be specific:
- "At $80M exit on $300K SAFE → ~$770K back to you. 2.5× MOIC on a 4-year hold."
- "If we hit $120M, you get $1.1M+. 3.7× MOIC."
- "And the math gets considerably better at Year 7 — but base case at Year 4 already returns the fund."

For SMALL SAFE: simpler version:
- "At $80M exit on $30K SAFE → ~$77K back. 2.5× on a 4-year hold."
- "Same math, smaller scale."

Common pushback: "Why should I believe $80-120M?" Answer: comp slide is next.`);

// ============================================================
// SLIDE 8 — COMPARABLE VALUATIONS
// ============================================================
const s8 = pres.addSlide();
s8.background = { color: C.white };

s8.addText('The real comparables', {
  x: 0.6, y: 0.5, w: 12.1, h: 0.5,
  fontFace: FONT_DISPLAY, fontSize: 32, color: C.ink, bold: true,
});

s8.addText('Six exits and IPOs over 4 years. None were pre-revenue unicorns. Every one built revenue first.', {
  x: 0.6, y: 1.05, w: 12.1, h: 0.4,
  fontFace: FONT_BODY, fontSize: 14, color: C.muted, italic: true,
});

// Comps in a 2x3 grid
const comps = [
  { name: 'Shipley Do-Nuts', cat: 'DIRECT MODEL', stats: 'Houston · ~380 stores · 2× value in 4-yr PE hold', note: 'Peak Rock 2021 → Levine Leichtman 2025' },
  { name: 'Mochinut', cat: 'CULTURAL MATCH', stats: '148+ units · 2017-20 founded · $400K-$1M AUV', note: 'Mochi donuts + boba · Asian-American positioning' },
  { name: "Dave's Hot Chicken", cat: 'PACE BENCHMARK', stats: '$22M (2020) → $617M (2024) → $1B exit', note: 'Roark Capital June 2025 · 8× revenue multiple' },
  { name: 'Krispy Kreme', cat: 'DIRECT CATEGORY', stats: '$1.35B (JAB 2016) → $3.8B IPO (2021)', note: 'Hub-and-spoke supply model · 5-yr PE hold' },
  { name: 'Cava', cat: 'PUBLIC MULTIPLE', stats: '$2.4B IPO on $700M rev · 3.5× revenue', note: 'The sustainable post-bubble fast-casual comp' },
  { name: 'Sweetgreen', cat: 'CAUTIONARY TALE', stats: '$3B IPO (2021) → $1.08B today · -66%', note: 'We model on sane multiples, not 2021 peaks' },
];

comps.forEach((c, i) => {
  const x = 0.6 + (i % 3) * 4.1;
  const y = 1.7 + Math.floor(i / 3) * 2.6;
  s8.addShape('rect', {
    x, y, w: 3.9, h: 2.4,
    fill: { color: C.cream },
    line: { color: C.card, width: 1 },
  });
  s8.addText(c.cat, {
    x: x + 0.3, y: y + 0.25, w: 3.5, h: 0.3,
    fontFace: FONT_BODY, fontSize: 9.5, color: C.goldDeep, bold: true, charSpacing: 3,
  });
  s8.addText(c.name, {
    x: x + 0.3, y: y + 0.6, w: 3.5, h: 0.5,
    fontFace: FONT_DISPLAY, fontSize: 18, color: C.ink, bold: true,
  });
  s8.addText(c.stats, {
    x: x + 0.3, y: y + 1.2, w: 3.5, h: 0.7,
    fontFace: FONT_BODY, fontSize: 11, color: C.text, lineSpacingMultiple: 1.4,
  });
  s8.addText(c.note, {
    x: x + 0.3, y: y + 1.85, w: 3.5, h: 0.4,
    fontFace: FONT_BODY, fontSize: 10, color: C.muted, italic: true, lineSpacingMultiple: 1.3,
  });
});

s8.addNotes(`If they ask "why should I believe this?" — this slide is the answer.

Walk through each comp briefly:
- Shipley: same model, same kind of exit, just 4 years ahead of us
- Mochinut: same identity, same product approach, proves the category works
- Dave's: same starting point (literally parking lot, $22M revenue), reached $1B in 5 years
- Krispy Kreme: same supply-chain thesis (DFD = our centralized kitchen)
- Cava: shows the sustainable multiple
- Sweetgreen: shows we're NOT modeling on bubble peaks

Critical line: "None were pre-revenue unicorns. Dave's at $1B had $617M of actual revenue. We're not asking you to bet on hype — we're asking you to bet on a proven trajectory."

For ANCHOR SAFE: this is where they'll dig in. Be ready for "what makes you different from the failed roll-ups?" Answer: team capability (data, engineering, donut expertise — slide 5).`);

// ============================================================
// SLIDE 9 — THE ROLL-UP STRUCTURE
// ============================================================
const s9 = pres.addSlide();
s9.background = { color: C.cream };

s9.addText('The roll-up structure', {
  x: 0.6, y: 0.5, w: 12.1, h: 0.5,
  fontFace: FONT_DISPLAY, fontSize: 32, color: C.ink, bold: true,
});

s9.addText('One HoldCo, three cap-table lines. Tax-free contributions via §721. Clean.', {
  x: 0.6, y: 1.05, w: 12.1, h: 0.4,
  fontFace: FONT_BODY, fontSize: 14, color: C.muted, italic: true,
});

// HoldCo box on top
s9.addShape('rect', {
  x: 2.6, y: 1.8, w: 8.1, h: 1.0,
  fill: { color: C.ink },
  line: { color: C.gold, width: 2 },
});
s9.addText('TOP-LEVEL · DELAWARE LLC', {
  x: 2.9, y: 1.95, w: 7.5, h: 0.25,
  fontFace: FONT_BODY, fontSize: 9, color: C.gold, bold: true, charSpacing: 3,
});
s9.addText('Golden Glaze Holdings LLC', {
  x: 2.9, y: 2.2, w: 7.5, h: 0.55,
  fontFace: FONT_DISPLAY, fontSize: 24, color: C.cream, bold: true,
});

// Three cap table boxes
const capLines = [
  { label: 'GGP (OPERATORS)', pct: '~50%', detail: '6 partners · founders + active + advisors' },
  { label: 'PASSIVE SPV (LPs)', pct: '~36%', detail: '14 LPs pooled · UU+Jack as LP of founder shops' },
  { label: 'MIP POOL', pct: '10% reserve', detail: 'Pheak + executive hires through Series A' },
];
capLines.forEach((l, i) => {
  const x = 0.7 + i * 4.05;
  s9.addShape('rect', {
    x, y: 3.2, w: 3.9, h: 1.4,
    fill: { color: C.white },
    line: { color: C.gold, width: 1 },
  });
  s9.addText(l.label, {
    x: x + 0.2, y: 3.35, w: 3.5, h: 0.3,
    fontFace: FONT_BODY, fontSize: 10, color: C.muted, bold: true, charSpacing: 3, align: 'center',
  });
  s9.addText(l.pct, {
    x: x + 0.2, y: 3.7, w: 3.5, h: 0.55,
    fontFace: FONT_MONO, fontSize: 28, color: C.goldDeep, bold: true, align: 'center',
  });
  s9.addText(l.detail, {
    x: x + 0.2, y: 4.25, w: 3.5, h: 0.35,
    fontFace: FONT_BODY, fontSize: 10.5, color: C.text, align: 'center',
  });
});

// Subsidiary boxes
s9.addText('WHOLLY-OWNED SUBSIDIARIES', {
  x: 0.6, y: 5.1, w: 12.1, h: 0.3,
  fontFace: FONT_BODY, fontSize: 10, color: C.muted, bold: true, charSpacing: 3, align: 'center',
});
const subs = ['Shop LLCs (×7)', 'Kitchen LLC', 'Golden POS LLC', 'Real Estate LLC'];
subs.forEach((s, i) => {
  const x = 0.6 + i * 3.05;
  s9.addShape('rect', {
    x, y: 5.5, w: 2.95, h: 0.7,
    fill: { color: C.card },
    line: { color: C.muted, width: 1 },
  });
  s9.addText(s, {
    x, y: 5.5, w: 2.95, h: 0.7,
    fontFace: FONT_BODY, fontSize: 13, color: C.ink, bold: true, align: 'center', valign: 'middle',
  });
});

// Key callouts
s9.addText('Shell HoldCo formed Month 1. SAFE closes immediately. Subsidiaries roll in over 6-12 months as consents complete.', {
  x: 0.6, y: 6.5, w: 12.1, h: 0.6,
  fontFace: FONT_BODY, fontSize: 13, color: C.text, italic: true, align: 'center', lineSpacingMultiple: 1.4,
});

s9.addNotes(`This is the structural slide. For sophisticated investors (anchor SAFE), this is where they evaluate whether we know what we're doing.

Key talking points:
1. Three lines is institutional-standard. PE buyers see this and immediately understand they can engage cleanly.
2. Shell HoldCo first means SAFE proceeds are available before the rollup completes. Investors don't have to wait.
3. §721 is the standard tax-free contribution mechanism. No tax event for any LP at rollup.
4. 6-12 month timeline is realistic, not aggressive. We're not pretending it happens in 30 days.

For SMALL SAFE: light touch on this slide. Mention: "you'll see this evolve as the HoldCo forms, but your equity position is established by the SAFE terms at close."

For ANCHOR SAFE: this is where they'll ask "what could go wrong?" Have ready: capital floor mechanic protects LPs, lender/landlord consents handled per-shop, tax memos drafted per contribution.`);

// ============================================================
// SLIDE 10 — UNIT ECONOMICS
// ============================================================
const s10 = pres.addSlide();
s10.background = { color: C.white };

s10.addText('Unit economics that work', {
  x: 0.6, y: 0.5, w: 12.1, h: 0.5,
  fontFace: FONT_DISPLAY, fontSize: 32, color: C.ink, bold: true,
});

s10.addText('Two example shops, one each from the LP cohort and the founder-funded cohort.', {
  x: 0.6, y: 1.05, w: 12.1, h: 0.4,
  fontFace: FONT_BODY, fontSize: 14, color: C.muted, italic: true,
});

// Two columns: Arlington and Bluemound
const shopEx = [
  {
    name: 'ARLINGTON · LP-FUNDED',
    rows: [
      ['Acquisition price', '~$130-180K'],
      ['LP capital (8 × $25K)', '$200K'],
      ['MRR at acquisition', '$18K'],
      ['MRR today (8 months)', '$30K (+67%)'],
      ['Annualized', '$360K'],
      ['Current valuation', '$330K (0.92× rev)'],
      ['Payback path', '<3 yrs at current margins'],
    ]
  },
  {
    name: 'BLUEMOUND · FOUNDER-FUNDED',
    rows: [
      ['Acquisition price', '~$30-50K'],
      ['Founder capital', 'UU + Jack'],
      ['MRR at acquisition', '$0 (closed shop)'],
      ['MRR today (1 month)', '$8K (NEW)'],
      ['Annualized', '$96K'],
      ['Current valuation', '$80K (0.83× rev)'],
      ['Payback path', '<2 yrs · still ramping'],
    ]
  },
];
shopEx.forEach((s, i) => {
  const x = 0.6 + i * 6.1;
  s10.addText(s.name, {
    x, y: 1.7, w: 5.9, h: 0.4,
    fontFace: FONT_BODY, fontSize: 12, color: C.goldDeep, bold: true, charSpacing: 3,
  });
  s.rows.forEach((r, j) => {
    const y = 2.2 + j * 0.5;
    s10.addShape('rect', {
      x, y, w: 5.9, h: 0.45,
      fill: { color: j % 2 ? C.cream : C.white },
      line: { color: C.card, width: 0.5 },
    });
    s10.addText(r[0], {
      x: x + 0.2, y, w: 3.0, h: 0.45,
      fontFace: FONT_BODY, fontSize: 12, color: C.text, valign: 'middle',
    });
    s10.addText(r[1], {
      x: x + 3.2, y, w: 2.5, h: 0.45,
      fontFace: FONT_MONO, fontSize: 12, color: C.ink, bold: true, valign: 'middle', align: 'right',
    });
  });
});

s10.addText('The model works at both ends of the funding spectrum. LP-funded scales capital; founder-funded scales velocity.', {
  x: 0.6, y: 6.6, w: 12.1, h: 0.5,
  fontFace: FONT_BODY, fontSize: 13, color: C.muted, italic: true, align: 'center',
});

s10.addNotes(`Walk through both shops side by side. Show the model works in two different capital structures.

Key narrative for ANCHOR SAFE: "Arlington shows the LP-funded path — we share equity but scale faster. Bluemound shows the founder-funded path — we keep more equity but scale slower. The HoldCo rollup blends both, and your SAFE captures the future of both paths."

For SMALL SAFE: simpler — "Both shop types are profitable. You're investing in the platform that operates both."

Pushback to prepare for: "What's the actual EBITDA margin?" Honest answer: still being verified by bookkeeper, target is 18-22% at maturity (Dave's-comparable).`);

// ============================================================
// SLIDE 11 — WHAT'S NEEDED & WHAT'S IN PLAY
// ============================================================
const s11 = pres.addSlide();
s11.background = { color: C.cream };

s11.addText('What we are asking for', {
  x: 0.6, y: 0.5, w: 12.1, h: 0.5,
  fontFace: FONT_DISPLAY, fontSize: 32, color: C.ink, bold: true,
});

s11.addText('$1M total round · $300K SAFE first to fund HoldCo formation · $700K follow-on as warranted', {
  x: 0.6, y: 1.05, w: 12.1, h: 0.4,
  fontFace: FONT_BODY, fontSize: 14, color: C.muted, italic: true,
});

// SAFE terms box
s11.addShape('rect', {
  x: 0.6, y: 1.7, w: 12.1, h: 2.8,
  fill: { color: C.white },
  line: { color: C.gold, width: 2 },
});
s11.addText('SAFE TERMS', {
  x: 0.9, y: 1.9, w: 11.5, h: 0.3,
  fontFace: FONT_BODY, fontSize: 11, color: C.goldDeep, bold: true, charSpacing: 3,
});
s11.addText('$300K · $2M post-money cap · 20% discount · MFN', {
  x: 0.9, y: 2.2, w: 11.5, h: 0.6,
  fontFace: FONT_DISPLAY, fontSize: 26, color: C.ink, bold: true,
});

// Terms detail rows
const terms = [
  ['Instrument', 'SAFE (Simple Agreement for Future Equity) · Y Combinator post-money template'],
  ['Valuation cap', '$2M post-money · approximately 1.5× current aggregate shop value'],
  ['Discount', '20% on next priced round · the greater-of mechanic favors investor at conversion'],
  ['MFN clause', 'Any later SAFE on better terms triggers automatic upgrade for early participants'],
  ['Conversion', 'Series A within 6-12 months at $4-5M pre-money · $1M raise · SAFE converts at cap'],
];
terms.forEach((t, i) => {
  const y = 3.0 + i * 0.28;
  s11.addText(t[0], {
    x: 0.9, y, w: 2.8, h: 0.26,
    fontFace: FONT_BODY, fontSize: 11.5, color: C.muted, bold: true,
  });
  s11.addText(t[1], {
    x: 3.7, y, w: 8.7, h: 0.26,
    fontFace: FONT_BODY, fontSize: 11.5, color: C.text,
  });
});

// Use of proceeds
s11.addText('USE OF $300K SAFE PROCEEDS', {
  x: 0.6, y: 4.8, w: 12.1, h: 0.3,
  fontFace: FONT_BODY, fontSize: 11, color: C.goldDeep, bold: true, charSpacing: 3,
});

const uses = [
  ['$55-90K', 'Legal · §721 rollup, HoldCo formation, OA, securities counsel'],
  ['$60K', 'Operations · Jonathan ops manager hire (first 6-9 months)'],
  ['$50K', 'Kitchen build · centralized production for shop network'],
  ['$45K', 'FDD work · franchise disclosure document preparation'],
  ['$30K', 'Brand · signage, packaging, web, light marketing'],
  ['$30K', 'Reserve · working capital for next 2 acquisitions'],
];
uses.forEach((u, i) => {
  const x = 0.6 + (i % 3) * 4.1;
  const y = 5.2 + Math.floor(i / 3) * 0.95;
  s11.addShape('rect', {
    x, y, w: 3.9, h: 0.85,
    fill: { color: C.white },
    line: { color: C.card, width: 1 },
  });
  s11.addText(u[0], {
    x: x + 0.2, y: y + 0.05, w: 3.5, h: 0.35,
    fontFace: FONT_MONO, fontSize: 16, color: C.goldDeep, bold: true,
  });
  s11.addText(u[1], {
    x: x + 0.2, y: y + 0.4, w: 3.5, h: 0.45,
    fontFace: FONT_BODY, fontSize: 10.5, color: C.text,
  });
});

s11.addNotes(`This is the closing slide. Be specific. Be honest.

For ANCHOR SAFE ($500K): "We're talking to one anchor of $500K plus pool participants for the remaining $500K. The anchor gets the right of first look on Series A pricing — meaningful upside protection."

For SMALL SAFE ($30K): "The terms are MFN-protected. If a later investor gets better terms, yours automatically upgrade. No timing risk."

Make sure they understand the use of proceeds. Legal isn't bloated — it's actually necessary to do this rollup right. The Jonathan hire is the single biggest line because that's the institutional-grade ops capability we need.`);

// ============================================================
// SLIDE 12 — THE MATH (returns table)
// ============================================================
const s12 = pres.addSlide();
s12.background = { color: C.white };

s12.addText('The math', {
  x: 0.6, y: 0.5, w: 12.1, h: 0.5,
  fontFace: FONT_DISPLAY, fontSize: 32, color: C.ink, bold: true,
});

s12.addText('SAFE participants at three check sizes, three exit valuations. MOIC and IRR for a 4-year hold.', {
  x: 0.6, y: 1.05, w: 12.1, h: 0.4,
  fontFace: FONT_BODY, fontSize: 14, color: C.muted, italic: true,
});

// Returns table — corrected SAFE math
// Cap $2M post-money, Series A 20% dilution
// SAFE ownership at exit = (check/$2M) × (1 - 0.2 Series A dilution)
const calcReturn = (check, exitMM) => {
  const ownership = (check / 2000) * (1 - 0.2);
  return exitMM * 1000000 * ownership;
};
const moic = (ret, check) => (ret / (check * 1000)).toFixed(1);
const irr = (moic, years = 4) => (Math.pow(parseFloat(moic), 1/years) - 1) * 100;

// Format dollar returns: $X.XM for >= $1M, $XXXk for less
const fmt = (n) => {
  if (n >= 1000000) return `$${(n / 1000000).toFixed(1)}M`;
  return `$${(n / 1000).toFixed(0)}K`;
};

s12.addTable([
  // header
  [
    { text: 'Check Size', options: { bold: true, color: C.white, fill: { color: C.ink }, fontSize: 13, fontFace: FONT_BODY } },
    { text: 'Exit @ $50M', options: { bold: true, color: C.white, fill: { color: C.ink }, fontSize: 13, fontFace: FONT_BODY, align: 'center' } },
    { text: 'Exit @ $80M', options: { bold: true, color: C.white, fill: { color: C.ink }, fontSize: 13, fontFace: FONT_BODY, align: 'center' } },
    { text: 'Exit @ $120M (base)', options: { bold: true, color: C.white, fill: { color: C.ink }, fontSize: 13, fontFace: FONT_BODY, align: 'center' } },
    { text: 'Exit @ $200M (upside)', options: { bold: true, color: C.white, fill: { color: C.ink }, fontSize: 13, fontFace: FONT_BODY, align: 'center' } },
  ],
  ...[30, 100, 250, 500].map((check, i) => {
    const e50 = calcReturn(check, 50), e80 = calcReturn(check, 80), e120 = calcReturn(check, 120), e200 = calcReturn(check, 200);
    return [
      { text: `$${check}K`, options: { bold: true, color: C.ink, fontSize: 14, fontFace: FONT_MONO, fill: { color: i % 2 ? C.cream : C.white } } },
      { text: `${fmt(e50)}\n${moic(e50, check)}× MOIC · ${irr(moic(e50, check)).toFixed(0)}% IRR`, options: { color: C.text, fontSize: 12, fontFace: FONT_BODY, align: 'center', fill: { color: i % 2 ? C.cream : C.white } } },
      { text: `${fmt(e80)}\n${moic(e80, check)}× MOIC · ${irr(moic(e80, check)).toFixed(0)}% IRR`, options: { color: C.text, fontSize: 12, fontFace: FONT_BODY, align: 'center', fill: { color: i % 2 ? C.cream : C.white } } },
      { text: `${fmt(e120)}\n${moic(e120, check)}× MOIC · ${irr(moic(e120, check)).toFixed(0)}% IRR`, options: { color: C.goldDeep, bold: true, fontSize: 12, fontFace: FONT_BODY, align: 'center', fill: { color: i % 2 ? C.cream : C.white } } },
      { text: `${fmt(e200)}\n${moic(e200, check)}× MOIC · ${irr(moic(e200, check)).toFixed(0)}% IRR`, options: { color: C.goldDeep, bold: true, fontSize: 12, fontFace: FONT_BODY, align: 'center', fill: { color: i % 2 ? C.cream : C.white } } },
    ];
  })
], {
  x: 0.6, y: 1.8, w: 12.1, h: 3.4,
  colW: [2.0, 2.525, 2.525, 2.525, 2.525],
  rowH: [0.5, 0.7, 0.7, 0.7, 0.7],
  border: { type: 'solid', color: C.card, pt: 0.5 },
});

// Assumptions footnote
s12.addText('ASSUMPTIONS', {
  x: 0.6, y: 5.5, w: 12.1, h: 0.3,
  fontFace: FONT_BODY, fontSize: 10, color: C.goldDeep, bold: true, charSpacing: 3,
});

s12.addText([
  { text: '• SAFE converts at $2M cap at Series A · ', options: {} },
  { text: '• 20% Series A dilution applied · ', options: {} },
  { text: '• 4-year hold to exit · ', options: {} },
  { text: '• Linear scaling; no Series B+ dilution modeled', options: {} },
], {
  x: 0.6, y: 5.8, w: 12.1, h: 0.4,
  fontFace: FONT_BODY, fontSize: 11, color: C.text, lineSpacingMultiple: 1.4,
});

s12.addText('Numbers are illustrative. Actual returns depend on final cap table, dilution events, exit terms, and tax treatment. SAFE investors will see definitive math at close.', {
  x: 0.6, y: 6.3, w: 12.1, h: 0.4,
  fontFace: FONT_BODY, fontSize: 10, color: C.muted, italic: true,
});

s12.addText('Base case ($120M exit) returns 48× MOIC on the SAFE. Conservative case ($80M) still returns 32×. The $2M cap is generous to early SAFE investors — that\'s the point.', {
  x: 0.6, y: 6.85, w: 12.1, h: 0.4,
  fontFace: FONT_BODY, fontSize: 13, color: C.ink, italic: true, bold: true, align: 'center',
});

s12.addNotes(`Walk through the math. The MOICs are very high — that's the point of a $2M cap on a company we believe will be worth $80-120M in 4 years. Early SAFE investors are taking the most risk and getting the most upside.

For ANCHOR SAFE ($500K row): "At base case ($120M exit), you get back $24M. That's 48× MOIC over 4 years. At conservative case ($80M), still $16M and 32×. The cap is the answer to 'what protects me if you stumble' — and the cap is $2M. We deliberately set it generous because we want anchor commitment NOW, when we need the capital most."

For SMALL SAFE ($30K row): "$30K at base case becomes $1.44M. That's 48× over 4 years. At conservative $80M exit, still $960K and 32×. The cap normalizes the math — every dollar of SAFE has the same per-dollar return potential."

Critical: be honest about assumptions. These MOICs assume:
1. We hit $80-120M exit at Year 4 (execution risk)
2. Only one Series A round dilutes the SAFE (no Series B modeled)
3. No misc dilution from convertibles, employee grants beyond MIP, etc.
4. The acquirer doesn't impose additional adjustments

Realistic ranges:
- If we hit only $40M exit: SAFE pool returns 16× (still strong)
- If we need a Series B at 15% dilution: subtract ~15% from all returns
- If the rollup stalls: SAFE converts later at the same cap; less upside but still capped

If they ask "why such a low cap?" — honest answer: "We need the capital now to execute the rollup. The cap is the trade. Once Series A prices the company at $4-5M pre, the SAFE window closes forever. You are paying premium to today's $1.2M aggregate value ($2M cap = 1.7× current) for outsized upside to the $80M+ exit. That asymmetry is the entire offer."`);

// ============================================================
// SLIDE 13 — RISKS WE OWN
// ============================================================
const s13 = pres.addSlide();
s13.background = { color: C.cream };

s13.addText('The risks we own', {
  x: 0.6, y: 0.5, w: 12.1, h: 0.5,
  fontFace: FONT_DISPLAY, fontSize: 32, color: C.ink, bold: true,
});

s13.addText('Honest accounting of what could go wrong, and how we are managing each.', {
  x: 0.6, y: 1.05, w: 12.1, h: 0.4,
  fontFace: FONT_BODY, fontSize: 14, color: C.muted, italic: true,
});

const risks = [
  { risk: 'LP consent delays during rollup', mit: 'Capital floor + Arlington pref preserved. No LP loses anything. Many gain protections they did not formally have.' },
  { risk: 'Operational bandwidth as we scale acquisitions', mit: 'Jonathan ops manager hire in Month 2-4 directly addresses this. Muypin already running daily ops full-time.' },
  { risk: 'Multiple compression at exit (2021 vs today)', mit: 'We model on Cava (3.5×) and Krispy Kreme (3.6×) levels, not Sweetgreen 2021 (15×). Conservative throughout.' },
  { risk: 'Revenue verification gap (gross vs net)', mit: 'Fractional bookkeeper engaged Month 1. Verified May 2026 close locks in real numbers before SAFE close.' },
  { risk: 'Lender / landlord consent on any shop', mit: 'Shell HoldCo can absorb subsidiaries individually as consents complete. Not all-or-nothing structure.' },
  { risk: 'Securities compliance (14 LPs, Reg D)', mit: 'Accreditation questionnaires sent Month 1. Securities counsel engaged. Reg D 506(b) compliance achievable.' },
];

risks.forEach((r, i) => {
  const x = 0.6 + (i % 2) * 6.1;
  const y = 1.7 + Math.floor(i / 2) * 1.7;
  s13.addShape('rect', {
    x, y, w: 5.9, h: 1.55,
    fill: { color: C.white },
    line: { color: C.card, width: 1 },
  });
  s13.addText('▲ RISK', {
    x: x + 0.3, y: y + 0.2, w: 5.4, h: 0.25,
    fontFace: FONT_BODY, fontSize: 9, color: C.accent, bold: true, charSpacing: 3,
  });
  s13.addText(r.risk, {
    x: x + 0.3, y: y + 0.45, w: 5.4, h: 0.4,
    fontFace: FONT_BODY, fontSize: 13, color: C.ink, bold: true,
  });
  s13.addText('MITIGATION', {
    x: x + 0.3, y: y + 0.85, w: 5.4, h: 0.25,
    fontFace: FONT_BODY, fontSize: 9, color: C.goldDeep, bold: true, charSpacing: 3,
  });
  s13.addText(r.mit, {
    x: x + 0.3, y: y + 1.1, w: 5.4, h: 0.5,
    fontFace: FONT_BODY, fontSize: 11, color: C.text, lineSpacingMultiple: 1.3,
  });
});

s13.addNotes(`Risks slide is the ultimate trust builder. Investors HATE when a founder pretends there's no risk.

Walk through each. Acknowledge honestly. Show mitigation clearly. The asymmetry: founders who admit risk and have mitigation plans are far more credible than founders who claim everything will be fine.

For ANCHOR SAFE: spend more time here. They'll have read the deck and want to probe. Be ready for "what's the worst case?" Honest answer: "Worst case, the rollup stalls due to one LP holdout. We absorb that shop later. The other 6 still roll up. SAFE proceeds still fund growth. We are not at zero."

For SMALL SAFE: lighter — but still acknowledge: "We could fail. Donut shops are not bulletproof. The way you protect yourself is the structure of the SAFE — capped, discounted, MFN. The structure does its job even if we stumble."`);

// ============================================================
// SLIDE 14 — WHY NOW
// ============================================================
const s14 = pres.addSlide();
s14.background = { color: C.ink };

s14.addText('Why now', {
  x: 0.6, y: 0.5, w: 12.1, h: 0.5,
  fontFace: FONT_DISPLAY, fontSize: 32, color: C.cream, bold: true,
});

s14.addText('Three timing windows that compound to make this round time-sensitive.', {
  x: 0.6, y: 1.05, w: 12.1, h: 0.4,
  fontFace: FONT_BODY, fontSize: 14, color: C.goldSoft, italic: true,
});

const whyNow = [
  { num: '01', title: 'Pre-ramp valuations', body: 'Stores are 4-6 months old. Pricing on today\'s numbers undervalues the trajectory. The $2M cap captures this — invest BEFORE the ramp, not after.' },
  { num: '02', title: 'Roll-up window is open', body: 'HoldCo forms now. Once Series A closes, terms harden. Today\'s SAFE participants are the only ones who get this entry price.' },
  { num: '03', title: 'Operations stretching', body: 'We have 7 shops with 4 founders running ops part-time. Jonathan hire requires SAFE proceeds. Every week of delay is real operational drag.' },
];

whyNow.forEach((w, i) => {
  const y = 1.9 + i * 1.65;
  // Number
  s14.addShape('rect', {
    x: 0.6, y, w: 1.2, h: 1.4,
    fill: { color: C.gold },
    line: { color: C.gold, width: 0 },
  });
  s14.addText(w.num, {
    x: 0.6, y: y + 0.35, w: 1.2, h: 0.7,
    fontFace: FONT_DISPLAY, fontSize: 40, color: C.ink, bold: true, align: 'center',
  });
  // Content
  s14.addShape('rect', {
    x: 1.85, y, w: 10.85, h: 1.4,
    fill: { color: C.text },
    line: { color: C.gold, width: 0 },
  });
  s14.addText(w.title, {
    x: 2.1, y: y + 0.2, w: 10.4, h: 0.4,
    fontFace: FONT_DISPLAY, fontSize: 20, color: C.cream, bold: true,
  });
  s14.addText(w.body, {
    x: 2.1, y: y + 0.65, w: 10.4, h: 0.7,
    fontFace: FONT_BODY, fontSize: 13, color: 'D4C09B', lineSpacingMultiple: 1.4,
  });
});

s14.addText('The next 30 days set the trajectory.', {
  x: 0.6, y: 6.9, w: 12.1, h: 0.4,
  fontFace: FONT_BODY, fontSize: 14, color: C.gold, italic: true, align: 'center', bold: true,
});

s14.addNotes(`Closing emotional/urgency slide. Don't oversell — facts speak.

Key message: this round is open NOW. We're not pretending it's "first come first served" but the cap won't go down once we have anchor commitment.

For ANCHOR SAFE: "Your $500K commitment closes the round and unlocks the rest. The pool participants who follow you accept whatever terms you signed."

For SMALL SAFE: "MFN protects you on terms. But the cap is a function of valuation — once we have meaningful Series A revenue, the SAFE window closes."`);

// ============================================================
// SLIDE 15 — NEXT STEPS
// ============================================================
const s15 = pres.addSlide();
s15.background = { color: C.cream };

s15.addText('Next steps', {
  x: 0.6, y: 0.5, w: 12.1, h: 0.5,
  fontFace: FONT_DISPLAY, fontSize: 32, color: C.ink, bold: true,
});

s15.addText('What happens between today and SAFE close.', {
  x: 0.6, y: 1.05, w: 12.1, h: 0.4,
  fontFace: FONT_BODY, fontSize: 14, color: C.muted, italic: true,
});

const steps = [
  { week: 'WEEK 1', what: 'Follow-up call · clarify any open questions · expression of interest' },
  { week: 'WEEK 2', what: 'Term sheet shared · review with your counsel · indicative commitment' },
  { week: 'WEEK 3', what: 'Final SAFE document · signatures · wire instructions' },
  { week: 'WEEK 4', what: 'SAFE closes · HoldCo formation begins · regular monthly investor updates start' },
];

steps.forEach((s, i) => {
  const y = 1.8 + i * 1.1;
  s15.addShape('rect', {
    x: 0.6, y, w: 12.1, h: 0.9,
    fill: { color: C.white },
    line: { color: C.gold, width: 1 },
  });
  s15.addText(s.week, {
    x: 0.9, y: y + 0.25, w: 2.0, h: 0.4,
    fontFace: FONT_MONO, fontSize: 16, color: C.goldDeep, bold: true,
  });
  s15.addText(s.what, {
    x: 3.0, y: y + 0.25, w: 9.5, h: 0.4,
    fontFace: FONT_BODY, fontSize: 14, color: C.text, valign: 'middle',
  });
});

s15.addText('All materials available on request: strategic memo · cap table model · §721 contribution memos · LP consent process documentation.', {
  x: 0.6, y: 6.4, w: 12.1, h: 0.5,
  fontFace: FONT_BODY, fontSize: 12, color: C.muted, italic: true, align: 'center',
});

s15.addNotes(`Practical close. Make sure they know exactly what happens next and when.

For ANCHOR SAFE: "I want to do this in 30 days. Faster if your timeline allows. Slower if your counsel wants more time. Walk me through your preferred process."

For SMALL SAFE: "Standard process. We'll send you the SAFE template after this call. Once you've reviewed, we coordinate signatures and wire."

End every conversation with: "What questions do you have that I haven't answered? What would you need to see to commit?"`);

// ============================================================
// SLIDE 16 — CLOSING / CONTACT
// ============================================================
const s16 = pres.addSlide();
s16.background = { color: C.ink };

s16.addText('Golden Glaze', {
  x: 0.6, y: 1.8, w: 12.1, h: 1.5,
  fontFace: FONT_DISPLAY, fontSize: 72, color: C.cream, bold: true, italic: true, align: 'center',
});

s16.addText('The next great American specialty bakery — built right.', {
  x: 0.6, y: 3.5, w: 12.1, h: 0.6,
  fontFace: FONT_BODY, fontSize: 18, color: C.goldSoft, italic: true, align: 'center',
});

// Contact card
s16.addShape('rect', {
  x: 3.5, y: 4.7, w: 6.3, h: 1.6,
  fill: { color: C.text },
  line: { color: C.gold, width: 1 },
});
s16.addText('CONTACT', {
  x: 3.5, y: 4.85, w: 6.3, h: 0.3,
  fontFace: FONT_BODY, fontSize: 10, color: C.gold, bold: true, charSpacing: 3, align: 'center',
});
s16.addText('Jack Yen · Founder & CEO\nYouyou Ly · Co-founder & COO', {
  x: 3.5, y: 5.15, w: 6.3, h: 0.7,
  fontFace: FONT_BODY, fontSize: 14, color: C.cream, align: 'center', lineSpacingMultiple: 1.4,
});
s16.addText('Golden Glaze Holdings · Dallas-Fort Worth', {
  x: 3.5, y: 5.85, w: 6.3, h: 0.3,
  fontFace: FONT_BODY, fontSize: 11, color: 'D4C09B', italic: true, align: 'center',
});

s16.addText('Confidential investment memorandum · May 2026 · Do not distribute', {
  x: 0.6, y: 6.95, w: 12.1, h: 0.3,
  fontFace: FONT_BODY, fontSize: 9, color: C.muted, charSpacing: 2, align: 'center',
});

s16.addNotes(`Closing slide. Hold the brand moment.

End the conversation by re-stating the next step (whatever was agreed on the previous slide). Don't ramble. Confidence comes from clarity.

If they ask follow-up questions, take notes and commit to specific response times.

If they ask "when do you need an answer?" — be honest: "Anchor commitment unblocks the round. Pool participants follow on MFN terms whatever I close with the anchor. Realistic answer: 30 days from today to close this round."`);

// SAVE
pres.writeFile({ fileName: '/home/claude/gg-package/docs/02-Investor-Pitch-Deck.pptx' })
  .then(() => console.log('✓ Pitch deck built'));
