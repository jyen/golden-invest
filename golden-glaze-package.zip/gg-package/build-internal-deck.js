// Golden Glaze — Internal Alignment Deck
// Designed for the Youyou + Jack walkthrough session BEFORE approaching investors
// Different from the investor pitch deck: decision-focused, candid, internal

const PptxGenJS = require('pptxgenjs');
const pres = new PptxGenJS();

pres.layout = 'LAYOUT_WIDE';
pres.author = 'Golden Glaze Holdings';
pres.company = 'Golden Glaze Holdings LLC';
pres.title = 'Internal Alignment — Pre-Investor';

// Same brand palette
const C = {
  ink: '1A1208',
  text: '4A3825',
  muted: '8B6E3D',
  cream: 'FAF6EA',
  card: 'F8EFD7',
  gold: 'D99C2B',
  goldDeep: 'A87618',
  goldSoft: 'F5E2B8',
  white: 'FFFFFF',
  accent: 'B85042',
  green: '4A7C59',
};

const FD = 'Georgia';
const FB = 'Calibri';
const FM = 'Consolas';

// Helper
const eyebrow = (slide, text, x=0.6, y=0.5, color=C.goldDeep) => {
  slide.addText(text, {
    x, y, w: 12.1, h: 0.35,
    fontFace: FB, fontSize: 11, color, bold: true, charSpacing: 4,
  });
};

const title = (slide, text, x=0.6, y=0.9, color=C.ink) => {
  slide.addText(text, {
    x, y, w: 12.1, h: 0.7,
    fontFace: FD, fontSize: 32, color, bold: true,
  });
};

const subtitle = (slide, text, x=0.6, y=1.55, color=C.muted) => {
  slide.addText(text, {
    x, y, w: 12.1, h: 0.4,
    fontFace: FB, fontSize: 14, color, italic: true,
  });
};

// ============================================================
// SLIDE 1 — COVER
// ============================================================
const s1 = pres.addSlide();
s1.background = { color: C.ink };

s1.addText('INTERNAL ALIGNMENT · NOT FOR DISTRIBUTION', {
  x: 0.6, y: 0.5, w: 12.1, h: 0.4,
  fontFace: FB, fontSize: 11, color: C.gold, bold: true, charSpacing: 4,
});

s1.addText('Pre-investor alignment', {
  x: 0.6, y: 2.0, w: 12.1, h: 0.6,
  fontFace: FB, fontSize: 18, color: C.goldSoft, italic: true,
});

s1.addText('Locking the rollup', {
  x: 0.6, y: 2.7, w: 12.1, h: 1.3,
  fontFace: FD, fontSize: 66, color: C.cream, bold: true, italic: true,
});

s1.addText('Everything we need to decide before we send the deck to the anchor.', {
  x: 0.6, y: 4.3, w: 12.1, h: 0.6,
  fontFace: FB, fontSize: 18, color: C.goldSoft, italic: true,
});

// participants
s1.addShape('rect', {
  x: 0.6, y: 5.7, w: 12.1, h: 1.3,
  fill: { color: C.text },
  line: { color: C.gold, width: 1 },
});
s1.addText('PARTICIPANTS', {
  x: 0.9, y: 5.85, w: 11.5, h: 0.3,
  fontFace: FB, fontSize: 10, color: C.gold, bold: true, charSpacing: 3,
});
s1.addText('Youyou Ly · Co-founder & COO     /     Jack Yen · Founder & CEO', {
  x: 0.9, y: 6.15, w: 11.5, h: 0.7,
  fontFace: FD, fontSize: 22, color: C.cream, italic: true,
});

s1.addNotes(`This deck is for our internal alignment session ONLY. We work through it together, mark things up, make decisions, then close the book and write the investor-facing version.

Goal: leave this session with a locked cap table, locked SAFE terms, and a 30-day action list both of us own.

Estimated time: 90 minutes. We should not rush. Better to fight here than at the term sheet stage.`);

// ============================================================
// SLIDE 2 — WHERE WE ARE
// ============================================================
const s2 = pres.addSlide();
s2.background = { color: C.cream };

eyebrow(s2, 'STATE OF THE UNION · MAY 2026');
title(s2, 'Where we actually are');
subtitle(s2, 'Eight months of acquisitions. Seven shops. Real revenue. Not bad. But the structure is becoming the bottleneck.');

// 4 stat tiles
const stats = [
  { label: 'STORES OPERATING', val: '7', sub: 'in 8 months · DFW' },
  { label: 'GROSS ARR', val: '~$1.5M', sub: 'estimated · pre-merchant fees' },
  { label: 'AGGREGATE VALUE', val: '$1.20M', sub: 'conservative @ 0.83-0.92× rev' },
  { label: 'LP CAPITAL IN', val: '$380K', sub: '14 LPs across 3 cohorts' },
];
stats.forEach((s, i) => {
  const x = 0.6 + i * 3.05;
  s2.addShape('rect', {
    x, y: 2.1, w: 2.9, h: 1.5,
    fill: { color: C.white },
    line: { color: C.card, width: 1 },
  });
  s2.addText(s.label, {
    x: x + 0.2, y: 2.25, w: 2.5, h: 0.3,
    fontFace: FB, fontSize: 10, color: C.muted, bold: true, charSpacing: 3,
  });
  s2.addText(s.val, {
    x: x + 0.2, y: 2.55, w: 2.5, h: 0.6,
    fontFace: FD, fontSize: 28, color: C.goldDeep, bold: true,
  });
  s2.addText(s.sub, {
    x: x + 0.2, y: 3.15, w: 2.5, h: 0.4,
    fontFace: FB, fontSize: 11, color: C.text,
  });
});

// What's working vs what's not
const working = [
  'Turnaround playbook proven (NRH $3K→$11K MRR)',
  'Acquisition pipeline real and moving',
  'Team coming together (Pheak, Muypin, Chanda, Lam)',
  'Conservative valuations defensible at diligence',
];
const broken = [
  '7 separate LLCs — institutional dealbreaker',
  'No formal waterfall / Arlington pref informal',
  'Securities compliance gaps (Reg D 506(b))',
  'No professional ops manager yet (Jonathan pending)',
];
s2.addText('WHAT IS WORKING', {
  x: 0.6, y: 4.0, w: 5.95, h: 0.3,
  fontFace: FB, fontSize: 10, color: C.green, bold: true, charSpacing: 3,
});
s2.addText('WHAT NEEDS FIXING', {
  x: 6.75, y: 4.0, w: 5.95, h: 0.3,
  fontFace: FB, fontSize: 10, color: C.accent, bold: true, charSpacing: 3,
});

working.forEach((item, i) => {
  const y = 4.35 + i * 0.55;
  s2.addShape('rect', {
    x: 0.6, y, w: 5.95, h: 0.45,
    fill: { color: C.white },
    line: { color: C.green, width: 0.5 },
  });
  s2.addText('✓  ' + item, {
    x: 0.8, y, w: 5.7, h: 0.45,
    fontFace: FB, fontSize: 12, color: C.text, valign: 'middle',
  });
});

broken.forEach((item, i) => {
  const y = 4.35 + i * 0.55;
  s2.addShape('rect', {
    x: 6.75, y, w: 5.95, h: 0.45,
    fill: { color: C.white },
    line: { color: C.accent, width: 0.5 },
  });
  s2.addText('!  ' + item, {
    x: 6.95, y, w: 5.7, h: 0.45,
    fontFace: FB, fontSize: 12, color: C.text, valign: 'middle',
  });
});

s2.addNotes(`Open with reality. Don't sell. Just lay out what is.

Working: turnaround playbook is real. We have NRH +267% revenue as proof. We've assembled a team that knows donuts. Valuations are conservative and defensible.

Not working: 7 LLCs cannot become a Series A target. Arlington pref is not in operating agreement language. We have securities compliance work to do. We need a real ops manager.

The question we're aligning on today: what is the cleanest path from here to the structure that supports institutional capital and a $80-120M exit?`);

// ============================================================
// SLIDE 3 — THE STRUCTURE WE'RE PROPOSING
// ============================================================
const s3 = pres.addSlide();
s3.background = { color: C.white };

eyebrow(s3, 'THE ARCHITECTURE');
title(s3, 'One HoldCo. Three cap-table lines. Clean.');
subtitle(s3, 'Golden Glaze Holdings LLC (Delaware) absorbs every shop under §721 tax-free contributions over 6-12 months.');

// HoldCo box
s3.addShape('rect', {
  x: 3.6, y: 2.1, w: 6.1, h: 0.95,
  fill: { color: C.ink },
  line: { color: C.gold, width: 2 },
});
s3.addText('TOP-LEVEL · DELAWARE LLC', {
  x: 3.85, y: 2.25, w: 5.6, h: 0.25,
  fontFace: FB, fontSize: 9, color: C.gold, bold: true, charSpacing: 3,
});
s3.addText('Golden Glaze Holdings LLC', {
  x: 3.85, y: 2.5, w: 5.6, h: 0.5,
  fontFace: FD, fontSize: 22, color: C.cream, bold: true,
});

// Three cap lines with detail
const lines = [
  { label: 'GGP', pct: '~50%', who: 'Operators line', detail: 'Founders (UU 35, Jack 25, Peiyun 15, Max 5) + Active partner (Muypin 6) + Advisors (Luke 3, Chanda 2, Jonathan 2, Lam 1 + 6 reserved). All non-vesting.' },
  { label: 'PASSIVE SPV', pct: '~36%', who: '14 LPs pooled', detail: 'Arl/NRH cohort (8 × $25K + 10% pref floor) + FW cohort (4 × $30K) + Grapevine 2-of-4 ($60K) + UU/Jack as "LPs" of Bluemound/Carrollton/Dallas.' },
  { label: 'MIP', pct: '10% reserve', who: 'Employee equity', detail: 'Pheak 2% allocated (master baker) + 8% reserved for CFO/COO/CMO/GMs and Jonathan converting from advisor to full-time. 4-year vest, 1-year cliff.' },
];

lines.forEach((l, i) => {
  const x = 0.6 + i * 4.1;
  s3.addShape('rect', {
    x, y: 3.5, w: 3.9, h: 3.6,
    fill: { color: C.cream },
    line: { color: C.gold, width: 1 },
  });
  s3.addText(l.label, {
    x: x + 0.3, y: 3.7, w: 3.5, h: 0.3,
    fontFace: FB, fontSize: 11, color: C.goldDeep, bold: true, charSpacing: 3,
  });
  s3.addText(l.pct, {
    x: x + 0.3, y: 4.05, w: 3.5, h: 0.8,
    fontFace: FM, fontSize: 32, color: C.ink, bold: true,
  });
  s3.addText(l.who, {
    x: x + 0.3, y: 4.9, w: 3.5, h: 0.4,
    fontFace: FD, fontSize: 14, color: C.goldDeep, italic: true,
  });
  s3.addText(l.detail, {
    x: x + 0.3, y: 5.35, w: 3.5, h: 1.7,
    fontFace: FB, fontSize: 11, color: C.text, lineSpacingMultiple: 1.4,
  });
});

s3.addNotes(`This is the structure we proposed. Walk through each of the three lines.

GGP (50%): operator line. Six people inside it, four tiers. We worked the percentages back from "founders own 80% of GGP."

Passive SPV (36%): 14 LPs pooled into one cap table line. UU/Jack are treated as the "LPs" of the three founder-funded shops — same mechanic, just we're on both sides for those shops.

MIP (10%): narrow today. Only Pheak. 8% reserved for institutional executive hires through Series A.

The 2.4% gap (founder note conversion) is the $30K founder loan converting to equity at HoldCo.

Decision to align on: does this structure feel right? Anything we'd change before sending counsel an engagement letter?`);

// ============================================================
// SLIDE 4 — GGP FOUR TIERS
// ============================================================
const s4 = pres.addSlide();
s4.background = { color: C.cream };

eyebrow(s4, 'GGP CAP TABLE');
title(s4, 'GGP — the operator entity, four tiers, locked');
subtitle(s4, '100% of GGP. Permanent equity, non-vesting. This is the table we walk into the anchor conversation with.');

s4.addTable([
  [
    { text: 'Tier', options: { bold: true, color: C.white, fill: { color: C.ink }, fontSize: 12, fontFace: FB } },
    { text: 'Member', options: { bold: true, color: C.white, fill: { color: C.ink }, fontSize: 12, fontFace: FB } },
    { text: '%', options: { bold: true, color: C.white, fill: { color: C.ink }, fontSize: 12, fontFace: FB, align: 'right' } },
    { text: 'Role / Justification', options: { bold: true, color: C.white, fill: { color: C.ink }, fontSize: 12, fontFace: FB } },
  ],
  // Founders 80%
  [
    { text: 'Founder', options: { bold: true, color: C.goldDeep, fontSize: 11, fontFace: FB, fill: { color: 'F5E2B8' } } },
    { text: 'Youyou Ly', options: { bold: true, color: C.ink, fontSize: 11, fontFace: FB, fill: { color: 'F5E2B8' } } },
    { text: '35%', options: { bold: true, color: C.goldDeep, fontSize: 14, fontFace: FM, align: 'right', fill: { color: 'F5E2B8' } } },
    { text: 'CEO/COO. Ops leadership, M&A pipeline, data infrastructure.', options: { color: C.text, fontSize: 11, fontFace: FB, fill: { color: 'F5E2B8' } } },
  ],
  [
    { text: 'Founder', options: { bold: true, color: C.goldDeep, fontSize: 11, fontFace: FB, fill: { color: 'F5E2B8' } } },
    { text: 'Jack Yen', options: { bold: true, color: C.ink, fontSize: 11, fontFace: FB, fill: { color: 'F5E2B8' } } },
    { text: '25%', options: { bold: true, color: C.goldDeep, fontSize: 14, fontFace: FM, align: 'right', fill: { color: 'F5E2B8' } } },
    { text: 'Founder & CEO. Capital structure, investor relations.', options: { color: C.text, fontSize: 11, fontFace: FB, fill: { color: 'F5E2B8' } } },
  ],
  [
    { text: 'Founder', options: { bold: true, color: C.goldDeep, fontSize: 11, fontFace: FB, fill: { color: 'F5E2B8' } } },
    { text: 'Peiyun', options: { bold: true, color: C.ink, fontSize: 11, fontFace: FB, fill: { color: 'F5E2B8' } } },
    { text: '15%', options: { bold: true, color: C.goldDeep, fontSize: 14, fontFace: FM, align: 'right', fill: { color: 'F5E2B8' } } },
    { text: 'Co-founder, Engineering. Golden POS, customer loyalty.', options: { color: C.text, fontSize: 11, fontFace: FB, fill: { color: 'F5E2B8' } } },
  ],
  [
    { text: 'Founder', options: { bold: true, color: C.goldDeep, fontSize: 11, fontFace: FB, fill: { color: 'F5E2B8' } } },
    { text: 'Max', options: { bold: true, color: C.ink, fontSize: 11, fontFace: FB, fill: { color: 'F5E2B8' } } },
    { text: '5%', options: { bold: true, color: C.goldDeep, fontSize: 14, fontFace: FM, align: 'right', fill: { color: 'F5E2B8' } } },
    { text: 'Co-founder, Analysis. Formalized at HoldCo.', options: { color: C.text, fontSize: 11, fontFace: FB, fill: { color: 'F5E2B8' } } },
  ],
  // Active 6%
  [
    { text: 'Active partner', options: { bold: true, color: C.ink, fontSize: 11, fontFace: FB, fill: { color: 'F8EFD7' } } },
    { text: 'Muypin', options: { bold: true, color: C.ink, fontSize: 11, fontFace: FB, fill: { color: 'F8EFD7' } } },
    { text: '6%', options: { bold: true, color: C.ink, fontSize: 14, fontFace: FM, align: 'right', fill: { color: 'F8EFD7' } } },
    { text: 'Full-time donut ops. Only non-founder at owner commitment.', options: { color: C.text, fontSize: 11, fontFace: FB, fill: { color: 'F8EFD7' } } },
  ],
  // Advisors 8% allocated + 6% reserved
  [
    { text: 'Advisor', options: { bold: true, color: C.muted, fontSize: 11, fontFace: FB, fill: { color: C.cream } } },
    { text: 'Luke', options: { color: C.text, fontSize: 11, fontFace: FB, fill: { color: C.cream } } },
    { text: '3%', options: { bold: true, color: C.text, fontSize: 14, fontFace: FM, align: 'right', fill: { color: C.cream } } },
    { text: 'Strategy. Part-time at Verizon Innovation Lab.', options: { color: C.text, fontSize: 11, fontFace: FB, fill: { color: C.cream } } },
  ],
  [
    { text: 'Advisor', options: { bold: true, color: C.muted, fontSize: 11, fontFace: FB, fill: { color: C.cream } } },
    { text: 'Chanda', options: { color: C.text, fontSize: 11, fontFace: FB, fill: { color: C.cream } } },
    { text: '2%', options: { bold: true, color: C.text, fontSize: 14, fontFace: FM, align: 'right', fill: { color: C.cream } } },
    { text: 'FOH operations. Mutual-aid, owns her own shop.', options: { color: C.text, fontSize: 11, fontFace: FB, fill: { color: C.cream } } },
  ],
  [
    { text: 'Advisor', options: { bold: true, color: C.muted, fontSize: 11, fontFace: FB, fill: { color: C.cream } } },
    { text: 'Jonathan', options: { color: C.text, fontSize: 11, fontFace: FB, fill: { color: C.cream } } },
    { text: '2%', options: { bold: true, color: C.text, fontSize: 14, fontFace: FM, align: 'right', fill: { color: C.cream } } },
    { text: 'Operations. Currently advisor; converts to MIP when full-time.', options: { color: C.text, fontSize: 11, fontFace: FB, fill: { color: C.cream } } },
  ],
  [
    { text: 'Advisor', options: { bold: true, color: C.muted, fontSize: 11, fontFace: FB, fill: { color: C.cream } } },
    { text: 'Lam', options: { color: C.text, fontSize: 11, fontFace: FB, fill: { color: C.cream } } },
    { text: '1%', options: { bold: true, color: C.text, fontSize: 14, fontFace: FM, align: 'right', fill: { color: C.cream } } },
    { text: 'Bakery. Part-time mutual-aid.', options: { color: C.text, fontSize: 11, fontFace: FB, fill: { color: C.cream } } },
  ],
  [
    { text: 'Reserved', options: { italic: true, color: C.muted, fontSize: 11, fontFace: FB, fill: { color: C.cream } } },
    { text: 'Future advisors', options: { italic: true, color: C.muted, fontSize: 11, fontFace: FB, fill: { color: C.cream } } },
    { text: '6%', options: { italic: true, color: C.muted, fontSize: 14, fontFace: FM, align: 'right', fill: { color: C.cream } } },
    { text: 'Institutional-grade board advisors recruited before Series A.', options: { italic: true, color: C.muted, fontSize: 11, fontFace: FB, fill: { color: C.cream } } },
  ],
  // Total
  [
    { text: 'TOTAL', options: { bold: true, color: C.ink, fontSize: 12, fontFace: FB, fill: { color: C.card } } },
    { text: '11 partners', options: { bold: true, color: C.ink, fontSize: 11, fontFace: FB, fill: { color: C.card } } },
    { text: '100%', options: { bold: true, color: C.goldDeep, fontSize: 14, fontFace: FM, align: 'right', fill: { color: C.card } } },
    { text: 'Founders 80% + Active 6% + Advisors 14%', options: { bold: true, color: C.text, fontSize: 11, fontFace: FB, fill: { color: C.card } } },
  ],
], {
  x: 0.6, y: 2.1, w: 12.1, h: 4.9,
  colW: [1.8, 1.8, 1.0, 7.5],
  fontSize: 11,
  border: { type: 'solid', color: 'D4C09B', pt: 0.5 },
});

s4.addNotes(`This is the GGP table we worked out. Two open questions still defaulted:

1. Lam at 1% in advisors vs MIP. Defaulted to advisor based on "mutual-aid / part-time" framing. If Lam is on payroll as full-time employee, she belongs in MIP. Decision needed.

2. Advisor reserve at 6%. Sized for 2-4 institutional board advisors at 1-3% each before Series A. Larger reserve possible if we want to recruit more aggressively.

Other items to ratify:
- Max's 5% — formalized from informal. Comfortable?
- Muypin at 6% as the only "active partner" — does she feel that level of commitment?
- Advisors at 8% allocated total — too generous, too tight, or right?

These are the conversations we should not have for the first time in front of an investor.`);

// ============================================================
// SLIDE 5 — MIP NARROW & FOCUSED
// ============================================================
const s5 = pres.addSlide();
s5.background = { color: C.white };

eyebrow(s5, 'MIP POOL · 10% RESERVED AT HOLDCO');
title(s5, 'MIP is narrow on purpose');
subtitle(s5, 'Only 2% allocated today. The other 8% is reserved for the institutional hires we will need to make in the next 12 months.');

// Two big cards: allocated vs reserved
const mipCards = [
  {
    title: 'ALLOCATED · 2%',
    name: 'Pheak',
    role: 'Master Baker · Full-time',
    pct: '2%',
    detail: 'Recipe development, baker training, quality standards across all shops. 10+ years experience anchoring Arlington baking. The only currently full-time non-partner employee at master-craft level. 4-year vest, 1-year cliff.',
    color: C.gold,
  },
  {
    title: 'RESERVED · 8%',
    name: 'Future executive hires',
    role: 'CFO · COO · CMO · GMs',
    pct: '8%',
    detail: 'For the institutional-grade hires we need to make between now and Series A. May absorb Jonathan ~1.5% when he transitions from advisor to full-time Operations Manager.',
    color: C.muted,
  },
];

mipCards.forEach((c, i) => {
  const x = 0.6 + i * 6.1;
  s5.addShape('rect', {
    x, y: 2.1, w: 5.9, h: 4.8,
    fill: { color: i === 0 ? C.cream : C.white },
    line: { color: c.color, width: 2 },
  });
  s5.addText(c.title, {
    x: x + 0.3, y: 2.3, w: 5.3, h: 0.35,
    fontFace: FB, fontSize: 12, color: c.color, bold: true, charSpacing: 3,
  });
  s5.addText(c.pct, {
    x: x + 0.3, y: 2.75, w: 5.3, h: 1.0,
    fontFace: FM, fontSize: 56, color: C.ink, bold: true,
  });
  s5.addText(c.name, {
    x: x + 0.3, y: 4.0, w: 5.3, h: 0.5,
    fontFace: FD, fontSize: 22, color: C.ink, bold: true,
  });
  s5.addText(c.role, {
    x: x + 0.3, y: 4.55, w: 5.3, h: 0.35,
    fontFace: FB, fontSize: 12, color: C.goldDeep, italic: true,
  });
  s5.addText(c.detail, {
    x: x + 0.3, y: 5.0, w: 5.3, h: 1.7,
    fontFace: FB, fontSize: 12, color: C.text, lineSpacingMultiple: 1.4,
  });
});

s5.addNotes(`MIP discipline matters. Most early QSR roll-ups over-allocate MIP and run out of equity to recruit real talent.

Our approach: only allocate to people who are full-time TODAY (Pheak). Hold the rest for the hires we will actually need (CFO, COO, GMs).

Jonathan is in advisor pool today, not MIP — because he's not yet on payroll. When he transitions, ~1.5% comes out of the reserved 8%.

Decision to confirm: Pheak at 2% feels right? Or higher (3%) given how foundational she is to the bakery operation?`);

// ============================================================
// SLIDE 6 — CAPITAL FLOOR + ARLINGTON PREF
// ============================================================
const s6 = pres.addSlide();
s6.background = { color: C.cream };

eyebrow(s6, 'LP PROTECTION MECHANIC');
title(s6, 'Capital floor + Arlington pref preserved');
subtitle(s6, 'This is how we get clean consent signatures on rollup paperwork without anyone losing what was promised.');

// 3-column explainer
const protect = [
  {
    label: 'THE MECHANIC',
    title: 'Greater of equity or floor',
    detail: 'At exit, each LP receives the GREATER of (a) their pro-rata equity share in HoldCo, OR (b) their original investment back (plus pref where applicable). GGP absorbs any difference.',
  },
  {
    label: 'ARLINGTON SPECIFIC',
    title: '10% pref honored',
    detail: 'The original 10% per year preferred return commitment is honored as an extended floor. At year 5: $25K × 1.5 = $37.50K per Arlington LP. Simple interest. Floor exists for downside certainty.',
  },
  {
    label: 'COST TO GGP',
    title: 'Theoretical, not actual',
    detail: 'At any exit above ~$3M, equity shares dominate the floor. Real cost is zero. The floor is a peace-of-mind mechanic for LPs, not a real economic transfer at expected exits.',
  },
];

protect.forEach((p, i) => {
  const x = 0.6 + i * 4.1;
  s6.addShape('rect', {
    x, y: 2.1, w: 3.9, h: 4.5,
    fill: { color: C.white },
    line: { color: C.gold, width: 1 },
  });
  s6.addText(p.label, {
    x: x + 0.3, y: 2.3, w: 3.5, h: 0.3,
    fontFace: FB, fontSize: 10, color: C.goldDeep, bold: true, charSpacing: 3,
  });
  s6.addText(p.title, {
    x: x + 0.3, y: 2.65, w: 3.5, h: 1.0,
    fontFace: FD, fontSize: 20, color: C.ink, bold: true,
  });
  s6.addText(p.detail, {
    x: x + 0.3, y: 3.85, w: 3.5, h: 2.5,
    fontFace: FB, fontSize: 12, color: C.text, lineSpacingMultiple: 1.5,
  });
});

s6.addText('"We see you, and you remain protected." — the message to every existing LP, especially Arlington.', {
  x: 0.6, y: 7.0, w: 12.1, h: 0.4,
  fontFace: FB, fontSize: 13, color: C.muted, italic: true, align: 'center',
});

s6.addNotes(`This is the most important slide for the LP relationship. Walk through carefully.

The capital floor mechanic does THREE things:
1. Adds formal downside protection that did NOT exist in the original operating agreements (which had no waterfall)
2. Honors the Arlington 10% pref promise that was made informally at the time
3. Costs GGP literally nothing at any realistic exit because equity shares dominate

Critical message in every LP conversation: "We are introducing protections that you did not have, while preserving everything that was promised."

This is what gets us clean unanimous consent.`);

// ============================================================
// SLIDE 7 — SAFE TERMS
// ============================================================
const s7 = pres.addSlide();
s7.background = { color: C.ink };

s7.addText('THE SAFE WE ARE OPENING', {
  x: 0.6, y: 0.5, w: 12.1, h: 0.35,
  fontFace: FB, fontSize: 11, color: C.gold, bold: true, charSpacing: 4,
});

s7.addText('The terms', {
  x: 0.6, y: 0.95, w: 12.1, h: 0.7,
  fontFace: FD, fontSize: 36, color: C.cream, bold: true,
});

s7.addText('Same numbers UU has been working with. Pre-anchor conversation locked.', {
  x: 0.6, y: 1.65, w: 12.1, h: 0.4,
  fontFace: FB, fontSize: 14, color: C.goldSoft, italic: true,
});

// Big terms callout
s7.addShape('rect', {
  x: 0.6, y: 2.3, w: 12.1, h: 1.7,
  fill: { color: C.text },
  line: { color: C.gold, width: 2 },
});
s7.addText('$1M round · $2M post-money cap · 20% discount · MFN', {
  x: 0.85, y: 2.55, w: 11.6, h: 1.2,
  fontFace: FD, fontSize: 30, color: C.cream, bold: true, valign: 'middle',
});

// 4 detail columns
const terms = [
  { l: 'INSTRUMENT', v: 'SAFE (Y Combinator post-money template)' },
  { l: 'STRUCTURE', v: '$500K anchor + $500K pool in $30K+ checks' },
  { l: 'CONVERSION', v: 'Series A within 6-12 months · greater-of cap or discount' },
  { l: 'TIMING', v: 'Anchor commit unlocks pool · MFN protects timing' },
];
terms.forEach((t, i) => {
  const x = 0.6 + i * 3.05;
  s7.addText(t.l, {
    x, y: 4.3, w: 2.85, h: 0.3,
    fontFace: FB, fontSize: 10, color: C.gold, bold: true, charSpacing: 3,
  });
  s7.addText(t.v, {
    x, y: 4.6, w: 2.85, h: 1.3,
    fontFace: FB, fontSize: 13, color: 'D4C09B', lineSpacingMultiple: 1.4,
  });
});

// Why $2M cap defense
s7.addShape('rect', {
  x: 0.6, y: 6.1, w: 12.1, h: 1.1,
  fill: { color: C.text },
  line: { color: C.gold, width: 0 },
});
s7.addText('WHY $2M CAP IS RIGHT FOR THIS STAGE', {
  x: 0.85, y: 6.2, w: 11.6, h: 0.3,
  fontFace: FB, fontSize: 10, color: C.gold, bold: true, charSpacing: 3,
});
s7.addText('Our current aggregate value is $1.20M. A $2M post-money cap = 1.7× current value — fair forward premium for 12 months of platform-building. Series A target ($4M pre) is 3.3× current, so SAFE investors get meaningful discount via the cap. Above $3M cap, the SAFE conversion math breaks (cap stops protecting). Below $1.5M, we give away too much. $2M is the right window.', {
  x: 0.85, y: 6.5, w: 11.6, h: 0.65,
  fontFace: FB, fontSize: 11.5, color: C.cream, lineSpacingMultiple: 1.4,
});

s7.addNotes(`This is where to spend time aligning. The terms work — but only if we walk into the anchor conversation with absolute conviction.

The cap is the negotiation point. If the anchor pushes back asking for a lower cap ($1.5M, $1.2M), we have to know our floor. My recommendation: $2M is the lowest we should accept. If they want lower, walk away or take a smaller check.

If anchor offers higher cap ($2.5-3M) in exchange for more committed dollars or better terms (e.g., right-of-first-look on Series A pricing), consider it — but only if it's a real strategic relationship, not just a financial check.

Decisions to lock:
1. Are we both 100% comfortable with $2M cap as the entry point?
2. Are we okay if the anchor pushes higher (to $2.5M)?
3. What's our walk-away point if anchor pushes lower?`);

// ============================================================
// SLIDE 8 — SERIES A PATH
// ============================================================
const s8 = pres.addSlide();
s8.background = { color: C.white };

eyebrow(s8, 'NEXT MILESTONE');
title(s8, 'Series A — 6 to 12 months out');
subtitle(s8, 'What we have to be by then. What it costs us to get there.');

// Two columns: target Series A vs what we need to be
s8.addText('SERIES A TARGET', {
  x: 0.6, y: 2.1, w: 5.95, h: 0.3,
  fontFace: FB, fontSize: 10, color: C.goldDeep, bold: true, charSpacing: 3,
});
s8.addText('WHAT WE HAVE TO BE', {
  x: 6.75, y: 2.1, w: 5.95, h: 0.3,
  fontFace: FB, fontSize: 10, color: C.goldDeep, bold: true, charSpacing: 3,
});

// Left column - Series A target
const seriesA = [
  ['Raise size', '$1M'],
  ['Pre-money valuation', '$4M'],
  ['Post-money', '$5M'],
  ['Series A investor takes', '20%'],
  ['SAFE converts at', '$2M cap'],
  ['SAFE pool ends at', '20% post-A'],
];
seriesA.forEach((row, i) => {
  const y = 2.5 + i * 0.55;
  s8.addShape('rect', {
    x: 0.6, y, w: 5.95, h: 0.45,
    fill: { color: i % 2 ? C.cream : C.white },
    line: { color: C.card, width: 0.5 },
  });
  s8.addText(row[0], {
    x: 0.8, y, w: 3.5, h: 0.45,
    fontFace: FB, fontSize: 12, color: C.text, valign: 'middle',
  });
  s8.addText(row[1], {
    x: 4.3, y, w: 2.0, h: 0.45,
    fontFace: FM, fontSize: 13, color: C.goldDeep, bold: true, align: 'right', valign: 'middle',
  });
});

// Right column - what we need to be
const milestones = [
  ['Shops operating', '9-11'],
  ['Gross ARR run-rate', '$2.5-3.5M'],
  ['Jonathan onboarded', 'Yes'],
  ['Bookkeeping verified', 'Yes'],
  ['Kitchen operational', 'Yes (or near)'],
  ['FDD work begun', 'Yes'],
];
milestones.forEach((row, i) => {
  const y = 2.5 + i * 0.55;
  s8.addShape('rect', {
    x: 6.75, y, w: 5.95, h: 0.45,
    fill: { color: i % 2 ? C.cream : C.white },
    line: { color: C.card, width: 0.5 },
  });
  s8.addText(row[0], {
    x: 6.95, y, w: 3.5, h: 0.45,
    fontFace: FB, fontSize: 12, color: C.text, valign: 'middle',
  });
  s8.addText(row[1], {
    x: 10.45, y, w: 2.0, h: 0.45,
    fontFace: FM, fontSize: 13, color: C.goldDeep, bold: true, align: 'right', valign: 'middle',
  });
});

s8.addText('If we hit these milestones, Series A at $4M pre is conservative. We could likely price $8-12M pre on real traction. But $4M is our floor target.', {
  x: 0.6, y: 6.4, w: 12.1, h: 0.7,
  fontFace: FB, fontSize: 13, color: C.text, italic: true, align: 'center', lineSpacingMultiple: 1.4,
});

s8.addNotes(`This is the bridge between SAFE and Series A. We have to be specific about what we are by the time Series A happens, because that determines the cap and the round size.

Critical milestones:
- 9-11 shops (3-4 more acquisitions in next 12 months)
- $2.5-3.5M gross ARR
- Jonathan onboarded as ops manager
- Verified financials
- Kitchen operational
- FDD work begun (signals franchise readiness)

If we hit these, we could price Series A at $8-12M pre. We're holding $4M as our floor because it's the most conservative number that still makes the SAFE math work.

Decisions to lock:
1. Are these milestones realistic on a 12-month timeline?
2. Do we want to commit to specific acquisition counts in writing?
3. What's our backup plan if Series A doesn't price as expected?`);

// ============================================================
// SLIDE 9 — SEQUENCING
// ============================================================
const s9 = pres.addSlide();
s9.background = { color: C.cream };

eyebrow(s9, 'THE NEXT 12 MONTHS');
title(s9, 'Sequencing');
subtitle(s9, 'Real timelines, not Twitter timelines. Roll-up done right.');

const phases = [
  { period: 'MONTH 1', focus: 'Form Delaware HoldCo as shell. Engage counsel + bookkeeper. Send accreditation questionnaires to all 14 LPs. SAFE closes into shell. First proceeds released.' },
  { period: 'MONTHS 2-4', focus: 'Founder-funded shops (Bluemound, Carrollton, Dallas) roll in first — no LP consents needed. §721 contribution. Founder $30K note converts to equity. Jonathan hire commences.' },
  { period: 'MONTHS 3-6', focus: 'LP consent process — Arl/NRH first, FW second, Grapevine third. Capital floor + pref preserved. Soft conversations before paperwork. Counsel walks LPs through OA.' },
  { period: 'MONTHS 6-10', focus: 'LP-shop roll-ins execute as consents complete. Kitchen build begins. FDD work commences. HoldCo Operating Agreement finalized (drag-along, ROFR, MIP terms).' },
  { period: 'MONTHS 10-12', focus: 'Remaining Grapevine $60K raised at HoldCo level. Series A pitch ready. Bookkeeping verified. Q1 2027 close on Series A timeline.' },
];

phases.forEach((p, i) => {
  const y = 2.1 + i * 0.85;
  s9.addShape('rect', {
    x: 0.6, y, w: 2.0, h: 0.75,
    fill: { color: C.ink },
    line: { color: C.gold, width: 1 },
  });
  s9.addText(p.period, {
    x: 0.6, y, w: 2.0, h: 0.75,
    fontFace: FM, fontSize: 13, color: C.gold, bold: true, align: 'center', valign: 'middle',
  });
  s9.addShape('rect', {
    x: 2.75, y, w: 9.95, h: 0.75,
    fill: { color: C.white },
    line: { color: C.gold, width: 0.5 },
  });
  s9.addText(p.focus, {
    x: 2.95, y, w: 9.7, h: 0.75,
    fontFace: FB, fontSize: 11, color: C.text, valign: 'middle', lineSpacingMultiple: 1.3,
  });
});

s9.addNotes(`This is honest sequencing. Most roll-ups pretend they happen in 30-60 days. They don't. They take 6-12 months done right.

The shell HoldCo first matters: it lets SAFE close immediately, gives us counsel-level structure, and we don't have to wait for every consent before deploying capital.

Founder-funded shops first: easiest, no consents needed. Establishes the §721 mechanic and proves it works before going to LPs.

LP consents 3-6 months: each cohort gets its own conversation. Soft outreach before paperwork. We pay for their counsel review if they want one.

Series A close at month 12: realistic, not aspirational. If we close earlier, great. If it slips to month 15, we have runway.

Decisions to lock:
1. Is 6-12 month timeline acceptable?
2. Who owns LP outreach for each cohort?
3. What happens if any LP says no?`);

// ============================================================
// SLIDE 10 — OPEN ITEMS
// ============================================================
const s10 = pres.addSlide();
s10.background = { color: C.white };

eyebrow(s10, 'WHAT WE NEED TO DECIDE TODAY');
title(s10, 'Open items');
subtitle(s10, 'These are the questions we should NOT have for the first time in front of an investor.');

const opens = [
  { num: '01', q: 'Lam — advisor pool at 1% or MIP at 1%?', context: 'Defaulted to advisor based on "mutual-aid / part-time" framing. If Lam is on payroll as employee, she belongs in MIP. Decision driver: is she an outside contributor or a team member?' },
  { num: '02', q: 'Advisor reserve at 6% — keep, increase, or decrease?', context: 'Sized for 2-4 institutional board advisors at 1-3% each before Series A. If we want to recruit more aggressively (e.g., bring in a former Krispy Kreme or Mochinut exec), 8-10% reserve makes sense.' },
  { num: '03', q: 'Pheak at 2% MIP — comfortable or undershooting?', context: 'She is foundational to the bakery operation. Some platform plays would put master baker at 3-4%. We chose 2% to keep MIP narrow. Right call or revisit?' },
  { num: '04', q: 'Max at 5% — formalizing informal arrangement?', context: 'Max was informally part of the team. Formalizing at HoldCo. Need to confirm with Max directly that 5% feels right to him and signals his commitment level.' },
  { num: '05', q: 'Grapevine remaining $60K — confirmed as HoldCo SAFE raise?', context: 'Two of four LPs in Grapevine have not wired. Plan: do NOT backfill at original terms; raise the missing $60K at HoldCo level via SAFE participants instead. Locks the cap table cleaner.' },
  { num: '06', q: 'Youyou full-time transition — at HoldCo formation?', context: 'Currently SVP at consulting firm. Investor conversation will surface this immediately. Plan: full-time transition at HoldCo formation, funded by SAFE proceeds. Confirm timing.' },
];

opens.forEach((o, i) => {
  const x = 0.6 + (i % 2) * 6.1;
  const y = 2.1 + Math.floor(i / 2) * 1.7;
  s10.addShape('rect', {
    x, y, w: 5.9, h: 1.55,
    fill: { color: i % 2 === 0 ? C.cream : C.white },
    line: { color: C.gold, width: 1 },
  });
  s10.addText(o.num, {
    x: x + 0.25, y: y + 0.2, w: 0.7, h: 0.4,
    fontFace: FM, fontSize: 18, color: C.goldDeep, bold: true,
  });
  s10.addText(o.q, {
    x: x + 1.0, y: y + 0.2, w: 4.7, h: 0.5,
    fontFace: FD, fontSize: 13, color: C.ink, bold: true,
  });
  s10.addText(o.context, {
    x: x + 1.0, y: y + 0.7, w: 4.7, h: 0.8,
    fontFace: FB, fontSize: 10.5, color: C.text, lineSpacingMultiple: 1.4,
  });
});

s10.addNotes(`These are the decisions we leave the room with. Walk through each one.

Priority order:
1. Lam tier (affects cap table)
2. Advisor reserve size (affects cap table)
3. Pheak %  (affects MIP)
4. Max 5% confirmation (affects founder bucket)
5. Grapevine plan (affects rollup paperwork)
6. UU full-time timing (affects investor narrative)

If we can't agree on any of these in this session, schedule a follow-up before sending the deck to investors. We should not paper over disagreements.`);

// ============================================================
// SLIDE 11 — 30-DAY ACTION LIST
// ============================================================
const s11 = pres.addSlide();
s11.background = { color: C.cream };

eyebrow(s11, 'WHAT EACH OF US OWNS · NEXT 30 DAYS');
title(s11, 'The action list');
subtitle(s11, 'No general commitments. Specific tasks, owners, dates.');

const actions = [
  { owner: 'BOTH', wk: 'W1', task: 'Read strategy doc end-to-end. Mark up. Final cap table sign-off in this session.' },
  { owner: 'JACK', wk: 'W1', task: 'Engage corporate counsel for Delaware HoldCo formation. Get fee estimate.' },
  { owner: 'UU',   wk: 'W1', task: 'Engage fractional bookkeeper for April + May 2026 close. Verify gross/net split.' },
  { owner: 'UU',   wk: 'W1-2', task: 'Send accreditation questionnaires to all 14 LPs (template from counsel).' },
  { owner: 'UU',   wk: 'W2', task: 'Soft outreach calls to 2-3 Arlington LPs. Test the capital floor + pref message.' },
  { owner: 'BOTH', wk: 'W2', task: 'Finalize SAFE term sheet for anchor. Reviewed by counsel.' },
  { owner: 'JACK', wk: 'W2-3', task: 'First conversation with anchor SAFE investor. UU joins for technical questions.' },
  { owner: 'UU',   wk: 'W3', task: 'Personalize LP letter for each of 14 LPs. Customize bracketed fields.' },
  { owner: 'BOTH', wk: 'W3', task: 'Send personalized LP letters with 30-min call offer.' },
  { owner: 'BOTH', wk: 'W4', task: 'HoldCo legally formed. Open bank account. Securities counsel engaged.' },
];

const ownerColor = { UU: C.green, JACK: C.gold, BOTH: C.goldDeep };

actions.forEach((a, i) => {
  const y = 2.1 + i * 0.45;
  s11.addShape('rect', {
    x: 0.6, y, w: 12.1, h: 0.4,
    fill: { color: i % 2 ? C.white : C.cream },
    line: { color: C.card, width: 0.3 },
  });
  s11.addText(a.owner, {
    x: 0.7, y, w: 1.2, h: 0.4,
    fontFace: FM, fontSize: 12, color: ownerColor[a.owner], bold: true, valign: 'middle', align: 'center',
  });
  s11.addText(a.wk, {
    x: 2.0, y, w: 0.9, h: 0.4,
    fontFace: FM, fontSize: 12, color: C.muted, bold: true, valign: 'middle', align: 'center',
  });
  s11.addText(a.task, {
    x: 3.0, y, w: 9.5, h: 0.4,
    fontFace: FB, fontSize: 12, color: C.text, valign: 'middle',
  });
});

s11.addNotes(`This is the close-out. Walk through line by line. Confirm each owner. Add dates.

Critical first-week items:
1. Both: agree on final cap table (this session)
2. Jack: engage corporate counsel — without legal we cannot form HoldCo
3. UU: engage bookkeeper — without verified financials we cannot defend revenue at diligence
4. UU: send accreditation questionnaires — free and required, do it first

Anchor conversation in week 2-3 means we need everything else done first.

The LP outreach is the longest-running workstream — 30 days to send letters, then 30-60 days for soft conversations before paperwork.`);

// ============================================================
// SLIDE 12 — DECISIONS CHECKLIST
// ============================================================
const s12 = pres.addSlide();
s12.background = { color: C.ink };

s12.addText('LEAVING THE ROOM', {
  x: 0.6, y: 0.5, w: 12.1, h: 0.35,
  fontFace: FB, fontSize: 11, color: C.gold, bold: true, charSpacing: 4,
});

s12.addText('What we walk out with', {
  x: 0.6, y: 0.95, w: 12.1, h: 0.7,
  fontFace: FD, fontSize: 36, color: C.cream, bold: true,
});

s12.addText('Six checkboxes. Each one signed off means we are ready for the anchor conversation.', {
  x: 0.6, y: 1.65, w: 12.1, h: 0.4,
  fontFace: FB, fontSize: 14, color: C.goldSoft, italic: true,
});

const decisions = [
  'Cap table is locked at the GGP table on slide 4 (Founders 80%, Active 6%, Advisors 14%)',
  'MIP at 10% with Pheak 2% allocated, 8% reserved for executive hires',
  'SAFE terms locked at $1M / $2M cap / 20% discount / MFN',
  'Series A target locked at $1M raise / $4M pre-money / 6-12 months out',
  '30-day action list is owned, dated, and shared between us',
  'Open items (Lam, advisor reserve, Pheak %, Max 5%, Grapevine, UU timing) closed',
];

decisions.forEach((d, i) => {
  const y = 2.3 + i * 0.75;
  s12.addShape('rect', {
    x: 0.6, y, w: 12.1, h: 0.65,
    fill: { color: C.text },
    line: { color: C.gold, width: 1 },
  });
  s12.addShape('rect', {
    x: 0.85, y: y + 0.18, w: 0.3, h: 0.3,
    fill: { color: C.text },
    line: { color: C.gold, width: 2 },
  });
  s12.addText(d, {
    x: 1.45, y, w: 11.0, h: 0.65,
    fontFace: FB, fontSize: 14, color: C.cream, valign: 'middle',
  });
});

s12.addNotes(`The close. Print this slide. Check the boxes as we go.

If any box is empty at the end of the session, we are NOT ready for the anchor conversation. Schedule a follow-up.

If all six are checked, we send the investor pitch deck within 7 days.

Last thing to confirm before ending: how do we communicate decisions to the rest of the team? Peiyun, Max, Muypin all need to know what we landed on. Slack post? Group call? Recap memo? Decide.`);

// SAVE
pres.writeFile({ fileName: '/home/claude/gg-package/docs/00-Internal-Walkthrough-for-Jack.pptx' })
  .then(() => console.log('✓ Internal walkthrough deck built'));
