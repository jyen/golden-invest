const fs = require('fs');
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, PageOrientation, LevelFormat,
  BorderStyle, WidthType, ShadingType, HeadingLevel, PageNumber, PageBreak
} = require('docx');

const GOLD = '8B6E10';
const GOLD_DEEP = 'A87618';
const INK = '1A1208';
const TEXT = '4A3825';
const MUTED = '8B6E3D';
const CREAM_BG = 'FAF6EA';
const CARD_BG = 'F8EFD7';
const BORDER = 'D4C09B';

const border = { style: BorderStyle.SINGLE, size: 4, color: BORDER };
const borders = { top: border, bottom: border, left: border, right: border };

// Helpers
const H1 = (text) => new Paragraph({
  heading: HeadingLevel.HEADING_1,
  spacing: { before: 360, after: 180 },
  children: [new TextRun({ text, bold: true, size: 36, color: INK, font: 'Calibri' })]
});

const H2 = (text) => new Paragraph({
  heading: HeadingLevel.HEADING_2,
  spacing: { before: 280, after: 140 },
  children: [new TextRun({ text, bold: true, size: 28, color: INK, font: 'Calibri' })]
});

const H3 = (text) => new Paragraph({
  heading: HeadingLevel.HEADING_3,
  spacing: { before: 200, after: 100 },
  children: [new TextRun({ text, bold: true, size: 22, color: GOLD_DEEP, font: 'Calibri' })]
});

const P = (text, opts = {}) => new Paragraph({
  spacing: { before: 80, after: 80, line: 320 },
  children: [new TextRun({ text, size: 22, color: TEXT, font: 'Calibri', ...opts })]
});

const Eyebrow = (text) => new Paragraph({
  spacing: { before: 120, after: 80 },
  children: [new TextRun({ text, bold: true, size: 18, color: GOLD_DEEP, font: 'Calibri', allCaps: true })]
});

const Bold = (text) => new TextRun({ text, bold: true, size: 22, color: INK, font: 'Calibri' });
const Plain = (text) => new TextRun({ text, size: 22, color: TEXT, font: 'Calibri' });
const Mono = (text) => new TextRun({ text, size: 22, color: GOLD_DEEP, font: 'Consolas', bold: true });

const Bullet = (text, opts = {}) => new Paragraph({
  numbering: { reference: 'bullets', level: 0 },
  spacing: { before: 60, after: 60, line: 300 },
  children: [new TextRun({ text, size: 22, color: TEXT, font: 'Calibri', ...opts })]
});

const Mixed = (...runs) => new Paragraph({
  spacing: { before: 80, after: 80, line: 320 },
  children: runs
});

const Cell = (text, opts = {}) => new TableCell({
  borders,
  width: { size: opts.width || 2340, type: WidthType.DXA },
  shading: opts.shade ? { fill: opts.shade, type: ShadingType.CLEAR, color: 'auto' } : undefined,
  margins: { top: 100, bottom: 100, left: 140, right: 140 },
  children: [new Paragraph({
    alignment: opts.align || AlignmentType.LEFT,
    children: [new TextRun({
      text,
      bold: opts.bold || false,
      size: opts.size || 20,
      color: opts.color || TEXT,
      font: opts.mono ? 'Consolas' : 'Calibri'
    })]
  })]
});

const HCell = (text, width) => Cell(text, { width, bold: true, size: 18, color: INK, shade: CARD_BG, align: AlignmentType.LEFT });

// Build the document
const children = [
  // Cover
  new Paragraph({
    spacing: { before: 600, after: 0 },
    children: [new TextRun({ text: 'STRATEGIC MEMORANDUM', bold: true, size: 22, color: GOLD_DEEP, font: 'Calibri', allCaps: true })]
  }),
  new Paragraph({
    spacing: { before: 100, after: 100 },
    children: [new TextRun({ text: 'Golden Glaze Holdings', bold: true, size: 56, color: INK, font: 'Calibri' })]
  }),
  new Paragraph({
    spacing: { before: 0, after: 600 },
    children: [new TextRun({ text: 'The roll-up, the team, the path to exit.', italics: true, size: 28, color: MUTED, font: 'Calibri' })]
  }),
  new Paragraph({
    spacing: { before: 200, after: 80 },
    children: [new TextRun({ text: 'PREPARED FOR', bold: true, size: 18, color: GOLD_DEEP, font: 'Calibri', allCaps: true })]
  }),
  new Paragraph({
    spacing: { before: 0, after: 240 },
    children: [new TextRun({ text: 'Jack Wong — Founder & CEO', size: 26, color: INK, font: 'Calibri', bold: true })]
  }),
  new Paragraph({
    spacing: { before: 200, after: 80 },
    children: [new TextRun({ text: 'PREPARED BY', bold: true, size: 18, color: GOLD_DEEP, font: 'Calibri', allCaps: true })]
  }),
  new Paragraph({
    spacing: { before: 0, after: 240 },
    children: [new TextRun({ text: 'Youyou — Co-founder & COO', size: 26, color: INK, font: 'Calibri', bold: true })]
  }),
  new Paragraph({
    spacing: { before: 200, after: 80 },
    children: [new TextRun({ text: 'PURPOSE', bold: true, size: 18, color: GOLD_DEEP, font: 'Calibri', allCaps: true })]
  }),
  new Paragraph({
    spacing: { before: 0, after: 200 },
    children: [new TextRun({ text: 'Aligned walkthrough of the rollup architecture, cap table, and capital strategy before approaching the $500K anchor SAFE investor and finalizing structure with counsel. This memo captures every decision made through May 2026 and the open items requiring sign-off.', size: 22, color: TEXT, font: 'Calibri' })]
  }),
  new Paragraph({ children: [new PageBreak()] }),

  // Executive Summary
  H1('1 · Executive Summary'),
  P('Golden Glaze Donuts is a 7-shop specialty bakery roll-up across the Dallas-Fort Worth area, acquired between September 2025 and April 2026. Current net annual run-rate is approximately $1.31M (estimated gross $1.5M before merchant fees). Aggregate shop-level valuation is $1.20M, conservatively struck at 0.83-0.92× annual revenue to ensure defensibility at PE diligence.'),
  P('The strategic objective is to consolidate the seven separate LLCs into a single Delaware HoldCo, raise $300K via SAFE to fund legal formation and growth, and complete a $1M Series A within 6-12 months. The 4-year exit target is $80-120M; the 7-year Shipley-scale target is $200-400M.'),
  P('This memo documents every structural decision made, identifies the open items requiring final founder sign-off, and frames the capital strategy in terms of real QSR comparables (Mochinut, Krispy Kreme, Dave\'s Hot Chicken, Cava, Sweetgreen, Shipley Do-Nuts).'),

  Eyebrow('The headline numbers'),
  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [3120, 3120, 3120],
    rows: [
      new TableRow({ children: [
        HCell('Metric', 3120), HCell('Current', 3120), HCell('Year 4 Target', 3120)
      ]}),
      new TableRow({ children: [
        Cell('Shops', { width: 3120 }), Cell('7', { width: 3120, bold: true, mono: true, color: GOLD_DEEP }), Cell('25-35', { width: 3120, bold: true, mono: true, color: GOLD_DEEP })
      ]}),
      new TableRow({ children: [
        Cell('Gross ARR', { width: 3120 }), Cell('~$1.5M', { width: 3120, bold: true, mono: true, color: GOLD_DEEP }), Cell('$10-15M', { width: 3120, bold: true, mono: true, color: GOLD_DEEP })
      ]}),
      new TableRow({ children: [
        Cell('Aggregate value', { width: 3120 }), Cell('$1.20M', { width: 3120, bold: true, mono: true, color: GOLD_DEEP }), Cell('$80-120M', { width: 3120, bold: true, mono: true, color: GOLD_DEEP })
      ]}),
      new TableRow({ children: [
        Cell('LP cash deployed', { width: 3120 }), Cell('$380K', { width: 3120, bold: true, mono: true, color: GOLD_DEEP }), Cell('n/a (HoldCo)', { width: 3120, mono: true })
      ]}),
      new TableRow({ children: [
        Cell('Capital raised', { width: 3120 }), Cell('$0 (institutional)', { width: 3120, mono: true }), Cell('$1.3M+ (SAFE + Series A)', { width: 3120, bold: true, mono: true, color: GOLD_DEEP })
      ]}),
    ]
  }),

  new Paragraph({ children: [new PageBreak()] }),

  // Section 2: Current State
  H1('2 · Current State'),
  H2('2.1 The Portfolio'),
  P('Seven shops acquired across DFW in an 8-month window. Each shop was purchased as a distressed or under-performing donut shop and stabilized through operational turnaround — recipe upgrade, staff training, hours optimization, and brand cleanup.'),

  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [1560, 1560, 1560, 1560, 1560, 1560],
    rows: [
      new TableRow({ children: [
        HCell('Shop', 1560), HCell('Acquired', 1560), HCell('MRR Now (net)', 1560), HCell('Type', 1560), HCell('LP Count', 1560), HCell('Valuation', 1560)
      ]}),
      new TableRow({ children: [
        Cell('Arlington', { width: 1560, bold: true }), Cell('Sep 2025', { width: 1560 }), Cell('$30K', { width: 1560, mono: true }), Cell('LP-funded', { width: 1560 }), Cell('8 of 8', { width: 1560, mono: true }), Cell('$330K', { width: 1560, bold: true, mono: true, color: GOLD_DEEP })
      ]}),
      new TableRow({ children: [
        Cell('NRH (Rufe Snow)', { width: 1560, bold: true }), Cell('Sep 2025', { width: 1560 }), Cell('$11K', { width: 1560, mono: true }), Cell('Joint w/ Arl', { width: 1560 }), Cell('shared', { width: 1560, mono: true }), Cell('$110K', { width: 1560, bold: true, mono: true, color: GOLD_DEEP })
      ]}),
      new TableRow({ children: [
        Cell('Fort Worth', { width: 1560, bold: true }), Cell('Oct 2025', { width: 1560 }), Cell('$22.5K', { width: 1560, mono: true }), Cell('LP-funded', { width: 1560 }), Cell('4 of 4', { width: 1560, mono: true }), Cell('$230K', { width: 1560, bold: true, mono: true, color: GOLD_DEEP })
      ]}),
      new TableRow({ children: [
        Cell('Grapevine', { width: 1560, bold: true }), Cell('Nov 2025', { width: 1560 }), Cell('$18K', { width: 1560, mono: true }), Cell('LP-funded', { width: 1560 }), Cell('2 of 4', { width: 1560, mono: true, color: 'B85042', bold: true }), Cell('$190K', { width: 1560, bold: true, mono: true, color: GOLD_DEEP })
      ]}),
      new TableRow({ children: [
        Cell('Carrollton', { width: 1560, bold: true }), Cell('Feb 2026', { width: 1560 }), Cell('$10K', { width: 1560, mono: true }), Cell('Founder-funded', { width: 1560 }), Cell('—', { width: 1560 }), Cell('$140K', { width: 1560, bold: true, mono: true, color: GOLD_DEEP })
      ]}),
      new TableRow({ children: [
        Cell('Dallas (Frankford)', { width: 1560, bold: true }), Cell('Feb 2026', { width: 1560 }), Cell('$10K', { width: 1560, mono: true }), Cell('Founder-funded', { width: 1560 }), Cell('—', { width: 1560 }), Cell('$120K', { width: 1560, bold: true, mono: true, color: GOLD_DEEP })
      ]}),
      new TableRow({ children: [
        Cell('Bluemound', { width: 1560, bold: true }), Cell('Apr 2026', { width: 1560 }), Cell('$8K', { width: 1560, mono: true }), Cell('Founder-funded', { width: 1560 }), Cell('—', { width: 1560 }), Cell('$80K', { width: 1560, bold: true, mono: true, color: GOLD_DEEP })
      ]}),
      new TableRow({ children: [
        Cell('TOTAL', { width: 1560, bold: true, shade: CARD_BG }), Cell('—', { width: 1560, shade: CARD_BG }), Cell('$109.5K/mo', { width: 1560, bold: true, mono: true, shade: CARD_BG }), Cell('—', { width: 1560, shade: CARD_BG }), Cell('14 LPs', { width: 1560, bold: true, mono: true, shade: CARD_BG }), Cell('$1.20M', { width: 1560, bold: true, mono: true, color: GOLD_DEEP, shade: CARD_BG })
      ]}),
    ]
  }),

  Eyebrow('Notes on the table'),
  Bullet('Grapevine has only 2 of 4 LPs wired ($60K of expected $120K). The remaining $60K of capacity is open — recommended action: do NOT backfill at original terms; raise the missing $60K at HoldCo level (SAFE participants instead of late LPs).'),
  Bullet('Net MRR is after merchant fees, processing, and platform commissions. Gross top-line is estimated 10-20% higher (~$126K/mo, $1.5M ARR). Final gross figures pending May close verification.'),
  Bullet('Valuations are user-set conservative numbers at 0.83-0.92× annual revenue for LP-funded shops, 1.0-1.17× for newer founder-funded shops. Defensible at PE diligence; deliberately leaves upside for SAFE investors.'),

  H2('2.2 The LP Capital Base'),
  P('Fourteen passive limited partners have collectively contributed $380K in cash across three shop-level LLCs:'),
  Mixed(Bold('Arlington/NRH joint LLC: '), Plain('8 LPs × $25K = $200K. Additional commitment: 10% per year preferred return (informal, original deal term).')),
  Mixed(Bold('Fort Worth LLC: '), Plain('4 LPs × $30K = $120K. No pref commitment.')),
  Mixed(Bold('Grapevine LLC: '), Plain('2 of 4 LPs × $30K = $60K wired so far. Remaining $60K of capacity open. No pref commitment.')),
  P('UU + Jack additionally lent $30K combined ($15K each) as a note to the Arl/NRH joint LLC because the round under-funded. This note will be converted to founder equity at HoldCo formation (decision made — see Section 4.2).'),
  P('Bluemound, Carrollton, and Dallas are 100% founder-funded by UU + Jack. No LPs in those shops. The founder cash contribution is captured by treating UU + Jack as the "LPs" of those three shops in the rollup structure (see Section 4.3).'),

  H2('2.3 The Team'),
  P('Twenty-eight-plus people across four tiers: founders, active operating partner, strategic advisors, and shop-level operators.'),
  Bullet('Four founders (combined 80% of GGP): Jack (CEO, 25%), Youyou (COO, 35%), Peiyun (Engineering, 15%), Max (Analysis, 5%)'),
  Bullet('One active operating partner (6%): Muypin — full-time donut operations across all shops'),
  Bullet('Four strategic advisors (8% allocated, 6% reserved for institutional-grade hires): Luke (3% — strategy), Chanda (2% — FOH ops), Jonathan (2% — incoming ops manager), Lam (1% — bakery)'),
  Bullet('MIP (10% pool): Pheak 2% allocated (master baker, full-time); 8% reserved for CFO, COO, CMO, and GM hires through Series A'),
  Bullet('Shop teams: 18+ across 7 stores including bakers, FOH staff, and one floating team member (Yangzhou) across Carrollton and Dallas'),

  new Paragraph({ children: [new PageBreak()] }),

  // Section 3: The Rollup
  H1('3 · The Roll-Up Strategy'),
  H2('3.1 Why we have to do this now'),
  P('The seven shop-LLC structure is fine for early operation but becomes a dealbreaker the moment we approach institutional capital. Specifically:'),
  Bullet('A Series A investor will not write to seven separate LLCs.'),
  Bullet('A strategic or PE buyer pays one wire to one entity; fragmented structures get discounted 20-30% in M&A pricing.'),
  Bullet('Shared services (centralized kitchen, brand, Golden POS) need a single parent.'),
  Bullet('Securities compliance and accreditation tracking is impractical across 14 LPs in three separate vehicles.'),
  P('§721 of the IRC allows tax-free contribution of LLC interests into a partnership. Done correctly, the rollup itself triggers no tax event for any LP — a major selling point in our consent conversations.'),

  H2('3.2 Target Structure — One HoldCo, Three Cap Table Lines'),
  P('Golden Glaze Holdings LLC (Delaware) — formed as a shell entity in Month 1 of the rollup. The shell exists to receive the SAFE and to serve as the parent for subsidiary roll-ins as they complete consent processes over Months 2-12.'),
  P('Approximate post-rollup ownership (before SAFE/Series A dilution):'),

  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [3120, 1560, 4680],
    rows: [
      new TableRow({ children: [
        HCell('Line', 3120), HCell('% of HoldCo', 1560), HCell('Composition', 4680)
      ]}),
      new TableRow({ children: [
        Cell('GGP (Operators)', { width: 3120, bold: true }), Cell('~50%', { width: 1560, bold: true, mono: true, color: GOLD_DEEP }), Cell('6 partners pooled — founders + active operating partner + strategic advisors', { width: 4680 })
      ]}),
      new TableRow({ children: [
        Cell('Passive SPV (LPs)', { width: 3120, bold: true }), Cell('~36%', { width: 1560, bold: true, mono: true, color: GOLD_DEEP }), Cell('14 LPs pooled into one line + UU/Jack as "LPs" of founder-funded shops', { width: 4680 })
      ]}),
      new TableRow({ children: [
        Cell('MIP Pool', { width: 3120, bold: true }), Cell('10% reserve', { width: 1560, bold: true, mono: true, color: GOLD_DEEP }), Cell('Pheak + executive hires (CFO/COO/CMO/GMs through Series A)', { width: 4680 })
      ]}),
      new TableRow({ children: [
        Cell('Founder note conversion', { width: 3120, bold: true }), Cell('~2.4%', { width: 1560, bold: true, mono: true, color: GOLD_DEEP }), Cell('$30K founder loan to Arl/NRH converts to equity at HoldCo formation', { width: 4680 })
      ]}),
      new TableRow({ children: [
        Cell('Total', { width: 3120, bold: true, shade: CARD_BG }), Cell('100%', { width: 1560, bold: true, mono: true, shade: CARD_BG }), Cell('Then dilutes by 10% MIP, ~15% SAFE, 20% Series A in sequence', { width: 4680, shade: CARD_BG })
      ]}),
    ]
  }),

  H2('3.3 Sequencing — 6 to 12 months end-to-end'),
  P('The shell HoldCo is formed first so it can issue the SAFE. Subsidiaries roll in over Months 2-12 as lender consents, landlord consents, and LP signatures clear individually.'),
  Bullet('Month 1: Form Golden Glaze Holdings LLC in Delaware. Counsel engaged. SAFE closes into HoldCo. Proceeds released to fund legal/formation costs.'),
  Bullet('Months 1-3: Send accreditation questionnaires to all 14 LPs. Critical for Reg D 506(b) compliance.'),
  Bullet('Months 2-4: Roll founder-funded shops (Bluemound, Carrollton, Dallas) into HoldCo first — no LP consents required, fastest path. §721 contribution.'),
  Bullet('Months 3-6: LP consent process for Arl/NRH, FW, Grapevine. Capital floor + Arlington 10% pref preserved as the protection mechanism.'),
  Bullet('Months 4-8: $30K founder note converts to equity at HoldCo formation.'),
  Bullet('Months 6-10: LP-shop rollups executed once consents complete. §721 contribution.'),
  Bullet('Months 8-12: HoldCo Operating Agreement finalized — drag-along, ROFR, capital floor, MIP terms.'),
  Bullet('Months 10-12: Remaining Grapevine $60K raised at HoldCo level (SAFE participants instead of late LPs at original terms).'),

  H2('3.4 Capital Floor + Arlington Pref'),
  P('The LP operating agreements as originally signed gave GGP 50% of each shop with no formal waterfall. Defensible while everyone is friendly, dangerous in a PE diligence room. We are introducing a capital floor mechanism to preserve LP protection and clean up the structure.'),
  Mixed(Bold('Mechanic at exit: '), Plain('Each LP receives the GREATER of (a) their pro-rata equity share in HoldCo, OR (b) their original investment plus accrued pref (where applicable). GGP absorbs any difference from the floor.')),
  Mixed(Bold('Arlington-specific: '), Plain('The 8 Arlington/NRH joint LLC LPs were promised a 10% per year preferred return at original deal time. This is honored as an extended floor — at year 5, the pref-adjusted floor is $37.50K per LP (simple interest, $25K × 1 + 10% × 5).')),
  Mixed(Bold('FW and Grapevine: '), Plain('No pref was promised. Their floor is their original $30K investment.')),
  Mixed(Bold('Why this matters at diligence: '), Plain('Institutional buyers want to see clean documentation that ALL stakeholders have certainty. The capital floor mechanic provides downside protection that did not exist formally, while giving us clean consent signatures on roll-up paperwork. The cost to GGP is theoretical at any exit valuation above ~$3M because equity shares dominate the floor.')),

  new Paragraph({ children: [new PageBreak()] }),

  // Section 4: Decisions Made
  H1('4 · Decisions Already Made'),
  P('Six structural decisions have been made through the strategy work to date. Each is now reflected in the HoldCo design and the cap table model.'),

  H2('4.1 Conservative Valuations'),
  P('Aggregate shop-level value is set at $1.20M, deliberately conservative at 0.83-0.92× annual revenue for the established LP-funded shops. Industry comparables from BizBuySell place donut shops at 0.37-0.78× revenue (median 0.50×). Our valuations are slightly above market median because of demonstrated turnaround performance, but well below where institutional buyers will eventually price us.'),
  Mixed(Bold('Strategic rationale: '), Plain('Conservative valuations strengthen our position with SAFE investors (they get more equity per dollar, better terms feel like) and with PE diligence (no inflated marks to defend). The valuation discipline becomes pricing power at Series A.')),

  H2('4.2 $30K Founder Note → Convert to Equity'),
  Mixed(
    Bold('Decision: '),
    Plain('The $30K combined founder loan ($15K each from UU and Jack to the Arl/NRH joint LLC) will be converted to founder equity at HoldCo formation. Not repaid from SAFE proceeds.')
  ),
  Mixed(Bold('Why: '), Plain('Option to repay from SAFE proceeds was rejected because it looks like founders cashing out, not investing. Converting to equity adds approximately 2.4% to the founder bucket at HoldCo, cleans the cap table of founder debt, and signals continued personal investment.')),

  H2('4.3 Founder-Funded Shops — Symmetric Structure'),
  P('Bluemound, Carrollton, and Dallas were 100% founder-funded. For the rollup, UU + Jack are treated as the "LPs" of those three shops:'),
  Bullet('50% of each shop\'s value goes to UU + Jack split 50-50 (mirroring the 50% LP slot in LP-funded shops)'),
  Bullet('50% of each shop\'s value goes to GGP (same as the operator slot in LP-funded shops — so all active partners benefit through their GGP positions)'),
  P('Contribution is at current fair market value, not historical acquisition cost. The founder advantage of finding distressed deals and negotiating low prices is captured automatically: founders put in less cash than the shop\'s current FMV, then receive equity equal to FMV.'),

  H2('4.4 GGP Three-Tier Structure'),
  P('GGP (Golden Glaze Operators LLC) holds the 50% operator slot in every shop. Equity inside GGP is permanent and non-vesting, distributed across four tiers:'),

  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [2340, 1170, 5850],
    rows: [
      new TableRow({ children: [HCell('Partner', 2340), HCell('% of GGP', 1170), HCell('Role / Justification', 5850)]}),
      new TableRow({ children: [Cell('Youyou', { width: 2340, bold: true, color: GOLD_DEEP }), Cell('35%', { width: 1170, bold: true, mono: true, color: GOLD_DEEP }), Cell('Co-founder, COO. Ops leadership across 7 shops, M&A pipeline, data infrastructure.', { width: 5850 })]}),
      new TableRow({ children: [Cell('Jack', { width: 2340, bold: true, color: GOLD_DEEP }), Cell('25%', { width: 1170, bold: true, mono: true, color: GOLD_DEEP }), Cell('Founder & CEO. Capital structure, investor relations, deal structuring.', { width: 5850 })]}),
      new TableRow({ children: [Cell('Peiyun', { width: 2340, bold: true, color: GOLD_DEEP }), Cell('15%', { width: 1170, bold: true, mono: true, color: GOLD_DEEP }), Cell('Co-founder, Engineering. Golden POS, customer loyalty, data infrastructure.', { width: 5850 })]}),
      new TableRow({ children: [Cell('Max', { width: 2340, bold: true, color: GOLD_DEEP }), Cell('5%', { width: 1170, bold: true, mono: true, color: GOLD_DEEP }), Cell('Co-founder, Analysis. Formalized at HoldCo from previously informal arrangement.', { width: 5850 })]}),
      new TableRow({ children: [Cell('Muypin', { width: 2340, bold: true }), Cell('6%', { width: 1170, bold: true, mono: true }), Cell('Active Operating Partner. Full-time donut operations across all shops. The only non-founder at owner-commitment level.', { width: 5850 })]}),
      new TableRow({ children: [Cell('Luke', { width: 2340, bold: true }), Cell('3%', { width: 1170, bold: true, mono: true }), Cell('Strategic Advisor — Strategy. Part-time at Verizon Innovation Lab.', { width: 5850 })]}),
      new TableRow({ children: [Cell('Chanda', { width: 2340, bold: true }), Cell('2%', { width: 1170, bold: true, mono: true }), Cell('Strategic Advisor — FOH Operations. Owns her own shop, mutual-aid arrangement.', { width: 5850 })]}),
      new TableRow({ children: [Cell('Jonathan', { width: 2340, bold: true }), Cell('2%', { width: 1170, bold: true, mono: true }), Cell('Strategic Advisor — Operations. 15+ yrs multi-unit production floor experience. Converts to MIP when hired full-time.', { width: 5850 })]}),
      new TableRow({ children: [Cell('Lam', { width: 2340, bold: true }), Cell('1%', { width: 1170, bold: true, mono: true }), Cell('Strategic Advisor — Bakery. 5+ years experience, part-time.', { width: 5850 })]}),
      new TableRow({ children: [Cell('Future advisors', { width: 2340, italics: true, color: MUTED }), Cell('6%', { width: 1170, bold: true, mono: true, color: MUTED }), Cell('Reserved for institutional-grade board advisors recruited before Series A.', { width: 5850, color: MUTED })]}),
      new TableRow({ children: [Cell('TOTAL', { width: 2340, bold: true, shade: CARD_BG }), Cell('100%', { width: 1170, bold: true, mono: true, shade: CARD_BG, color: GOLD_DEEP }), Cell('Founders 80% · Active 6% · Advisors 14%', { width: 5850, bold: true, shade: CARD_BG })]}),
    ]
  }),

  H2('4.5 MIP Pool — Narrow and Focused'),
  P('Ten percent of HoldCo reserved for vesting equity grants to full-time employees. Only 2% allocated currently (Pheak, master baker). Eight percent reserved for the institutional-grade executive hires we will need to recruit through Series A:'),
  Bullet('Pheak: 2% — Master Baker, working full-time. Allocated. Vesting 4-year with 1-year cliff.'),
  Bullet('Future hires bucket: 8% reserved for CFO, COO, CMO, and GMs. May absorb Jonathan (~1.5%) when he transitions from advisor to full-time Operations Manager.'),

  H2('4.6 Arlington 10% Preferred Return Preserved'),
  P('The 10% per year promise made to Arlington LPs at original deal time is honored through the rollup as an extended capital floor. The floor calculation is simple interest: $25K × (1 + 10% × years). At a 5-year hold to exit, the floor is $37.50K per Arlington LP. At any reasonable exit valuation, equity share will dominate the floor — meaning Arlington LPs receive more than $37.50K each. The floor exists to provide certainty in the very unlikely downside case.'),

  new Paragraph({ children: [new PageBreak()] }),

  // Section 5: Capital Strategy
  H1('5 · Capital Strategy'),
  H2('5.1 The $300K SAFE — Terms and Rationale'),
  P('Currently in discussion with an anchor investor for approximately $500K and pool participants for $30K+ checks. Recommended terms across the full round:'),
  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [2340, 7020],
    rows: [
      new TableRow({ children: [HCell('Term', 2340), HCell('Value / Rationale', 7020)]}),
      new TableRow({ children: [Cell('Instrument', { width: 2340, bold: true }), Cell('SAFE (Simple Agreement for Future Equity) — post-money, MFN clause, standard Y Combinator template', { width: 7020 })]}),
      new TableRow({ children: [Cell('Valuation cap', { width: 2340, bold: true }), Cell('$2M post-money. Implies forward valuation of approximately 1.5× current shop-level aggregate — fair given pre-ramp revenue base and platform/brand work ahead.', { width: 7020 })]}),
      new TableRow({ children: [Cell('Discount', { width: 2340, bold: true }), Cell('20% (the lower-of-cap-or-discount mechanic protects investors at conversion)', { width: 7020 })]}),
      new TableRow({ children: [Cell('MFN', { width: 2340, bold: true }), Cell('Most-favored-nation. Any later SAFE participant on better terms triggers automatic upgrade for earlier participants. Removes timing pressure on pool investors.', { width: 7020 })]}),
      new TableRow({ children: [Cell('Round target', { width: 2340, bold: true }), Cell('$1M total: $500K anchor + $500K from pool participants in $30K+ checks', { width: 7020 })]}),
      new TableRow({ children: [Cell('Conversion trigger', { width: 2340, bold: true }), Cell('Next priced equity round (Series A). At conversion, SAFE investor receives the GREATER of (cap-implied shares) or (discount-implied shares).', { width: 7020 })]}),
    ]
  }),

  H2('5.2 Series A — Year 1 Target'),
  P('Within 6-12 months of SAFE close, raise a Series A of approximately $1M at $4M pre-money ($5M post). At this stage we expect 10-15 shops, $3-5M gross ARR, demonstrated unit economics, and a credible operations leadership team including Jonathan as Operations Manager. SAFE converts at the cap ($2M) — better terms than priced round implied, so SAFE investors win meaningfully.'),

  H2('5.3 Exit Strategy — 4-Year and 7-Year Paths'),
  P('Two exit windows are modeled. The first targets PE or strategic acquisition at the 4-year mark; the second targets full Shipley-scale at year 7+:'),
  Bullet('Year 4 ($80-120M exit window): 25-35 shops at $400-500K AUV = $10-15M gross ARR. Buyer pays 6-10× revenue multiple. Realistic at this stage given Dave\'s Hot Chicken pace benchmark and Shipley\'s track record under Peak Rock.'),
  Bullet('Year 7 ($200-400M Shipley-scale exit): 100+ stores or significant supply/wholesale business attached. Either path requires franchise system + centralized kitchen + brand identity at scale.'),

  H2('5.4 Comparable Valuations — The Real Reference Set'),
  P('Six QSR/specialty bakery comparables anchor our exit modeling. Each illustrates a different piece of the trajectory:'),
  Bullet('Shipley Do-Nuts (direct model match): Houston-based donut franchise + Flour & Supply Co. Peak Rock Capital acquired Jan 2021, sold to Levine Leichtman July 2025 at approximately 2× value after 4-year hold. ~380 stores at second sale.'),
  Bullet('Mochinut (cultural / category match): LA-based mochi donuts + boba + Korean rice-flour hot dogs. 148+ units globally by 2023. $400K-$1M AUV per store. Asian-American specialty bakery thesis proven at scale.'),
  Bullet('Dave\'s Hot Chicken (pace benchmark): $22M systemwide sales 2020 → $617M 2024 → $1B Roark acquisition June 2025 at 8× revenue. The fastest QSR roll-up to billion-dollar exit in recent memory.'),
  Bullet('Krispy Kreme (PE → public trajectory): JAB Holdings $1.35B private acquisition 2016 → $3.6-4B IPO 2021 on Delivered Fresh Daily hub-and-spoke model. Direct strategic parallel to our centralized kitchen thesis.'),
  Bullet('Cava (sane public multiple): IPO June 2023 at $2.4B on $700M revenue = ~3.5× revenue multiple. The sustainable public-market comp.'),
  Bullet('Sweetgreen (cautionary tale): IPO 2021 at $3B / 15× revenue, today trades at $1.08B / 2.4× revenue. Loss of 66% value when bubble compressed. We model on sane multiples, not 2021 peaks.'),
  P('Critical observation: NONE of these were pre-revenue unicorns. Every one built revenue first, then multiples followed. Our trajectory assumes the same discipline.'),

  new Paragraph({ children: [new PageBreak()] }),

  // Section 6: Open Items
  H1('6 · Open Items Requiring Sign-Off'),
  P('The following decisions are still informal or unconfirmed. Each should be ratified between you and me before we approach the anchor SAFE investor.'),

  H2('6.1 Securities Compliance'),
  Bullet('Send accreditation questionnaires to all 14 LPs immediately. Free to send (template available), creates audit trail required for Reg D 506(b) compliance.'),
  Bullet('Identify any non-accredited LPs and develop disclosure-based path to formalize.'),
  Bullet('Engage securities counsel before SAFE close.'),

  H2('6.2 Operational Bookkeeping'),
  Bullet('Engage fractional bookkeeper (~$1-3K) to perform clean April + May 2026 close.'),
  Bullet('Reconcile POS data → bank deposits → bookkeeping records for each of 7 shops.'),
  Bullet('Lock in verified gross ARR figure (currently estimated ~$1.5M).'),
  Bullet('Outputs feed into SAFE close materials and Series A diligence prep.'),

  H2('6.3 Counsel Engagement'),
  Bullet('Secure SAFE template — Y Combinator post-money MFN form, standard terms.'),
  Bullet('Engage corporate counsel for HoldCo Delaware formation.'),
  Bullet('Securities counsel for §721 rollup mechanics.'),
  Bullet('Tax advisor for §721 contribution memos per shop.'),
  Bullet('Cost estimate: $25-40K total legal through HoldCo OA finalization. Deferred to SAFE proceeds.'),

  H2('6.4 LP Consent Outreach'),
  Bullet('Soft conversations with each LP group before formal paperwork goes out.'),
  Bullet('Lead with the capital floor mechanic as protection (no LP loses anything; many gain protections they did not previously have).'),
  Bullet('Arlington LPs: explicitly honor the 10% pref through pref-adjusted floor language.'),
  Bullet('Target: signed consents within 90 days of HoldCo formation.'),

  H2('6.5 Lender and Landlord Consents'),
  Bullet('Most shop-level loans (if any) require consent for change of ownership at the LLC level.'),
  Bullet('All commercial leases include change-of-control provisions.'),
  Bullet('Identify each shop\'s consent requirements early in Month 1-2.'),
  Bullet('Risk: landlord or lender holdout on one shop could delay that shop\'s rollup. Solution: structure HoldCo as parent with right to absorb at later date.'),

  H2('6.6 The Last Two Open Allocation Questions'),
  Bullet('Lam in advisor pool at 1% versus moving to MIP at 1% as employee. Defaulted to advisor (per "mutual-aid" framing), but flag if Lam is on payroll.'),
  Bullet('Advisor pool reserve at 6%. Sized for 2-4 institutional board advisors at 1-3% each. Larger reserve possible if envisioning more aggressive advisor recruitment.'),

  new Paragraph({ children: [new PageBreak()] }),

  // Section 7: Risks
  H1('7 · Risks and Mitigations'),
  P('No deal is without risk. The honest assessment:'),

  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [3120, 6240],
    rows: [
      new TableRow({ children: [HCell('Risk', 3120), HCell('Mitigation', 6240)]}),
      new TableRow({ children: [Cell('LP holdout on rollup consent', { width: 3120, bold: true }), Cell('Capital floor mechanic provides downside protection. Arlington pref preserves original deal. Each LP gets greater of equity or floor — no one loses.', { width: 6240 })]}),
      new TableRow({ children: [Cell('Lender / landlord consent delay', { width: 3120, bold: true }), Cell('Shell HoldCo can wait for individual subsidiary roll-ins; not all-or-nothing. SAFE proceeds available once shell formed.', { width: 6240 })]}),
      new TableRow({ children: [Cell('§721 tax treatment error', { width: 3120, bold: true }), Cell('Tax advisor engaged before any contribution. Per-shop §721 memos drafted. Standard mechanic — rarely fails when done correctly.', { width: 6240 })]}),
      new TableRow({ children: [Cell('Revenue at SAFE close lower than projected', { width: 3120, bold: true }), Cell('Conservative $1.31M net / $1.5M gross framing already cushions against this. May close will confirm or adjust.', { width: 6240 })]}),
      new TableRow({ children: [Cell('Anchor SAFE investor walks away', { width: 3120, bold: true }), Cell('MFN clause makes pool investors fungible substitutes. $500K from anchor can be replaced by 5-10 pool participants without renegotiating terms.', { width: 6240 })]}),
      new TableRow({ children: [Cell('Operations stretched too thin during rollup', { width: 3120, bold: true }), Cell('Jonathan hire in Month 2-4 addresses this directly. Muypin already running daily ops. Bandwidth for next 6 acquisitions limited until ops manager onboarded.', { width: 6240 })]}),
      new TableRow({ children: [Cell('Multi compression at exit', { width: 3120, bold: true }), Cell('Modeled at 6-10× revenue (mid-cycle), not 15× (peak bubble). Cava\'s 3.5× is the realistic floor for a quality fast-casual platform.', { width: 6240 })]}),
    ]
  }),

  new Paragraph({ children: [new PageBreak()] }),

  // Section 8: Action Items
  H1('8 · Action Items — Next 30 Days'),
  P('Specific, dated actions before the anchor SAFE investor conversation:'),
  Bullet('Week 1: Decide on remaining open items (Lam tier, advisor reserve size). Final cap table sign-off between UU and Jack.'),
  Bullet('Week 1: Engage corporate counsel to begin Delaware HoldCo formation.'),
  Bullet('Week 1-2: Send accreditation questionnaires to all 14 LPs.'),
  Bullet('Week 2: Engage fractional bookkeeper. Begin April close.'),
  Bullet('Week 2: Soft outreach calls to 2-3 Arlington LPs to test the capital floor + pref preservation message. Refine language based on response.'),
  Bullet('Week 2-3: Update pitch deck with verified gross ARR figure once bookkeeper completes close.'),
  Bullet('Week 3: First conversation with anchor SAFE investor. Use the strategy doc + pitch deck.'),
  Bullet('Week 3-4: Form HoldCo legally. Open bank account. Engage securities counsel.'),
  Bullet('Week 4: SAFE term sheet drafted and reviewed by counsel.'),

  H1('9 · Closing'),
  P('This memo represents approximately 3 months of structural work compressed into a single readable form. The architecture is now defensible at institutional diligence, the cap table is clean, the LP base is protected, and the capital strategy aligns to real comparable trajectories. The next 30 days are about execution — counsel, bookkeeper, accreditation, anchor conversation.'),
  P('Two requests for our session:'),
  Bullet('Read this end-to-end before we meet. Mark anything that surprises you or that you would frame differently.'),
  Bullet('Come to the meeting with your veto list — what would you change about the cap table, the structure, or the sequencing? Better to fight here than at the term sheet stage.'),
  P(' ', { italics: true }),
  P('Looking forward to the conversation.', { italics: true }),
  P(' '),
  P('— Youyou'),
];

const doc = new Document({
  styles: {
    default: { document: { run: { font: 'Calibri', size: 22 } } },
    paragraphStyles: [
      { id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { size: 36, bold: true, font: 'Calibri', color: INK },
        paragraph: { spacing: { before: 360, after: 180 }, outlineLevel: 0 } },
      { id: 'Heading2', name: 'Heading 2', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { size: 28, bold: true, font: 'Calibri', color: INK },
        paragraph: { spacing: { before: 280, after: 140 }, outlineLevel: 1 } },
      { id: 'Heading3', name: 'Heading 3', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { size: 22, bold: true, font: 'Calibri', color: GOLD_DEEP },
        paragraph: { spacing: { before: 200, after: 100 }, outlineLevel: 2 } },
    ]
  },
  numbering: {
    config: [
      { reference: 'bullets',
        levels: [{ level: 0, format: LevelFormat.BULLET, text: '•', alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
    ]
  },
  sections: [{
    properties: {
      page: {
        size: { width: 12240, height: 15840 },
        margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 }
      }
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          alignment: AlignmentType.RIGHT,
          children: [new TextRun({ text: 'GOLDEN GLAZE · STRATEGIC MEMORANDUM · CONFIDENTIAL', size: 16, color: MUTED, font: 'Calibri', allCaps: true })]
        })]
      })
    },
    footers: {
      default: new Footer({
        children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({ text: 'Page ', size: 16, color: MUTED, font: 'Calibri' }),
            new TextRun({ children: [PageNumber.CURRENT], size: 16, color: MUTED, font: 'Calibri' }),
            new TextRun({ text: ' of ', size: 16, color: MUTED, font: 'Calibri' }),
            new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 16, color: MUTED, font: 'Calibri' }),
          ]
        })]
      })
    },
    children
  }]
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync('/home/claude/gg-package/docs/01-Strategy-Walkthrough-for-Jack.docx', buffer);
  console.log('✓ Strategy walkthrough doc built');
});
