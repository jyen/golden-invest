// Build: Accredited Investor Questionnaire
// Reg D 506(b) compliance template — investor self-certification

const { Document, Packer, Paragraph, TextRun, AlignmentType, HeadingLevel, BorderStyle, Table, TableRow, TableCell, WidthType, ShadingType, PageBreak } = require('docx');
const fs = require('fs');

// Color palette
const INK = '1A1208';
const TEXT = '3A2818';
const SOFT = '6B5840';
const MUTED = '8E7857';
const GOLD = 'D99C2B';
const GOLD_DEEP = 'A87618';
const CREAM = 'FAF6EA';
const CARD = 'F8EFD7';

// Typography helpers
const Title = (text) => new Paragraph({
  children: [new TextRun({ text, size: 40, color: INK, font: 'Georgia', bold: true })],
  alignment: AlignmentType.CENTER,
  spacing: { before: 100, after: 240 },
});

const Subtitle = (text) => new Paragraph({
  children: [new TextRun({ text, size: 22, color: GOLD_DEEP, font: 'Calibri', italics: true })],
  alignment: AlignmentType.CENTER,
  spacing: { after: 480 },
});

const H1 = (text) => new Paragraph({
  children: [new TextRun({ text, size: 28, color: INK, font: 'Georgia', bold: true })],
  spacing: { before: 360, after: 180 },
  border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: GOLD } },
});

const H2 = (text) => new Paragraph({
  children: [new TextRun({ text, size: 24, color: GOLD_DEEP, font: 'Georgia', bold: true })],
  spacing: { before: 240, after: 120 },
});

const P = (text) => new Paragraph({
  children: [new TextRun({ text, size: 22, color: TEXT, font: 'Calibri' })],
  spacing: { after: 160, line: 320 },
});

const Plain = (text, opts = {}) => new TextRun({ text, size: 22, color: opts.color || TEXT, font: 'Calibri', bold: opts.bold, italics: opts.italics });
const Bold = (text) => new TextRun({ text, size: 22, color: INK, font: 'Calibri', bold: true });

const Mixed = (...runs) => new Paragraph({
  children: runs,
  spacing: { after: 160, line: 320 },
});

const CheckLine = (label) => new Paragraph({
  children: [
    new TextRun({ text: '☐  ', size: 24, color: GOLD_DEEP, font: 'Calibri', bold: true }),
    new TextRun({ text: label, size: 22, color: TEXT, font: 'Calibri' }),
  ],
  spacing: { after: 140, line: 320 },
  indent: { left: 200 },
});

const FillLine = (label, lines = 1) => {
  const paras = [
    new Paragraph({
      children: [new TextRun({ text: label, size: 20, color: SOFT, font: 'Calibri', bold: true })],
      spacing: { before: 120, after: 60 },
    }),
  ];
  for (let i = 0; i < lines; i++) {
    paras.push(new Paragraph({
      children: [new TextRun({ text: '\u00A0'.repeat(120), size: 22, font: 'Calibri', color: 'FFFFFF' })],
      spacing: { after: 100 },
      border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: MUTED } },
    }));
  }
  return paras;
};

const Spacer = (size = 200) => new Paragraph({ children: [new TextRun({ text: '', size: 12 })], spacing: { after: size } });

const NoteBox = (text) => {
  return new Paragraph({
    children: [
      new TextRun({ text: 'NOTE:  ', size: 18, color: GOLD_DEEP, font: 'Calibri', bold: true, characterSpacing: 20 }),
      new TextRun({ text, size: 20, color: TEXT, font: 'Calibri', italics: true }),
    ],
    spacing: { before: 120, after: 240, line: 300 },
    shading: { type: ShadingType.SOLID, color: CARD },
    border: {
      top: { style: BorderStyle.NONE, size: 0, color: CARD },
      bottom: { style: BorderStyle.NONE, size: 0, color: CARD },
      left: { style: BorderStyle.SINGLE, size: 18, color: GOLD },
      right: { style: BorderStyle.NONE, size: 0, color: CARD },
    },
    indent: { left: 200, right: 200 },
  });
};

// Document content
const doc = new Document({
  styles: {
    default: {
      document: { run: { font: 'Calibri', size: 22, color: TEXT } },
    },
  },
  sections: [{
    properties: {
      page: { margin: { top: 1080, right: 1080, bottom: 1080, left: 1080 } },
    },
    children: [
      // ============ HEADER ============
      new Paragraph({
        children: [new TextRun({ text: 'GOLDEN GLAZE HOLDINGS LLC', size: 18, color: GOLD_DEEP, font: 'Calibri', bold: true, characterSpacing: 40 })],
        alignment: AlignmentType.CENTER,
        spacing: { after: 60 },
      }),
      new Paragraph({
        children: [new TextRun({ text: '—', size: 18, color: GOLD, font: 'Calibri' })],
        alignment: AlignmentType.CENTER,
        spacing: { after: 360 },
      }),

      Title('Accredited Investor Questionnaire'),
      Subtitle('Confidential — for the purposes of verifying eligibility under SEC Rule 506(b)'),

      P('Thank you for your interest in investing in Golden Glaze Holdings LLC (the "Company"). The Company is offering securities (in the form of Simple Agreements for Future Equity, or "SAFEs") in reliance on the exemption from registration provided by Rule 506(b) of Regulation D under the Securities Act of 1933.'),

      P('To comply with applicable securities laws, we are required to verify that each prospective investor either (a) qualifies as an "accredited investor" under SEC rules, or (b) is a "sophisticated investor" who meets the knowledge and experience requirements of Rule 506(b).'),

      P('Please complete this questionnaire honestly and completely. The information you provide will be kept confidential and used solely to confirm your eligibility to invest. False or misleading statements may result in the rescission of your investment and civil liability under federal and state securities laws.'),

      NoteBox('This questionnaire is provided for informational purposes only. It is not a substitute for advice from your own legal counsel or tax advisor. Please consult appropriate professionals before completing this form or making an investment decision.'),

      Spacer(400),

      // ============ SECTION 1: INVESTOR INFORMATION ============
      H1('Section 1 · Investor Information'),

      ...FillLine('Full legal name (individual) or entity name'),
      ...FillLine('Mailing address'),
      ...FillLine('Email address'),
      ...FillLine('Phone number'),
      ...FillLine('Social Security Number (individual) or EIN (entity)'),

      H2('Type of investor'),
      CheckLine('Individual (one person investing in their own name)'),
      CheckLine('Joint with spouse'),
      CheckLine('Trust'),
      CheckLine('LLC, Corporation, Partnership, or other entity'),
      CheckLine('Retirement account (IRA, Self-Directed 401(k), etc.)'),

      Spacer(300),

      // ============ SECTION 2: ACCREDITED STATUS ============
      H1('Section 2 · Accredited Investor Status'),

      P('Under SEC Rule 501(a), an individual qualifies as an "accredited investor" by meeting one or more of the criteria below. Please check ALL that apply to you. You must check at least one of the boxes in this section, or alternatively complete Section 3 (Sophisticated Investor) below.'),

      H2('Income test'),
      CheckLine('I had individual income exceeding $200,000 in each of the two most recent calendar years, and I reasonably expect to reach the same income level in the current year.'),
      CheckLine('Together with my spouse or spousal equivalent, I had joint income exceeding $300,000 in each of the two most recent calendar years, and we reasonably expect to reach the same income level in the current year.'),

      H2('Net worth test'),
      CheckLine('My individual net worth (or joint net worth with my spouse or spousal equivalent) exceeds $1,000,000, excluding the value of my primary residence.'),

      H2('Professional certification test'),
      CheckLine('I hold in good standing a Series 7, Series 65, or Series 82 license issued by FINRA.'),
      CheckLine('I am a "knowledgeable employee" of a private fund as defined in Rule 3c-5(a)(4) of the Investment Company Act.'),

      H2('Entity tests (for trusts, LLCs, corporations, partnerships)'),
      CheckLine('The entity has total assets in excess of $5,000,000 and was not formed for the specific purpose of acquiring the securities offered.'),
      CheckLine('All of the equity owners of the entity are themselves accredited investors.'),
      CheckLine('The entity is a "family office" as defined in Rule 202(a)(11)(G)-1 of the Investment Advisers Act, with at least $5,000,000 in assets under management, not formed for the specific purpose of acquiring the securities, and whose investment is directed by a person with sufficient knowledge and experience.'),
      CheckLine('The entity is a bank, registered broker-dealer, registered investment adviser, insurance company, registered investment company, or other qualifying institutional investor under Rule 501(a)(1).'),

      Spacer(300),

      // ============ SECTION 3: SOPHISTICATED (NON-ACCREDITED) INVESTOR ============
      H1('Section 3 · Sophisticated Investor (Non-Accredited)'),

      P('Rule 506(b) permits up to 35 non-accredited investors per offering, provided that each such investor (alone or with their purchaser representative) has sufficient knowledge and experience in financial and business matters to evaluate the merits and risks of the investment.'),

      P('If you do NOT meet the accredited criteria in Section 2 above, please complete this section to certify your qualifications:'),

      CheckLine('I have read the offering materials provided (including the SAFE document, business plan, financial summary, and any other diligence materials) and understand the risks described therein.'),
      CheckLine('I understand that this investment involves a high degree of risk, including the possibility of total loss, and that there is no public market for these securities.'),
      CheckLine('I have sufficient knowledge and experience in financial and business matters that I am capable of evaluating the merits and risks of this investment.'),
      CheckLine('I have the financial ability to bear the economic risk of this investment, including the possibility of losing my entire investment.'),

      ...FillLine('Briefly describe your financial and business experience that qualifies you as a sophisticated investor (e.g., prior investments, professional background, education, advisory roles)', 4),

      Spacer(300),

      // ============ SECTION 4: INVESTMENT DETAILS ============
      H1('Section 4 · Investment Details'),

      ...FillLine('Proposed investment amount (USD)'),
      ...FillLine('Source of funds (e.g., personal savings, retirement account, business funds)'),

      H2('Have you previously invested in any Golden Glaze entity?'),
      CheckLine('Yes — please indicate which entity below'),
      CheckLine('No'),
      ...FillLine('If yes, which entity (Arlington/NRH joint LLC, Fort Worth LLC, Grapevine LLC, etc.) and approximate amount', 2),

      H2('Are you investing on behalf of another person or entity?'),
      CheckLine('No, I am investing in my own name and for my own account.'),
      CheckLine('Yes — please describe the beneficial owner below'),
      ...FillLine('If yes, name of beneficial owner and relationship to investor', 2),

      Spacer(300),

      // ============ SECTION 5: ACKNOWLEDGMENTS ============
      H1('Section 5 · Acknowledgments and Representations'),

      P('By signing below, I (the undersigned investor) represent and warrant to Golden Glaze Holdings LLC that:'),

      CheckLine('All information I have provided in this questionnaire is true, complete, and accurate to the best of my knowledge.'),
      CheckLine('I understand that the Company will rely on the information in this questionnaire to determine my eligibility to invest, and to comply with applicable federal and state securities laws.'),
      CheckLine('I will notify the Company promptly in writing if any of the information I have provided becomes inaccurate or incomplete prior to the closing of my investment.'),
      CheckLine('I understand that the securities I am acquiring have not been registered under the Securities Act of 1933 or any state securities laws, and that I cannot sell or transfer them except pursuant to registration or an applicable exemption.'),
      CheckLine('I am acquiring the securities for my own account, for investment purposes, and not with a view to or for resale or distribution.'),
      CheckLine('I understand that no public market exists for these securities, that none may ever exist, and that my investment may be illiquid for an extended period (potentially indefinitely).'),
      CheckLine('I have had the opportunity to ask questions and receive answers from the Company concerning the terms of the offering, the business, and the risks of investment.'),
      CheckLine('I acknowledge that I have been advised to consult with my own legal, tax, and financial advisors before making this investment, and have either done so or made an informed decision not to.'),

      Spacer(400),

      // ============ SIGNATURE ============
      H1('Signature'),

      ...FillLine('Signature (individual or authorized signatory of entity)'),
      ...FillLine('Printed name'),
      ...FillLine('Title (if signing on behalf of an entity)'),
      ...FillLine('Date'),

      Spacer(600),

      // Footer
      new Paragraph({
        children: [new TextRun({ text: 'Return completed form to: legal@goldenglazedonuts.com', size: 20, color: GOLD_DEEP, font: 'Calibri', italics: true })],
        alignment: AlignmentType.CENTER,
        spacing: { after: 120 },
      }),
      new Paragraph({
        children: [new TextRun({ text: 'For questions, contact Jack Zhou (jack@goldenglazedonuts.com) or Youyou Chen (youyou@goldenglazedonuts.com)', size: 18, color: MUTED, font: 'Calibri', italics: true })],
        alignment: AlignmentType.CENTER,
        spacing: { after: 360 },
      }),
      new Paragraph({
        children: [new TextRun({ text: 'This document is confidential. Do not share without permission.', size: 16, color: MUTED, font: 'Calibri', italics: true, characterSpacing: 30 })],
        alignment: AlignmentType.CENTER,
      }),
    ],
  }],
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync('/home/claude/gg-package/docs/05-Accreditation-Questionnaire.docx', buffer);
  console.log('✓ Accreditation questionnaire built');
});
