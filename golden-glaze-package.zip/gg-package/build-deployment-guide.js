// Build: Deployment Guide
// How to use every artifact in the package, sequencing, talk tracks

const { Document, Packer, Paragraph, TextRun, AlignmentType, HeadingLevel, BorderStyle, Table, TableRow, TableCell, WidthType, ShadingType, PageBreak } = require('docx');
const fs = require('fs');

// Palette
const INK = '1A1208', TEXT = '3A2818', SOFT = '6B5840', MUTED = '8E7857';
const GOLD = 'D99C2B', GOLD_DEEP = 'A87618';
const CREAM = 'FAF6EA', CARD = 'F8EFD7';

const Title = (t) => new Paragraph({
  children: [new TextRun({ text: t, size: 48, color: INK, font: 'Georgia', bold: true })],
  alignment: AlignmentType.CENTER, spacing: { before: 100, after: 240 },
});
const Subtitle = (t) => new Paragraph({
  children: [new TextRun({ text: t, size: 24, color: GOLD_DEEP, font: 'Calibri', italics: true })],
  alignment: AlignmentType.CENTER, spacing: { after: 480 },
});
const H1 = (t) => new Paragraph({
  children: [new TextRun({ text: t, size: 32, color: INK, font: 'Georgia', bold: true })],
  spacing: { before: 480, after: 200 },
  border: { bottom: { style: BorderStyle.SINGLE, size: 12, color: GOLD } },
});
const H2 = (t) => new Paragraph({
  children: [new TextRun({ text: t, size: 26, color: GOLD_DEEP, font: 'Georgia', bold: true })],
  spacing: { before: 320, after: 160 },
});
const H3 = (t) => new Paragraph({
  children: [new TextRun({ text: t, size: 22, color: INK, font: 'Calibri', bold: true })],
  spacing: { before: 240, after: 120 },
});
const P = (t) => new Paragraph({
  children: [new TextRun({ text: t, size: 22, color: TEXT, font: 'Calibri' })],
  spacing: { after: 160, line: 320 },
});
const Plain = (t, opts={}) => new TextRun({ text: t, size: 22, color: opts.color || TEXT, font: 'Calibri', bold: opts.bold, italics: opts.italics });
const Bold = (t) => new TextRun({ text: t, size: 22, color: INK, font: 'Calibri', bold: true });
const Code = (t) => new TextRun({ text: t, size: 20, color: GOLD_DEEP, font: 'Consolas' });
const Mixed = (...r) => new Paragraph({ children: r, spacing: { after: 160, line: 320 } });
const Bullet = (t) => new Paragraph({
  children: [new TextRun({ text: t, size: 22, color: TEXT, font: 'Calibri' })],
  bullet: { level: 0 }, spacing: { after: 100, line: 300 },
});
const BulletBold = (boldPart, rest) => new Paragraph({
  children: [
    new TextRun({ text: boldPart, size: 22, color: INK, font: 'Calibri', bold: true }),
    new TextRun({ text: rest, size: 22, color: TEXT, font: 'Calibri' }),
  ],
  bullet: { level: 0 }, spacing: { after: 100, line: 300 },
});

const Cell = (text, opts={}) => new TableCell({
  width: { size: opts.width || 3000, type: WidthType.DXA },
  shading: opts.fill ? { type: ShadingType.SOLID, color: opts.fill } : undefined,
  margins: { top: 120, bottom: 120, left: 160, right: 160 },
  children: [new Paragraph({
    children: [new TextRun({
      text, size: opts.size || 20, font: opts.mono ? 'Consolas' : 'Calibri',
      color: opts.color || TEXT, bold: opts.bold, italics: opts.italics,
    })],
    alignment: opts.align || AlignmentType.LEFT,
  })],
});

const Spacer = (s=200) => new Paragraph({ children: [new TextRun({ text: '', size: 12 })], spacing: { after: s } });

const Callout = (label, body) => new Paragraph({
  children: [
    new TextRun({ text: `${label.toUpperCase()}  ·  `, size: 18, color: GOLD_DEEP, font: 'Calibri', bold: true, characterSpacing: 40 }),
    new TextRun({ text: body, size: 20, color: TEXT, font: 'Calibri', italics: true }),
  ],
  spacing: { before: 160, after: 240, line: 300 },
  shading: { type: ShadingType.SOLID, color: CARD },
  border: { left: { style: BorderStyle.SINGLE, size: 24, color: GOLD } },
  indent: { left: 200, right: 200 },
});

// ============ BUILD ============
const doc = new Document({
  styles: { default: { document: { run: { font: 'Calibri', size: 22, color: TEXT } } } },
  sections: [{
    properties: { page: { margin: { top: 1080, right: 1080, bottom: 1080, left: 1080 } } },
    children: [

      // COVER
      new Paragraph({
        children: [new TextRun({ text: 'GOLDEN GLAZE DONUTS', size: 18, color: GOLD_DEEP, font: 'Calibri', bold: true, characterSpacing: 60 })],
        alignment: AlignmentType.CENTER, spacing: { before: 1200, after: 120 },
      }),
      new Paragraph({
        children: [new TextRun({ text: '——', size: 18, color: GOLD, font: 'Calibri' })],
        alignment: AlignmentType.CENTER, spacing: { after: 480 },
      }),
      Title('Deployment Guide'),
      Subtitle('How to use every artifact in this package — for Youyou and Jack'),

      P('This guide ties the package together. It maps each file to its purpose, the audience it is for, the talk track to use, and the sequence in which to deploy them. Read this first. Then work through the strategy memo with Jack. Then start the conversations.'),

      Callout('Time to deploy', 'Plan to spend a focused weekend reviewing this with Jack. Decisions in Section 7 should be locked before any external conversations begin.'),

      new Paragraph({ children: [new PageBreak()] }),

      // ============ 1. FILE MAP ============
      H1('1 · What is in this package'),

      P('Seven artifacts, organized by audience and purpose:'),

      new Table({
        width: { size: 9360, type: WidthType.DXA },
        columnWidths: [560, 2800, 2400, 3600],
        rows: [
          new TableRow({ tableHeader: true, children: [
            Cell('#', { width: 560, bold: true, color: 'FFFFFF', fill: INK, align: AlignmentType.CENTER }),
            Cell('File', { width: 2800, bold: true, color: 'FFFFFF', fill: INK }),
            Cell('Audience', { width: 2400, bold: true, color: 'FFFFFF', fill: INK }),
            Cell('Purpose', { width: 3600, bold: true, color: 'FFFFFF', fill: INK }),
          ]}),
          new TableRow({ children: [
            Cell('01', { width: 560, bold: true, mono: true, color: GOLD_DEEP, align: AlignmentType.CENTER }),
            Cell('Strategy-Walkthrough-for-Jack.docx', { width: 2800, bold: true }),
            Cell('Jack first · advisors after', { width: 2400, italics: true, color: SOFT }),
            Cell('Master strategic memo. Every structural decision documented. Open items flagged. Read this first.', { width: 3600 }),
          ]}),
          new TableRow({ children: [
            Cell('02', { width: 560, bold: true, mono: true, color: GOLD_DEEP, align: AlignmentType.CENTER, fill: CREAM }),
            Cell('Investor-Deck-Standard.pptx', { width: 2800, bold: true, fill: CREAM }),
            Cell('Small SAFE investors ($25-50K)', { width: 2400, italics: true, color: SOFT, fill: CREAM }),
            Cell('10-slide pitch deck. Story-driven. Light on detail. For friends, family, and smaller checks.', { width: 3600, fill: CREAM }),
          ]}),
          new TableRow({ children: [
            Cell('03', { width: 560, bold: true, mono: true, color: GOLD_DEEP, align: AlignmentType.CENTER }),
            Cell('Investor-Deck-Anchor.pptx', { width: 2800, bold: true }),
            Cell('Anchor SAFE investor ($250K+)', { width: 2400, italics: true, color: SOFT }),
            Cell('16-slide analytical deck. Includes valuation methodology, comp set, exit math, returns table. For the $500K anchor and diligence-heavy folks.', { width: 3600 }),
          ]}),
          new TableRow({ children: [
            Cell('04', { width: 560, bold: true, mono: true, color: GOLD_DEEP, align: AlignmentType.CENTER, fill: CREAM }),
            Cell('LP-Update-Letter.docx', { width: 2800, bold: true, fill: CREAM }),
            Cell('14 existing LPs', { width: 2400, italics: true, color: SOFT, fill: CREAM }),
            Cell('Warm transparent letter explaining the roll-up. Honors Arlington 10% pref. Asks for accreditation + consent.', { width: 3600, fill: CREAM }),
          ]}),
          new TableRow({ children: [
            Cell('05', { width: 560, bold: true, mono: true, color: GOLD_DEEP, align: AlignmentType.CENTER }),
            Cell('Accreditation-Questionnaire.docx', { width: 2800, bold: true }),
            Cell('All 14 LPs + every SAFE investor', { width: 2400, italics: true, color: SOFT }),
            Cell('Reg D 506(b) self-certification form. Required before any SAFE closes. Send to legal counsel for review before mailing.', { width: 3600 }),
          ]}),
          new TableRow({ children: [
            Cell('06', { width: 560, bold: true, mono: true, color: GOLD_DEEP, align: AlignmentType.CENTER, fill: CREAM }),
            Cell('Deployment-Guide.docx', { width: 2800, bold: true, fill: CREAM }),
            Cell('You and Jack', { width: 2400, italics: true, color: SOFT, fill: CREAM }),
            Cell('This document. How to use everything, talk tracks, sequencing.', { width: 3600, fill: CREAM }),
          ]}),
          new TableRow({ children: [
            Cell('07', { width: 560, bold: true, mono: true, color: GOLD_DEEP, align: AlignmentType.CENTER }),
            Cell('golden-glaze-app/ (HTML)', { width: 2800, bold: true }),
            Cell('Investors during/after meetings', { width: 2400, italics: true, color: SOFT }),
            Cell('Interactive 10-tab strategy app. Deploy as a private URL. Share the link, not the file.', { width: 3600 }),
          ]}),
        ],
      }),

      Spacer(300),
      Callout('A note on numbering', 'The numbering reflects the order in which you should encounter the files, not necessarily the order in which you deploy them externally.'),

      new Paragraph({ children: [new PageBreak()] }),

      // ============ 2. DEPLOY THE HTML APP ============
      H1('2 · Deploying the HTML strategy app'),

      P('The interactive strategy app lives in the folder golden-glaze-app/. It is a single-page application built from the same source as the React JSX artifact. Once deployed, you share a URL — not a file — with investors and advisors.'),

      H2('Easiest deployment paths (free, no code knowledge needed)'),

      H3('Option A — Netlify Drop (recommended, takes 60 seconds)'),
      Mixed(
        Plain('Go to '), Code('app.netlify.com/drop'), Plain(', drag-and-drop the entire '), Code('golden-glaze-app/'), Plain(' folder, and you get a public URL within seconds. Free tier supports unlimited bandwidth for low-traffic sites like this one. To make it private, upgrade to Netlify Pro (~$19/month) and enable password protection.')
      ),

      H3('Option B — Vercel'),
      Mixed(
        Plain('Similar workflow at '), Code('vercel.com'), Plain('. Upload the folder. Get a URL. Vercel also offers free password protection on their Hobby tier.')
      ),

      H3('Option C — Custom domain'),
      P('If you want to host at app.goldenglazedonuts.com — both Netlify and Vercel support custom domain configuration in their dashboards. Buy the domain via Cloudflare Registrar or Namecheap, configure DNS, point it at the deployment. Takes about 30 minutes if you have not done it before.'),

      H2('Important: protect the URL'),
      P('This app contains confidential financial information, cap table details, and forward-looking projections. Do not post the URL publicly. Either (a) use password protection via Netlify Pro, (b) keep the URL un-indexed and only share with specific investors, or (c) host behind a private link with random characters (a "secret URL"). Treat the URL the way you would treat a draft pitch deck — only share with people you have agreed to share with.'),

      H2('Files in the golden-glaze-app folder'),
      BulletBold('index.html ', '— the entry point. This is what loads when someone visits the URL.'),
      BulletBold('assets/index-[hash].js ', '— the application code, all bundled into one file. ~660KB unminified.'),
      Bullet('That is it. Two files. No server required. No database. Static hosting only.'),

      Callout('What to say when sharing the link', 'Send a short email or Signal message: "Here is our strategy walkthrough — please review the Welcome tab first, then work through Where We Are and The Team to understand the team and operations. The Roll-Up and Modeler tabs are the financial detail. Reply with questions and let us schedule a call." Frame it as preparation for a conversation, not a substitute for one.'),

      new Paragraph({ children: [new PageBreak()] }),

      // ============ 3. TALK TRACKS ============
      H1('3 · Talk tracks by audience'),

      P('Same business. Different framings depending on who you are talking to. Use these as starting scripts; adapt for your relationship and the room.'),

      H2('A · Small SAFE investor ($25-50K) — friends, family, lighter checks'),

      H3('Goal'),
      P('Convert relationship and trust into a small check. They are not buying based on the math — they are buying based on you. The deck supports the conversation; it does not replace it.'),

      H3('Setup (15 min)'),
      P('"We are putting together a SAFE round of around $300K-$1M to formalize what we have built and prepare for a Series A. I wanted you to see what we are doing before it was finalized. Check sizes range from $25K to $50K for friends-and-family — and I would love your participation if it makes sense for you. Let me walk you through it."'),

      H3('Walkthrough (20-30 min)'),
      P('Open Deck 02 (Standard). Skip slide 5 details if they are not engaged — focus on slides 1, 2, 4, 7, 8, 9. Talk to the photos and the founders, not the math.'),

      H3('The ask'),
      P('"The structure is a SAFE — Simple Agreement for Future Equity. You wire funds, you get a contract that converts into HoldCo equity at our next priced round. The cap is $2 million post-money, which means you are getting in at founder-friendly terms. At our base case exit of $120M in four years, your $30K returns approximately $1.4M. We do not promise this. But the comps support it."'),

      H3('Common objections'),
      BulletBold('"Why donuts?" ', '— Fragmented market, low entry prices, proven exits (Shipley, Krispy Kreme, Dave\'s Hot Chicken). Donuts is one of the last unconsolidated QSR categories.'),
      BulletBold('"Why now?" ', '— We have seven shops in eight months. We have proven the M&A pipeline. The next 18 months are about turning that into a brand.'),
      BulletBold('"What kills this?" ', '— Execution risk. Operations stretched too thin. We are mitigating with the incoming Operations Manager (Jonathan) and our active operating partner (Muypin) running daily ops.'),
      BulletBold('"What\'s my downside?" ', '— Realistic worst case is total loss of capital. SAFE has no liquidation preference. This is risk capital — only invest what you can afford to lose.'),

      H2('B · Anchor SAFE investor ($250K-$500K) — diligence-heavy'),

      H3('Goal'),
      P('Land an anchor commitment of $250K-$500K that signals to other investors. Anchor investors often help bring others in. The deck shows institutional-grade thinking.'),

      H3('Setup (10 min)'),
      P('"We have a $1M SAFE round forming with a $2M post-money cap. We are looking for one anchor commitment of $250-500K that we can build the round around. The reason I am calling you specifically is [their unique fit — operator network, capital flexibility, etc.]. Let me walk you through what we have built and where this goes."'),

      H3('Walkthrough (45-60 min, plus a follow-up diligence call)'),
      P('Open Deck 03 (Anchor). Move through systematically. Spend extra time on slides covering the cap table architecture, the comp set, and the returns scenarios. Be prepared for detailed questions on unit economics, operations, and the team.'),

      H3('The ask'),
      P('"For $500K at our $2M cap, you would receive approximately 25% of post-SAFE equity, diluting to ~20% after Series A. At our base case exit of $120M in four years, your $500K returns approximately $24M — that is 48× MOIC, ~165% IRR. This is a generous cap. It reflects the fact that we are raising before the brand is built. We expect the cap to be more demanding for any investor coming in 12 months from now."'),

      H3('What anchor investors will ask'),
      BulletBold('Detailed unit economics ', '— per-shop revenue, gross margin, net margin, breakeven, payback. Be prepared to show actual numbers from at least two of the shops.'),
      BulletBold('Pipeline math ', '— how many more shops, at what prices, financed how? Walk through the $1M Series A target and what it unlocks.'),
      BulletBold('Operational depth ', '— who runs each shop? Who has bandwidth for the next acquisition? Be honest about your bench depth. Highlight Jonathan, Muypin, master bakers.'),
      BulletBold('Why a SAFE versus priced ', '— "Six months of operating data is too thin to defend a valuation. SAFE defers that conversation to Series A when we have 12-18 months of consolidated data. Anchor SAFE investors get the cap protection."'),
      BulletBold('Their pro-rata at Series A ', '— "We expect to honor pro-rata participation rights at Series A for anchor SAFE holders. Standard institutional term."'),

      H2('C · Existing LP (Arlington, NRH, FW, Grapevine) — preserve relationships'),

      H3('Goal'),
      P('Communicate the roll-up clearly, honor the original deal terms (especially Arlington pref), and obtain consent + accreditation paperwork. Most LPs will support this — they invested in you, not the shops. Make it easy for them to say yes.'),

      H3('How to deliver'),
      P('Send Document 04 (LP Update Letter) personally — email or mailed letter — followed by a phone call within 48 hours. Do not put this in a portal or generic email blast. These are the people who funded the business; they deserve a direct touch.'),

      H3('Phone call structure (15-20 min per LP)'),
      P('"Did you have a chance to read the letter? Any questions? The two things I need from you are the accreditation form (5 minutes to fill out) and your consent to the rollup once we send formal paperwork. The Arlington 10% pref carries forward into the rollup structure as a capital floor — you are protected. We will email the accreditation form right after this call."'),

      H3('Special handling: Arlington/NRH LPs'),
      P('Eight of your fourteen LPs are in the joint Arlington/NRH LLC, which carries the 10% per year preferred return. This is a critical term to preserve. The LP letter explicitly states that the pref is honored as an extended capital floor: $25K invested → minimum $37.5K return at year 5 (simple interest). Be prepared to confirm this on the phone in your own words.'),

      H3('Special handling: Grapevine partial wire'),
      P('Two of four Grapevine LPs wired their $30K; two did not. For the ones who wired, treat as full LPs in the rollup. For the ones who did not, the slot is no longer available — communicate that the round closed for the shop and any new participation would be at the HoldCo level via the SAFE round. This is one conversation, not a fight; most will understand.'),

      new Paragraph({ children: [new PageBreak()] }),

      // ============ 4. SEQUENCING ============
      H1('4 · Recommended sequencing (12 weeks)'),

      P('The order matters. Do not start outside conversations before internal alignment is locked. Do not start fundraising before the structure is finalized. Do not announce anything to existing LPs before legal has reviewed.'),

      H2('Week 1 — Internal alignment'),
      BulletBold('Day 1-2: ', 'You and Jack work through Document 01 (Strategy Walkthrough) together. Lock the open items in Section 7 of that document.'),
      BulletBold('Day 3-4: ', 'Final cap table sign-off between you and Jack. Document any side-letters, vesting accelerators, or special terms.'),
      BulletBold('Day 5-7: ', 'Engage corporate counsel. Brief them on the rollup structure. Have them review the LP letter (Document 04) and accreditation questionnaire (Document 05) before any external use.'),

      H2('Week 2 — Quiet preparation'),
      BulletBold('Day 1-3: ', 'Counsel drafts HoldCo formation documents (Delaware LLC, operating agreement, SAFE template).'),
      BulletBold('Day 4-7: ', 'Deploy HTML strategy app to private URL with password protection. Send the URL to a small group of trusted advisors (3-5 people) for feedback before any investor sees it.'),

      H2('Week 3-4 — Anchor investor outreach'),
      BulletBold('Goal: ', 'land the anchor commitment ($250-500K).'),
      BulletBold('Target list: ', '5-10 known relationships who could write a $250K+ check. Operator angels, family offices, friendly PE folks.'),
      BulletBold('Process: ', 'one-on-one meetings. Deck 03. Follow-up diligence call. Term sheet conversation. Verbal commitment.'),
      BulletBold('Critical decision point: ', 'do not start broad SAFE outreach until you have an anchor commitment. The anchor signals legitimacy.'),

      H2('Week 5-6 — Existing LP outreach'),
      BulletBold('Send Document 04 (LP Update Letter) to all 14 LPs. ', 'Personalized email or mailed letter.'),
      BulletBold('Phone call each LP within 48 hours. ', 'Walk them through the rollup. Confirm Arlington pref. Send accreditation form.'),
      BulletBold('Collect signed accreditation questionnaires (Document 05). ', 'This is required for SEC compliance. Do not skip it.'),
      BulletBold('Begin gathering consent for the rollup. ', 'Counsel drafts the formal consent letters at this stage.'),

      H2('Week 7-8 — Open broad SAFE round'),
      BulletBold('With anchor secured, ', 'start the broader $25-50K conversations. Use Deck 02 (Standard) for these.'),
      BulletBold('Target: ', '10-20 small SAFE investors. Aim for ~$300-500K from this pool to complement the anchor.'),
      BulletBold('Each investor: ', 'accreditation questionnaire signed before signing SAFE. No exceptions.'),

      H2('Week 9-10 — Close the SAFE round'),
      BulletBold('Counsel sends SAFE documents to committed investors. ', 'Standard YC SAFE template, $2M post-money cap, 20% discount, MFN clause.'),
      BulletBold('Investors sign and wire. ', 'Funds held in HoldCo bank account.'),
      BulletBold('Pay legal fees, ', 'cover formation costs, begin executing the rollup.'),

      H2('Week 11-12 — Execute the rollup'),
      BulletBold('HoldCo issues membership interests ', 'to GGP, the Passive SPV (LPs), and reserves MIP pool.'),
      BulletBold('Each shop LLC contributes its assets ', 'to HoldCo under §721 tax treatment.'),
      BulletBold('Lender consents and landlord consents ', 'completed in parallel.'),
      BulletBold('First post-rollup investor update ', 'sent at end of Week 12 — sets the precedent for quarterly reporting.'),

      Callout('Reality check on timing', 'This is an aggressive 12-week plan that assumes everything goes smoothly. More realistically, plan for 16-20 weeks. Add buffer for legal review cycles, LP holdouts on consent, lender approval delays, and the inevitable surprises. The work above is correctly sequenced; just budget more time for each step.'),

      new Paragraph({ children: [new PageBreak()] }),

      // ============ 5. CRITICAL THINGS NOT TO SCREW UP ============
      H1('5 · Critical things not to screw up'),

      H2('Securities compliance'),
      P('All 14 LPs must be either accredited investors or sophisticated investors who receive proper disclosure under Rule 506(b). If any LP is not accredited and was not given the required disclosures, the entire offering can be unwound — and any new SAFE round is at risk. Do not skip Document 05 (Accreditation Questionnaire). Send it to every LP. Send it to every SAFE investor.'),

      H2('The Arlington pref'),
      P('Eight LPs were promised 10% per year preferred return on their original $25K investments to the Arlington/NRH joint LLC. This is a binding informal agreement and must be honored. The mechanic is a capital floor in the rollup: each Arlington LP receives the greater of their pro-rata equity share OR their original capital plus accumulated pref. Do not let counsel "clean this up" by dropping it during the rollup — that creates fraud risk and destroys trust.'),

      H2('Founder loan conversion'),
      P('The $30K combined founder loan ($15K each from you and Jack to the Arlington/NRH LLC) converts to equity at HoldCo formation. Do not repay this from SAFE proceeds. Repaying founder loans from new investor capital looks like founders cashing out, which is a red flag in any diligence.'),

      H2('Cap table cleanliness'),
      P('At HoldCo, there should be exactly three lines: GGP, Passive SPV, MIP pool. Do not let individual LPs sit on the cap table directly — pool them all into the SPV. Do not let individual GGP members appear on the HoldCo cap table — they appear only on GGP\'s cap table. The cleaner the HoldCo cap table looks, the easier the eventual PE exit will be.'),

      H2('Document control'),
      P('The HTML app and the decks all contain forward-looking financial projections. These are sensitive. Do not let them get forwarded, screenshotted, or reposted. Watermark anything that goes to investors. Send the HTML URL with an expectation that it is for their eyes only. If something leaks, address it directly — but minimize the chance by being careful upfront.'),

      H2('What counsel needs to bless'),
      BulletBold('SAFE template ', '— the YC post-money SAFE with cap, discount, and MFN.'),
      BulletBold('LP consent letters ', '— specific to each shop LLC, getting consent for the rollup contribution.'),
      BulletBold('§721 contribution memos ', '— per shop, documenting the tax treatment.'),
      BulletBold('HoldCo operating agreement ', '— governance, distribution waterfall, transfer restrictions, drag-along, tag-along.'),
      BulletBold('Accreditation questionnaire ', '— have counsel review Document 05 before sending. Adapt if needed for state-specific requirements.'),
      BulletBold('LP update letter ', '— have counsel review Document 04 before sending. Specifically the Arlington pref language.'),

      Callout('Budget reality', 'Legal fees for this entire process will run $15-30K conservatively, $30-50K if there are complications. Plan to pay this from SAFE proceeds after close — most reputable boutique firms will accept this arrangement for a well-prepared client.'),

      new Paragraph({ children: [new PageBreak()] }),

      // ============ 6. QUICK REFERENCE ============
      H1('6 · Quick reference cheat sheet'),

      H2('The deal terms (memorize these)'),
      new Table({
        width: { size: 9360, type: WidthType.DXA },
        columnWidths: [3120, 6240],
        rows: [
          new TableRow({ children: [Cell('SAFE round size', { width: 3120, bold: true, fill: INK, color: 'FFFFFF' }), Cell('$1M target ($500K anchor + $500K pool)', { width: 6240, mono: true, bold: true })]}),
          new TableRow({ children: [Cell('Cap', { width: 3120, bold: true, fill: INK, color: 'FFFFFF' }), Cell('$2M post-money — generous for early SAFE investors', { width: 6240, mono: true })]}),
          new TableRow({ children: [Cell('Discount', { width: 3120, bold: true, fill: INK, color: 'FFFFFF' }), Cell('20% off Series A price', { width: 6240, mono: true })]}),
          new TableRow({ children: [Cell('MFN clause', { width: 3120, bold: true, fill: INK, color: 'FFFFFF' }), Cell('Yes — early investors get the best terms', { width: 6240, mono: true })]}),
          new TableRow({ children: [Cell('Series A target', { width: 3120, bold: true, fill: INK, color: 'FFFFFF' }), Cell('$1M at $4M pre-money ($5M post), 6-12 months from SAFE close', { width: 6240, mono: true })]}),
          new TableRow({ children: [Cell('Exit target', { width: 3120, bold: true, fill: INK, color: 'FFFFFF' }), Cell('$80-120M in 4 years (PE or strategic acquirer)', { width: 6240, mono: true })]}),
          new TableRow({ children: [Cell('Arlington LP pref', { width: 3120, bold: true, fill: INK, color: 'FFFFFF' }), Cell('10% per year simple interest, preserved as capital floor', { width: 6240, mono: true })]}),
        ],
      }),

      H2('The cap table (3 lines at HoldCo)'),
      new Table({
        width: { size: 9360, type: WidthType.DXA },
        columnWidths: [2340, 1560, 5460],
        rows: [
          new TableRow({ children: [
            Cell('GGP (Operators)', { width: 2340, bold: true, fill: INK, color: 'FFFFFF' }),
            Cell('~50%', { width: 1560, bold: true, mono: true, color: GOLD_DEEP }),
            Cell('4 founders + 1 active operating partner + 4 strategic advisors (8% allocated, 6% reserved)', { width: 5460 }),
          ]}),
          new TableRow({ children: [
            Cell('Passive SPV (LPs)', { width: 2340, bold: true, fill: INK, color: 'FFFFFF' }),
            Cell('~40%', { width: 1560, bold: true, mono: true, color: GOLD_DEEP }),
            Cell('14 LPs + you/Jack as "LPs" of founder-funded shops, pooled into one line', { width: 5460 }),
          ]}),
          new TableRow({ children: [
            Cell('MIP Pool', { width: 2340, bold: true, fill: INK, color: 'FFFFFF' }),
            Cell('10%', { width: 1560, bold: true, mono: true, color: GOLD_DEEP }),
            Cell('Pheak 2% allocated · 8% reserved for executive hires through Series A', { width: 5460 }),
          ]}),
        ],
      }),

      H2('GGP internal (founders + active + advisors)'),
      new Table({
        width: { size: 9360, type: WidthType.DXA },
        columnWidths: [2340, 1170, 5850],
        rows: [
          new TableRow({ children: [Cell('Youyou', { width: 2340, bold: true, color: GOLD_DEEP }), Cell('35%', { width: 1170, mono: true, bold: true, color: GOLD_DEEP }), Cell('Co-founder · CEO/COO', { width: 5850 })]}),
          new TableRow({ children: [Cell('Jack', { width: 2340, bold: true, color: GOLD_DEEP }), Cell('25%', { width: 1170, mono: true, bold: true, color: GOLD_DEEP }), Cell('Founder · CEO', { width: 5850 })]}),
          new TableRow({ children: [Cell('Peiyun', { width: 2340, bold: true, color: GOLD_DEEP }), Cell('15%', { width: 1170, mono: true, bold: true, color: GOLD_DEEP }), Cell('Co-founder · Engineering', { width: 5850 })]}),
          new TableRow({ children: [Cell('Max', { width: 2340, bold: true, color: GOLD_DEEP }), Cell('5%', { width: 1170, mono: true, bold: true, color: GOLD_DEEP }), Cell('Co-founder · Analysis', { width: 5850 })]}),
          new TableRow({ children: [Cell('Muypin', { width: 2340, bold: true }), Cell('6%', { width: 1170, mono: true, bold: true }), Cell('Active Operating Partner · full-time ops', { width: 5850 })]}),
          new TableRow({ children: [Cell('Luke', { width: 2340, bold: true }), Cell('3%', { width: 1170, mono: true, bold: true }), Cell('Strategic Advisor · strategy', { width: 5850 })]}),
          new TableRow({ children: [Cell('Chanda', { width: 2340, bold: true }), Cell('2%', { width: 1170, mono: true, bold: true }), Cell('Strategic Advisor · FOH operations', { width: 5850 })]}),
          new TableRow({ children: [Cell('Jonathan', { width: 2340, bold: true }), Cell('2%', { width: 1170, mono: true, bold: true }), Cell('Strategic Advisor · operations (converts to MIP on full-time hire)', { width: 5850 })]}),
          new TableRow({ children: [Cell('Lam', { width: 2340, bold: true }), Cell('1%', { width: 1170, mono: true, bold: true }), Cell('Strategic Advisor · bakery', { width: 5850 })]}),
          new TableRow({ children: [Cell('Future advisors', { width: 2340, italics: true, color: MUTED }), Cell('6%', { width: 1170, mono: true, bold: true, color: MUTED }), Cell('Reserved for institutional-grade board advisors before Series A', { width: 5850, color: MUTED })]}),
        ],
      }),

      H2('Return math (SAFE → exit, 4-year hold)'),
      P('Generous cap means generous returns to early SAFE investors. These are not guarantees — these are scenarios based on cap math.'),
      new Table({
        width: { size: 9360, type: WidthType.DXA },
        columnWidths: [2340, 2340, 2340, 2340],
        rows: [
          new TableRow({ children: [
            Cell('SAFE Check', { width: 2340, bold: true, fill: INK, color: 'FFFFFF', align: AlignmentType.CENTER }),
            Cell('At $80M exit', { width: 2340, bold: true, fill: INK, color: 'FFFFFF', align: AlignmentType.CENTER }),
            Cell('At $120M (base)', { width: 2340, bold: true, fill: INK, color: 'FFFFFF', align: AlignmentType.CENTER }),
            Cell('At $200M (upside)', { width: 2340, bold: true, fill: INK, color: 'FFFFFF', align: AlignmentType.CENTER }),
          ]}),
          new TableRow({ children: [
            Cell('$30K', { width: 2340, mono: true, bold: true, align: AlignmentType.CENTER }),
            Cell('$960K · 32×', { width: 2340, mono: true, align: AlignmentType.CENTER }),
            Cell('$1.4M · 48×', { width: 2340, mono: true, bold: true, color: GOLD_DEEP, align: AlignmentType.CENTER }),
            Cell('$2.4M · 80×', { width: 2340, mono: true, bold: true, color: GOLD_DEEP, align: AlignmentType.CENTER }),
          ]}),
          new TableRow({ children: [
            Cell('$100K', { width: 2340, mono: true, bold: true, align: AlignmentType.CENTER, fill: CREAM }),
            Cell('$3.2M · 32×', { width: 2340, mono: true, align: AlignmentType.CENTER, fill: CREAM }),
            Cell('$4.8M · 48×', { width: 2340, mono: true, bold: true, color: GOLD_DEEP, align: AlignmentType.CENTER, fill: CREAM }),
            Cell('$8M · 80×', { width: 2340, mono: true, bold: true, color: GOLD_DEEP, align: AlignmentType.CENTER, fill: CREAM }),
          ]}),
          new TableRow({ children: [
            Cell('$250K', { width: 2340, mono: true, bold: true, align: AlignmentType.CENTER }),
            Cell('$8M · 32×', { width: 2340, mono: true, align: AlignmentType.CENTER }),
            Cell('$12M · 48×', { width: 2340, mono: true, bold: true, color: GOLD_DEEP, align: AlignmentType.CENTER }),
            Cell('$20M · 80×', { width: 2340, mono: true, bold: true, color: GOLD_DEEP, align: AlignmentType.CENTER }),
          ]}),
          new TableRow({ children: [
            Cell('$500K (anchor)', { width: 2340, mono: true, bold: true, align: AlignmentType.CENTER, fill: CREAM }),
            Cell('$16M · 32×', { width: 2340, mono: true, align: AlignmentType.CENTER, fill: CREAM }),
            Cell('$24M · 48×', { width: 2340, mono: true, bold: true, color: GOLD_DEEP, align: AlignmentType.CENTER, fill: CREAM }),
            Cell('$40M · 80×', { width: 2340, mono: true, bold: true, color: GOLD_DEEP, align: AlignmentType.CENTER, fill: CREAM }),
          ]}),
        ],
      }),

      Spacer(200),
      Callout('Why these returns look so high', 'The $2M cap is generous to early SAFE investors. This is intentional — you are raising before the brand is built, before consolidated audited financials exist, and before the institutional operating team is in place. Investors taking that risk now deserve outsized upside. By Series A, the cap math will be much less favorable to new investors. That is the trade.'),

      new Paragraph({ children: [new PageBreak()] }),

      // ============ 7. OPEN ITEMS ============
      H1('7 · Decisions still to lock (do this in Week 1)'),

      P('Before any external conversation, you and Jack need to finalize these items together. None are blockers, but each shifts the conversation.'),

      H3('A · Lam in advisor pool (1%) versus MIP (1%)'),
      Mixed(
        Plain('Current default: advisor pool at 1%. '), Plain('Rationale: described as "mutual-aid" and part-time, which fits the advisor framing better than the MIP framing.', { italics: true }), Plain(' '), Bold('Change to MIP if: '), Plain('Lam is actually on payroll as a Golden Glaze employee, in which case MIP (which vests over 4 years) is more accurate.'),
      ),

      H3('B · Advisor pool reserve at 6% (could be 4-10%)'),
      Mixed(
        Plain('Current default: 6%. '), Plain('Rationale: room for 2-4 institutional-grade board advisors at 1-3% each.', { italics: true }), Plain(' '), Bold('Decrease (4%) if: '), Plain('you want to preserve more for active partner promotions. '), Bold('Increase (8-10%) if: '), Plain('you envision recruiting 5+ institutional advisors before Series A.'),
      ),

      H3('C · Total SAFE round size — $300K, $500K, $750K, or $1M?'),
      P('The cap math is the same regardless of round size (per-dollar return is uniform). But total capital available and total dilution to founders changes. Larger round = more cash, more runway, more dilution. Working number: $1M ($500K anchor + $500K pool). Could also be done in $300K initial tranche with a follow-on to mitigate dilution risk if SAFE momentum is slower than expected.'),

      H3('D · Anchor investor identity'),
      P('Who is the first call? Operator angels in the QSR space? Family offices with food-service exposure? A specific known relationship? Anchor identity matters — anchor signaling pulls others in. Make this list together with Jack before any outreach.'),

      H3('E · Brand and IP'),
      P('Has the Golden Glaze brand been formally registered as a trademark? Is the website domain owned by HoldCo or by an individual founder? Brand assets need to live at HoldCo for the eventual exit. Audit this in Week 1.'),

      Spacer(400),

      // ============ CLOSING ============
      H1('A note from us'),

      Mixed(
        Plain('You have built something real in eight months. Seven shops, $1.3M ARR, four founders with the right mix of finance, ops, and engineering, and a team of operators including master bakers and existing shop owners. That is a lot more than most teams have at this stage.'),
      ),

      Mixed(
        Plain('The next six months are about taking what you have built and making it institutional-grade — the cap table, the governance, the operations leadership, the brand. This package gives you the artifacts you need to do that systematically. The hard part is the work behind the artifacts, not the artifacts themselves.'),
      ),

      Mixed(
        Plain('Take the time to read everything before you start any conversations. Discuss it with Jack until you have shared conviction on every decision. Then move with confidence.', { italics: true }),
      ),

      Spacer(300),

      new Paragraph({
        children: [new TextRun({ text: '— GOLDEN GLAZE DONUTS, MAY 2026', size: 16, color: GOLD_DEEP, font: 'Calibri', bold: true, characterSpacing: 60 })],
        alignment: AlignmentType.CENTER, spacing: { before: 400 },
      }),
    ],
  }],
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync('/home/claude/gg-package/docs/06-Deployment-Guide.docx', buffer);
  console.log('✓ Deployment guide built');
});
