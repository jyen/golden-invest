import React, { useState, useMemo } from 'react';
import { BookOpen, MapPin, Target, GitMerge, Users, TrendingUp, ArrowRight, Building2, Coins, AlertCircle, CheckCircle2, ChevronRight, Zap, Sliders, Plus, Minus, Award, Clock, UserCircle2, ChefHat } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, LabelList } from 'recharts';

const FONT_IMPORT = `
@import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&family=Lobster&family=JetBrains+Mono:wght@400;500;600&display=swap');
`;

// ============= BRAND TOKENS =============
const C = {
  bg:           '#FAF6EA',  // softer cream page
  card:         '#FFFFFF',  // card surface
  cardWarm:     '#F8EFD7',  // warm off-white cards (more distinct from bg)
  cream:        '#F5E2B8',  // brand cream highlight
  ink:          '#1A1208',  // near-black warm
  text:         '#3D2811',  // primary text
  textSoft:     '#6B4A24',  // secondary
  textMuted:    '#8B6E3D',  // tertiary (darker, more readable)
  gold:         '#D99C2B',  // brand gold
  goldDeep:     '#A87618',  // gold for text
  goldSoft:     '#E8B854',
  border:       'rgba(61,40,17,0.16)',  // stronger border
  borderSoft:   'rgba(61,40,17,0.09)',
};

// ============= DATA =============
const STORES = [
  { id: 'arl',  name: 'Arlington',         acquired: 'Sep 2025', startMRR: 18, currentMRR: 30, type: 'passive', valuation: 330, lpCount: 8, lpInvest: 25 },
  { id: 'nrh',  name: 'NRH (Rufe Snow)',   acquired: 'Sep 2025', startMRR: 3,  currentMRR: 11, type: 'passive', valuation: 110, lpCount: 0, lpInvest: 0 },
  { id: 'fw',   name: 'Fort Worth',        acquired: 'Oct 2025', startMRR: 17, currentMRR: 22.5, type: 'passive', valuation: 230, lpCount: 4, lpInvest: 30 },
  { id: 'grp',  name: 'Grapevine',         acquired: 'Nov 2025', startMRR: 12, currentMRR: 18, type: 'passive', valuation: 190, lpCount: 2, lpInvest: 30 },
  { id: 'car',  name: 'Carrollton',        acquired: 'Feb 2026', startMRR: null, currentMRR: 10, type: 'founder', valuation: 140, lpCount: 0, lpInvest: 0 },
  { id: 'dal',  name: 'Dallas (Frankford)', acquired: 'Feb 2026', startMRR: null, currentMRR: 10, type: 'founder', valuation: 120, lpCount: 0, lpInvest: 0 },
  { id: 'blu',  name: 'Bluemound',         acquired: 'Apr 2026', startMRR: 0,  currentMRR: 8, type: 'founder', valuation: 80, lpCount: 0, lpInvest: 0 },
];

// Revenue numbers represent NET of merchant fees / platform commissions.
// Gross top-line revenue is estimated 10–20% higher pending May close verification.
const TOTAL_MRR_NOW = STORES.reduce((s, x) => s + x.currentMRR, 0);
const TOTAL_VAL = STORES.reduce((s, x) => s + x.valuation, 0);
const GROSS_MRR_EST = TOTAL_MRR_NOW * 1.15; // midpoint of 10-20% gross-up estimate
const GROSS_ARR_EST = GROSS_MRR_EST * 12;
const TOTAL_LPS = 14; // 8 Arl/NRH + 4 FW + 2 Grapevine (2 of 4 wired so far)
const TOTAL_LP_CASH = 8 * 25 + 4 * 30 + 2 * 30; // = $380K wired ($60K remaining Grapevine slots TBD)
const ANNUAL_RUNRATE = TOTAL_MRR_NOW * 12;

// ============= UTILS =============
const fmt$ = (n) => {
  if (n >= 1000) return `$${(n / 1000).toFixed(2)}M`;
  if (n >= 1)    return `$${Math.round(n)}K`;
  return '$0';
};
const fmtPct = (n) => `${(n * 100).toFixed(1)}%`;

// ============= CALC HELPERS =============
function calcScenario(s) {
  // Effective valuation per shop — scenario override wins, fallback to STORES default
  const v = (id) => s.storeValuations?.[id] ?? STORES.find(x => x.id === id)?.valuation ?? 0;

  const totalShop = STORES.reduce((sum, x) => sum + v(x.id), 0);
  const lpEquity = STORES.reduce((sum, x) => sum + (x.lpCount > 0 ? v(x.id) * (100 - s.ggpToShop) / 100 : 0), 0);
  const ggpDirect = STORES.reduce((sum, x) => sum + v(x.id) * s.ggpToShop / 100, 0);
  const uuJackDirect = STORES.reduce((sum, x) => sum + (x.lpCount === 0 ? v(x.id) * (100 - s.ggpToShop) / 100 : 0), 0);
  const ggpPlus = ggpDirect + uuJackDirect;

  const uuInGgp = ggpDirect * s.ggpUUJackPct / 100 + uuJackDirect;
  const advInGgp = ggpDirect * (100 - s.ggpUUJackPct) / 100;
  const uuPctOfGgp = ggpPlus > 0 ? uuInGgp / ggpPlus : 0;
  const advPctOfGgp = ggpPlus > 0 ? advInGgp / ggpPlus : 0;

  const day1 = {
    uuJack: totalShop > 0 ? (ggpPlus / totalShop) * uuPctOfGgp : 0,
    advisors: totalShop > 0 ? (ggpPlus / totalShop) * advPctOfGgp : 0,
    lps: totalShop > 0 ? lpEquity / totalShop : 0,
    mip: 0, safe: 0, seriesA: 0,
  };

  const m = (100 - s.mipPoolPct) / 100;
  const stage2 = {
    uuJack: day1.uuJack * m,
    advisors: day1.advisors * m,
    lps: day1.lps * m,
    mip: s.mipPoolPct / 100,
    safe: 0, seriesA: 0,
  };

  const capRoute = s.safeAmount / s.safeCap;
  const discRoute = s.safeAmount / (s.seriesAPreMoney * (100 - s.safeDiscount) / 100);
  const safePct = Math.max(capRoute, discRoute);
  const safeMult = 1 - safePct;
  const stage3 = {
    uuJack: stage2.uuJack * safeMult,
    advisors: stage2.advisors * safeMult,
    lps: stage2.lps * safeMult,
    mip: stage2.mip * safeMult,
    safe: safePct,
    seriesA: 0,
  };

  const seriesAPct = s.seriesAAmount / (s.seriesAPreMoney + s.seriesAAmount);
  const aMult = 1 - seriesAPct;
  const stage4 = {
    uuJack: stage3.uuJack * aMult,
    advisors: stage3.advisors * aMult,
    lps: stage3.lps * aMult,
    mip: stage3.mip * aMult,
    safe: stage3.safe * aMult,
    seriesA: seriesAPct,
  };

  const exit = Object.fromEntries(Object.keys(stage4).map(k => [k, stage4[k] * s.exitValuation]));
  const perLPExit = TOTAL_LPS > 0 ? exit.lps / TOTAL_LPS : 0;
  const avgLPInvest = TOTAL_LP_CASH / TOTAL_LPS;
  const lpMOIC = avgLPInvest > 0 ? perLPExit / avgLPInvest : 0;
  const safeMOIC = s.safeAmount > 0 ? exit.safe / s.safeAmount : 0;
  const seriesAMOIC = s.seriesAAmount > 0 ? exit.seriesA / s.seriesAAmount : 0;

  return { day1, stage2, stage3, stage4, exit, safePct, seriesAPct, perLPExit, lpMOIC, safeMOIC, seriesAMOIC, totalShop };
}

// ============= DONUT LOGO =============
function DonutLogo({ size = 40 }) {
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} style={{ display: 'block', flexShrink: 0 }} aria-label="Golden Glaze">
      <circle cx="50" cy="50" r="38" fill={C.gold} stroke={C.text} strokeWidth="3" />
      <circle cx="50" cy="50" r="11" fill={C.bg} stroke={C.text} strokeWidth="3" />
      <path d="M 36 41 Q 41 35, 50 34" stroke={C.cream} strokeWidth="3" strokeLinecap="round" fill="none" />
      <path d="M 56 35 Q 60 36, 64 39" stroke={C.cream} strokeWidth="2.2" strokeLinecap="round" fill="none" />
      <line x1="32" y1="42" x2="36" y2="40" stroke={C.text} strokeWidth="1.8" strokeLinecap="round" />
      <line x1="58" y1="32" x2="62" y2="36" stroke={C.text} strokeWidth="1.8" strokeLinecap="round" />
      <line x1="40" y1="30" x2="44" y2="33" stroke={C.text} strokeWidth="1.8" strokeLinecap="round" />
      <line x1="68" y1="46" x2="72" y2="44" stroke={C.text} strokeWidth="1.8" strokeLinecap="round" />
      <line x1="29" y1="55" x2="33" y2="58" stroke={C.text} strokeWidth="1.8" strokeLinecap="round" />
      <line x1="62" y1="60" x2="66" y2="62" stroke={C.text} strokeWidth="1.8" strokeLinecap="round" />
      <path d="M 17 64 Q 24 71, 33 66 T 51 68 T 70 65 T 84 62" stroke={C.text} strokeWidth="2.2" fill="none" strokeLinecap="round" />
    </svg>
  );
}

// ============= UI PRIMITIVES =============
function Eyebrow({ children }) {
  return (
    <div className="text-[11px] font-semibold mb-3" style={{ color: C.goldDeep, letterSpacing: '0.18em', textTransform: 'uppercase' }}>
      {children}
    </div>
  );
}

function H1({ children, size = 'lg' }) {
  const sizes = { lg: 'clamp(2.25rem, 5vw, 3.25rem)', xl: 'clamp(2.75rem, 7vw, 4.5rem)' };
  return (
    <h1 style={{ fontSize: sizes[size], fontWeight: 700, lineHeight: 1.02, letterSpacing: '-0.025em', color: C.ink }}>{children}</h1>
  );
}

function H2({ children }) {
  return (
    <h2 style={{ fontSize: '1.5rem', fontWeight: 600, color: C.ink, letterSpacing: '-0.01em' }}>{children}</h2>
  );
}

function Lede({ children }) {
  return <p className="max-w-2xl leading-relaxed" style={{ fontSize: '1rem', color: C.textSoft, fontWeight: 400 }}>{children}</p>;
}

function SectionTitle({ eyebrow, title, lede }) {
  return (
    <div className="mb-10">
      {eyebrow && <Eyebrow>{eyebrow}</Eyebrow>}
      <h2 style={{ fontSize: 'clamp(2rem, 4.5vw, 2.75rem)', fontWeight: 700, lineHeight: 1.05, letterSpacing: '-0.02em', color: C.ink, marginBottom: lede ? '1rem' : 0, maxWidth: '46rem' }}>{title}</h2>
      {lede && <Lede>{lede}</Lede>}
    </div>
  );
}

function Card({ children, className = '', tone = 'card', style = {} }) {
  const tones = {
    card:    { backgroundColor: C.card,     border: `1px solid ${C.border}` },
    warm:    { backgroundColor: C.cardWarm, border: `1px solid ${C.border}` },
    cream:   { backgroundColor: C.cream,    border: `1px solid rgba(168,118,24,0.18)` },
    dark:    { backgroundColor: C.ink,      color: C.bg, border: 'none' },
    gold:    { backgroundColor: C.gold,     color: C.ink, border: 'none' },
  };
  return (
    <div className={`rounded-2xl p-6 sm:p-7 ${className}`} style={{ ...tones[tone], ...style }}>
      {children}
    </div>
  );
}

function Stat({ label, value, sub, tone = 'normal' }) {
  const isAccent = tone === 'accent';
  return (
    <div className="rounded-2xl p-5"
      style={{
        backgroundColor: isAccent ? C.ink : C.card,
        color: isAccent ? C.bg : C.ink,
        border: isAccent ? 'none' : `1px solid ${C.border}`,
      }}>
      <div className="text-[10px] font-semibold mb-3"
        style={{
          letterSpacing: '0.16em',
          color: isAccent ? C.goldSoft : C.textMuted,
          textTransform: 'uppercase',
        }}>{label}</div>
      <div style={{
        fontFamily: '"JetBrains Mono", monospace',
        fontSize: 'clamp(1.5rem, 3.5vw, 2rem)',
        fontWeight: 600,
        letterSpacing: '-0.02em',
        lineHeight: 1,
        color: isAccent ? '#FFF' : C.ink,
      }}>{value}</div>
      {sub && (
        <div className="mt-2.5" style={{ fontSize: '0.7rem', color: isAccent ? 'rgba(245,226,184,0.7)' : C.textMuted, letterSpacing: '0.04em', fontWeight: 500 }}>{sub}</div>
      )}
    </div>
  );
}

function Pill({ children, tone = 'neutral' }) {
  const styles = {
    neutral: { backgroundColor: 'rgba(61,40,17,0.06)', color: C.text },
    gold:    { backgroundColor: 'rgba(217,156,43,0.16)', color: C.goldDeep },
  };
  return (
    <span className="inline-flex items-center px-2.5 py-1 rounded-full" style={{ ...styles[tone], fontSize: '10px', fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase' }}>{children}</span>
  );
}

function Stepper({ value, onChange, step = 1, min = 0, max = 999999, prefix = '', suffix = '', wide = false }) {
  return (
    <div className="flex items-center gap-1">
      <button
        onClick={() => onChange(Math.max(min, value - step))}
        className="w-7 h-7 grid place-items-center rounded-md transition-colors"
        style={{ backgroundColor: 'transparent', border: `1px solid ${C.border}`, color: C.textSoft }}
      >
        <Minus size={11} />
      </button>
      <div className={`relative ${wide ? 'w-24' : 'w-16'}`}>
        {prefix && <span className="absolute left-2 top-1/2 -translate-y-1/2 pointer-events-none" style={{ fontSize: '11px', color: C.textMuted, fontFamily: '"JetBrains Mono", monospace' }}>{prefix}</span>}
        <input
          type="number"
          value={value}
          step={step}
          min={min}
          max={max}
          onChange={(e) => onChange(Number(e.target.value))}
          className="w-full h-7 text-center outline-none rounded-md"
          style={{
            backgroundColor: C.card,
            border: `1px solid ${C.border}`,
            color: C.ink,
            fontFamily: '"JetBrains Mono", monospace',
            fontSize: '0.85rem',
            fontWeight: 600,
            paddingLeft: prefix ? '18px' : '4px',
            paddingRight: suffix ? '18px' : '4px',
          }}
        />
        {suffix && <span className="absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" style={{ fontSize: '11px', color: C.textMuted, fontFamily: '"JetBrains Mono", monospace' }}>{suffix}</span>}
      </div>
      <button
        onClick={() => onChange(Math.min(max, value + step))}
        className="w-7 h-7 grid place-items-center rounded-md transition-colors"
        style={{ backgroundColor: 'transparent', border: `1px solid ${C.border}`, color: C.textSoft }}
      >
        <Plus size={11} />
      </button>
    </div>
  );
}

function ScriptWordmark({ color = C.text, size = 'md' }) {
  const sizes = { sm: '1.25rem', md: '1.75rem', lg: '2.4rem', xl: '3.2rem' };
  return (
    <span style={{ fontFamily: '"Lobster", cursive', fontSize: sizes[size], color, lineHeight: 1, letterSpacing: '-0.005em' }}>Golden Glaze</span>
  );
}

// ============= TAB 1: WELCOME =============
function TabWelcome({ onNavigate, scenario }) {
  const tabMap = [
    { num: '02', name: 'Foundations',       icon: BookOpen,    desc: 'Glossary of every term, acronym, and mechanic. Read this once and never feel lost in the rest.' },
    { num: '03', name: 'Where We Are',      icon: MapPin,      desc: 'Honest portfolio snapshot — seven shops, ~$1.5M gross run-rate, what works and what we still need to fix.' },
    { num: '04', name: 'The Team',          icon: UserCircle2, desc: 'Founders, founding partner, operating partners, master operators, and the equity structure that holds them together.' },
    { num: '05', name: 'Vision & Exit',     icon: Target,      desc: 'The four-pillar platform thesis. $80–120M in 4 years, Shipley scale ($200–400M) in 7. With real comps.' },
    { num: '06', name: 'The Roll-Up',       icon: GitMerge,    desc: 'How seven LLCs become one HoldCo. Three-line cap table, capital floor protection, §721 mechanics, and what happens if money wants in *now*.' },
    { num: '07', name: 'Modeler',           icon: Sliders,     desc: 'Adjustable scenario sandbox. Change SAFE amount, Series A terms, MIP pool, exit valuation. Every number in the doc updates live.' },
    { num: '08', name: 'Walkthrough',       icon: ChevronRight,desc: 'Presentation-ready calculators for one-on-one investor conversations. Section A for existing LPs, Section B for new SAFE investors.' },
    { num: '09', name: 'For Existing LPs',  icon: Users,       desc: 'Consent memo for the 16 current LPs. Founder letter, performance update, what we are asking, and modeled returns.' },
    { num: '10', name: 'For New Investors', icon: TrendingUp,  desc: 'The pitch with an interactive deal calculator — investor enters check size, sees their stake and exit returns. Same SAFE terms across all checks.' },
  ];

  const paths = [
    {
      label: 'Walking through with an existing LP',
      audience: 'For one of the 14 LPs in Arlington/NRH, Fort Worth, or Grapevine',
      sequence: ['03', '06', '08', '09'],
      kicker: 'The Walkthrough tab\'s Section A is the centerpiece — pick their shop, see their exact stake.',
    },
    {
      label: 'Walking through with a new investor',
      audience: 'For the $500K anchor or any pool investor at $30K minimum',
      sequence: ['03', '04', '05', '10'],
      kicker: 'The For New Investors tab has the interactive deal calculator. Defaults to $500K but adjusts to any check size.',
    },
    {
      label: 'Internal modeling with Jack and the team',
      audience: 'For your own thinking, board prep, and term-sheet negotiation',
      sequence: ['06', '07', '08'],
      kicker: 'The Modeler is your what-if sandbox. Walkthrough Section A is your LP-by-LP view.',
    },
  ];

  return (
    <div>
      {/* Hero */}
      <div className="mb-12">
        <Eyebrow>Welcome · How to read this doc</Eyebrow>
        <h1 style={{ fontSize: 'clamp(2.5rem, 6vw, 4rem)', fontWeight: 700, lineHeight: 1.02, letterSpacing: '-0.025em', color: C.ink, marginTop: '12px', marginBottom: '20px' }}>
          The operating system for our roll-up.
        </h1>
        <p className="max-w-3xl" style={{ fontSize: '17px', color: C.textSoft, lineHeight: 1.55, fontWeight: 400 }}>
          This document holds the math, the structure, and the stories we are telling investors. It is also the calculator we use to walk people through their stakes one-on-one. Pick a path below, or browse any tab in the navigation above.
        </p>
      </div>

      {/* At a glance */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-12">
        <Stat label="Stores Acquired" value="7" sub="DFW · 8 months" tone="accent" />
        <Stat label="Annual Run-Rate" value={fmt$(ANNUAL_RUNRATE)} sub={`${fmt$(TOTAL_MRR_NOW)}/mo · growing`} />
        <Stat label="Existing LPs" value="16" sub={`${fmt$(TOTAL_LP_CASH)} deployed`} />
        <Stat label="Target Exit" value={fmt$(scenario.exitValuation)} sub="4 years · base case" />
      </div>

      {/* Reading paths */}
      <div className="mb-12">
        <H2>Three reading paths.</H2>
        <p className="mt-1 mb-6" style={{ fontSize: '13px', color: C.textSoft }}>Audience-specific sequences — each path tells one coherent story end to end.</p>
        <div className="space-y-3">
          {paths.map((p, i) => (
            <div key={i} className="rounded-2xl p-5 sm:p-6" style={{ backgroundColor: C.card, border: `1px solid ${C.border}` }}>
              <div className="flex items-start justify-between gap-4 flex-wrap mb-4">
                <div className="flex-1 min-w-0">
                  <div style={{ fontSize: '10.5px', fontWeight: 700, color: C.goldDeep, letterSpacing: '0.16em', textTransform: 'uppercase', marginBottom: '8px' }}>Path {String.fromCharCode(65 + i)}</div>
                  <h3 style={{ fontSize: '20px', fontWeight: 700, color: C.ink, lineHeight: 1.15, letterSpacing: '-0.01em' }}>{p.label}</h3>
                  <p style={{ fontSize: '13px', color: C.textSoft, marginTop: '6px', lineHeight: 1.5 }}>{p.audience}</p>
                </div>
              </div>
              <div className="flex items-center gap-2 flex-wrap mb-4">
                {p.sequence.map((n, j) => {
                  const tab = tabMap.find(t => t.num === n);
                  if (!tab) return null;
                  const Icon = tab.icon;
                  return (
                    <React.Fragment key={n}>
                      <button
                        onClick={() => onNavigate(tab.num)}
                        className="flex items-center gap-2 px-3 py-2 rounded-lg transition-colors"
                        style={{ backgroundColor: C.cardWarm, border: `1px solid ${C.border}`, color: C.ink, fontSize: '12.5px', fontWeight: 600 }}
                      >
                        <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '10px', color: C.goldDeep, fontWeight: 700 }}>{n}</span>
                        <Icon size={13} />
                        {tab.name}
                      </button>
                      {j < p.sequence.length - 1 && <ArrowRight size={14} style={{ color: C.textMuted }} />}
                    </React.Fragment>
                  );
                })}
              </div>
              <p style={{ fontSize: '12.5px', color: C.text, lineHeight: 1.5, paddingTop: '14px', borderTop: `1px solid ${C.borderSoft}` }}>
                <strong style={{ color: C.ink }}>Why this path:</strong> {p.kicker}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Full tab map */}
      <div className="mb-10">
        <H2>The full map.</H2>
        <p className="mt-1 mb-6" style={{ fontSize: '13px', color: C.textSoft }}>Every tab, what it contains, why it exists.</p>
        <div className="grid sm:grid-cols-2 gap-3">
          {tabMap.map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.num}
                onClick={() => onNavigate(tab.num)}
                className="rounded-xl p-4 text-left transition-colors"
                style={{ backgroundColor: C.card, border: `1px solid ${C.border}` }}
              >
                <div className="flex items-baseline gap-3 mb-2">
                  <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '11px', fontWeight: 700, color: C.goldDeep, letterSpacing: '0.1em' }}>{tab.num}</span>
                  <Icon size={14} style={{ color: C.textSoft }} />
                  <span style={{ fontSize: '14.5px', fontWeight: 700, color: C.ink }}>{tab.name}</span>
                </div>
                <p style={{ fontSize: '12.5px', color: C.textSoft, lineHeight: 1.5 }}>{tab.desc}</p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Live scenario reminder */}
      <Card tone="cream">
        <div className="flex items-start gap-4 flex-wrap">
          <div className="w-10 h-10 grid place-items-center rounded-xl shrink-0" style={{ backgroundColor: C.gold, color: C.ink }}>
            <Sliders size={16} />
          </div>
          <div className="flex-1 min-w-0">
            <div style={{ fontSize: '14.5px', fontWeight: 700, color: C.ink, marginBottom: '4px' }}>One scenario drives the whole doc</div>
            <p style={{ fontSize: '12.5px', color: C.text, lineHeight: 1.5 }}>
              Currently set to <strong style={{ fontFamily: '"JetBrains Mono", monospace' }}>{fmt$(scenario.safeAmount)} SAFE · {fmt$(scenario.exitValuation)} exit</strong>. Change it in the <strong>Modeler</strong> and every number across all tabs updates live — the LP walkthrough, the For New Investors calculator, every projection.
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}

// ============= TAB 2: FOUNDATIONS =============
const ACRONYM_GROUPS = [
  {
    title: 'Entities',
    icon: Building2,
    items: [
      { term: 'HoldCo',     full: 'Holding Company',                    def: 'Top-level entity that owns all 7 store LLCs + the kitchen + Golden POS. This is what investors will eventually own equity in. Will be Golden Glaze Holdings LLC (Delaware).' },
      { term: 'GGP',        full: 'Golden Glaze Partners',              def: 'Operator vehicle. Founders at 80%, advisors at 20%. Holds the 50% sweat-equity slot in every shop. After roll-up, becomes one consolidated line on HoldCo.' },
      { term: 'GCM',        full: 'Golden Capital Management',          def: 'Day-to-day management entity (buys supplies, pays staff, runs ops). Folds into HoldCo at roll-up — operators get upside via the MIP, not separate GCM equity.' },
      { term: 'SPV',        full: 'Special Purpose Vehicle',            def: 'Clean entity that pools all 14 passive LPs into one cap table line on HoldCo. Instead of 14 separate investors, HoldCo sees one "Passive SPV" line.' },
      { term: 'MIP',        full: 'Management Incentive Plan',          def: 'Equity pool (10%) reserved at HoldCo for active operators outside the GGP partner tier — Pheak, Chanda, Jonathan (incoming), Lam, and future executive hires. Vests over time, given as profits interests.' },
      { term: 'LLC',        full: 'Limited Liability Company',          def: 'The legal structure for each entity. Pass-through tax, limited liability for owners.' },
    ],
  },
  {
    title: 'Investor Types & Compliance',
    icon: Users,
    items: [
      { term: 'LP',         full: 'Limited Partner',                    def: 'Passive investor. Puts in cash, has limited say in operations, gets equity. Our 16 current LPs.' },
      { term: 'GP',         full: 'General Partner',                    def: 'Active operator. Manages the business. We (GGP) are the GP across all stores.' },
      { term: 'Accredited', full: 'Accredited Investor',                def: 'SEC definition: $200K income / $1M net worth (excl. primary home). Almost all LPs need to verify this.' },
      { term: '506(b)',     full: 'Reg D Rule 506(b)',                  def: 'SEC exemption. Lets us raise privately from accredited investors with no general solicitation. All LPs need accreditation questionnaires on file.' },
    ],
  },
  {
    title: 'Capital Instruments',
    icon: Coins,
    items: [
      { term: 'SAFE',       full: 'Simple Agreement for Future Equity', def: 'A note that converts to equity at the next priced round (Series A). Defers valuation discussion. Cheap, fast, founder-friendly.' },
      { term: 'Cap',        full: 'Valuation Cap',                      def: 'Maximum valuation at which the SAFE converts. Lower cap = better for the investor.' },
      { term: 'Discount',   full: 'Conversion Discount',                def: 'SAFE converts at X% below the Series A price. Investor gets the better of cap or discount.' },
      { term: 'MFN',        full: 'Most Favored Nation',                def: 'Clause that gives the SAFE holder the best terms of any future SAFE we issue.' },
      { term: 'Pre-money',  full: 'Pre-Money Valuation',                def: 'What the company is worth BEFORE new money comes in. Pre-money + raise = post-money.' },
      { term: 'Series A',   full: 'Series A Round',                     def: 'First priced equity round from institutional investors. Triggers SAFE conversion.' },
    ],
  },
  {
    title: 'Exit Concepts',
    icon: TrendingUp,
    items: [
      { term: 'EBITDA',     full: 'Earnings Before Interest, Tax, D&A', def: 'Proxy for operational cash flow. The number buyers value the business on. Target: $7–10M at year 4.' },
      { term: 'Multiple',   full: 'EBITDA Multiple',                    def: 'Valuation ÷ EBITDA. Pure operator: 5–7×. Branded franchise: 10–14×. Tech-enabled platform: 15–20×.' },
      { term: 'MOIC',       full: 'Multiple of Invested Capital',       def: 'Cash returned ÷ cash invested. A 5× MOIC = $25K invested, $125K returned.' },
      { term: 'Strategic',  full: 'Strategic Acquirer',                 def: 'Industry buyer (Krispy Kreme, Shipley parent, Dawn). Pays a premium for synergy.' },
      { term: 'PE',         full: 'Private Equity',                     def: 'Financial buyer (Peak Rock, Roark, Levine Leichtman). Buys to grow + flip in 4–7 years.' },
    ],
  },
  {
    title: 'Deal Mechanics',
    icon: GitMerge,
    items: [
      { term: '§721',           full: 'IRC Section 721 Contribution',   def: 'Tax-free transfer of LLC interests into a partnership/LLC. How we roll up — each shop\'s members contribute their interests into HoldCo with no tax hit.' },
      { term: 'Drag-along',     full: 'Drag-Along Right',               def: 'Majority can force minority to sell when there\'s an exit. Critical for clean PE exits.' },
      { term: 'Tag-along',      full: 'Tag-Along Right',                def: 'Minority can join when majority sells. Protects LPs.' },
      { term: 'ROFR',           full: 'Right of First Refusal',         def: 'If someone tries to sell, the company/other holders get first chance to buy at the same terms.' },
      { term: 'Capital Floor',  full: 'Capital Floor Mechanism',        def: 'LPs get the GREATER of (a) pro-rata equity share, OR (b) original investment back. Critical for getting LP consent on the roll-up.' },
      { term: 'Pref Return',    full: 'Preferred Return',                def: 'A guaranteed return rate (e.g., 10%/year) that LPs accrue on top of their capital floor. Arlington LPs were promised 10%/year — extends their floor from $25K to $25K + accrued pref. Simple interest unless otherwise stated.' },
      { term: 'Waterfall',      full: 'Distribution Waterfall',         def: 'Order in which exit proceeds get distributed.' },
    ],
  },
  {
    title: 'Franchise & Operations',
    icon: Award,
    items: [
      { term: 'FDD',         full: 'Franchise Disclosure Document',     def: 'Federally-required document we have to register before selling franchises. ~$50–150K legal investment. Takes 4–6 months.' },
      { term: 'Royalty',     full: 'Royalty Rate',                      def: 'Recurring % of franchisee revenue paid to us. Industry standard: 5–7%. Dave\'s Hot Chicken charges 6%.' },
      { term: 'AUV',         full: 'Average Unit Volume',               def: 'Per-store annualized revenue. Current portfolio AUV: ~$200K. Mature target: $800K–1M.' },
      { term: 'GPO',         full: 'Group Purchasing Organization',     def: 'Central buying group for franchisees. Suppliers pay us rebates (1–5% of franchisee spend).' },
      { term: 'SSS',         full: 'Same-Store Sales Growth',           def: 'Revenue growth in stores open >12 months. PE buyers obsess over this.' },
    ],
  },
];

function TabFoundations() {
  return (
    <div>
      <SectionTitle
        eyebrow="02 — Foundations"
        title="Terms, acronyms, and how the pieces fit together."
        lede="The vocabulary of the deal we are building. Every word here will come up in conversations with attorneys, investors, and acquirers — better to know them cold than to fake it."
      />

      <div className="space-y-10">
        {ACRONYM_GROUPS.map(group => {
          const Icon = group.icon;
          return (
            <div key={group.title}>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-9 h-9 grid place-items-center rounded-lg" style={{ backgroundColor: C.cream, color: C.text }}>
                  <Icon size={16} strokeWidth={2} />
                </div>
                <H2>{group.title}</H2>
              </div>
              <div className="grid sm:grid-cols-2 gap-3">
                {group.items.map(item => (
                  <div key={item.term} className="rounded-xl p-4" style={{ backgroundColor: C.card, border: `1px solid ${C.border}` }}>
                    <div className="flex items-baseline gap-2 mb-1.5">
                      <span style={{ fontSize: '15px', fontWeight: 700, color: C.goldDeep, fontFamily: '"JetBrains Mono", monospace' }}>{item.term}</span>
                      <span style={{ fontSize: '11px', color: C.textMuted, fontWeight: 500 }}>{item.full}</span>
                    </div>
                    <p style={{ fontSize: '13px', lineHeight: 1.55, color: C.text, fontWeight: 400 }}>{item.def}</p>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ============= TAB 3: WHERE WE ARE =============
function TabWhereWeAre({ scenario }) {
  const valOf = (id) => scenario.storeValuations?.[id] ?? STORES.find(s => s.id === id)?.valuation ?? 0;
  const totalVal = STORES.reduce((sum, s) => sum + valOf(s.id), 0);

  const REVENUE_CHART_DATA = STORES.map(s => ({
    name: s.name.split(' ')[0].replace('(Rufe', 'NRH'),
    fullName: s.name,
    Start: s.startMRR ?? 0,
    Current: s.currentMRR,
    growth: s.startMRR ? ((s.currentMRR - s.startMRR) / s.startMRR * 100).toFixed(0) : 'New',
  }));

  return (
    <div>
      <SectionTitle
        eyebrow="03 — Where We Are"
        title="Seven shops in eight months. $1.3M run-rate."
        lede="The honest snapshot of the business today — what we have built, what is working, and what we need to fix before institutional money gets serious about us."
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-3">
        <Stat label="Stores Acquired" value="7" sub="in 8 months" tone="accent" />
        <Stat label="Net Run-Rate" value={fmt$(ANNUAL_RUNRATE)} sub={`${fmt$(TOTAL_MRR_NOW)}/mo · after fees`} />
        <Stat label="Aggregate Valuation" value={fmt$(totalVal)} sub="store-level" />
        <Stat label="Active LPs" value={`${TOTAL_LPS}`} sub={`${fmt$(TOTAL_LP_CASH)} deployed`} />
      </div>
      <p className="mb-8" style={{ fontSize: '11.5px', color: C.textMuted, fontStyle: 'italic', lineHeight: 1.5 }}>
        Net run-rate is after merchant fees, processing, and platform commissions (DoorDash / Uber Eats). Gross top-line revenue is estimated <strong style={{ color: C.text, fontStyle: 'normal' }}>~$1.5M ARR · {fmt$(GROSS_MRR_EST)}/mo</strong> (10–20% higher than net). Verified gross figures pending May 2026 close.
      </p>

      <Card className="mb-6">
        <H2>Revenue trajectory</H2>
        <p className="mt-1 mb-5" style={{ fontSize: '13px', color: C.textSoft }}>Monthly revenue. Brown bars at acquisition, gold bars current.</p>
        <div style={{ width: '100%', height: 300 }}>
          <ResponsiveContainer>
            <BarChart data={REVENUE_CHART_DATA} margin={{ top: 28, right: 8, left: -8, bottom: 8 }}>
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: C.textSoft, fontWeight: 500 }} axisLine={{ stroke: C.border }} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: C.textMuted, fontFamily: 'JetBrains Mono' }} axisLine={false} tickLine={false} tickFormatter={(v) => `$${v}K`} />
              <Bar dataKey="Start" fill={C.text} radius={[4, 4, 0, 0]}>
                <LabelList dataKey="Start" position="top" style={{ fontSize: 10, fill: C.textSoft, fontFamily: 'JetBrains Mono', fontWeight: 500 }} formatter={(v) => v ? `$${v}K` : ''} />
              </Bar>
              <Bar dataKey="Current" fill={C.gold} radius={[4, 4, 0, 0]}>
                <LabelList dataKey="Current" position="top" style={{ fontSize: 11, fill: C.goldDeep, fontFamily: 'JetBrains Mono', fontWeight: 700 }} formatter={(v) => `$${v}K`} />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-x-4 gap-y-2 text-xs">
          {REVENUE_CHART_DATA.map(d => (
            <div key={d.name} className="flex items-baseline gap-2">
              <span style={{ color: C.textSoft, fontWeight: 500 }}>{d.fullName}</span>
              <span style={{ color: C.goldDeep, fontFamily: '"JetBrains Mono", monospace', fontWeight: 600 }}>{d.growth === 'New' ? 'NEW' : `+${d.growth}%`}</span>
            </div>
          ))}
        </div>
      </Card>

      <Card className="mb-6">
        <H2>Portfolio detail</H2>
        <div className="mt-5 -mx-6 sm:-mx-7 px-6 sm:px-7 overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ borderBottom: `1px solid ${C.border}` }}>
                {['Shop', 'Acquired', 'At Buy', 'Now', 'Δ', 'Val.', 'Structure'].map((h, i) => (
                  <th key={h} style={{ fontSize: '10px', fontWeight: 700, color: C.textMuted, letterSpacing: '0.14em', textTransform: 'uppercase', textAlign: i === 0 || i === 1 || i === 6 ? 'left' : 'right', padding: '10px 8px 10px 0' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {STORES.map(s => {
                const growth = s.startMRR ? ((s.currentMRR - s.startMRR) / s.startMRR * 100).toFixed(0) : null;
                return (
                  <tr key={s.id} style={{ borderBottom: `1px solid ${C.borderSoft}` }}>
                    <td className="py-3" style={{ fontSize: '13px', color: C.ink, fontWeight: 600 }}>
                      <div className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full shrink-0" style={{ backgroundColor: s.type === 'passive' ? C.gold : C.textMuted }}></div>
                        {s.name}
                      </div>
                    </td>
                    <td className="py-3 text-right" style={{ fontSize: '12px', color: C.textSoft }}>{s.acquired}</td>
                    <td className="py-3 text-right" style={{ fontSize: '12px', color: C.textSoft, fontFamily: '"JetBrains Mono", monospace' }}>{s.startMRR === null ? '—' : `$${s.startMRR}K`}</td>
                    <td className="py-3 text-right" style={{ fontSize: '13px', color: C.ink, fontWeight: 600, fontFamily: '"JetBrains Mono", monospace' }}>${s.currentMRR}K</td>
                    <td className="py-3 text-right" style={{ fontSize: '12px', color: C.goldDeep, fontWeight: 700, fontFamily: '"JetBrains Mono", monospace' }}>{growth ? `+${growth}%` : (s.startMRR === 0 ? 'NEW' : '—')}</td>
                    <td className="py-3 text-right" style={{ fontSize: '12px', color: C.text, fontFamily: '"JetBrains Mono", monospace' }}>${valOf(s.id)}K</td>
                    <td className="py-3" style={{ fontSize: '11px', color: C.textSoft, fontWeight: 500 }}>
                      {s.type === 'passive' ? `GGP + ${s.lpCount > 0 ? s.lpCount + ' LPs' : 'shared LPs'}` : 'GGP + Founders'}
                    </td>
                  </tr>
                );
              })}
              <tr style={{ borderTop: `2px solid ${C.text}` }}>
                <td className="pt-3" style={{ fontSize: '11px', fontWeight: 700, color: C.ink, letterSpacing: '0.12em', textTransform: 'uppercase' }}>Total</td>
                <td></td>
                <td></td>
                <td className="pt-3 text-right" style={{ fontSize: '13px', fontWeight: 700, color: C.ink, fontFamily: '"JetBrains Mono", monospace' }}>${TOTAL_MRR_NOW}K</td>
                <td></td>
                <td className="pt-3 text-right" style={{ fontSize: '13px', fontWeight: 700, color: C.ink, fontFamily: '"JetBrains Mono", monospace' }}>${totalVal}K</td>
                <td></td>
              </tr>
            </tbody>
          </table>
        </div>
      </Card>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <div className="flex items-center gap-2.5 mb-4 pb-3" style={{ borderBottom: `1px solid ${C.borderSoft}` }}>
            <CheckCircle2 size={18} style={{ color: C.goldDeep }} />
            <H2>What's working</H2>
          </div>
          <ul className="space-y-3" style={{ fontSize: '13px', lineHeight: 1.55, color: C.text }}>
            {[
              ['Operational turnaround playbook is real.', 'Revenue up 50–267% post-acquisition. NRH alone went from $3K to $11K/month.'],
              ['Acquisition velocity.', '7 shops in 8 months puts us in the top decile of small QSR roll-ups operationally.'],
              ['DFW market density.', 'Geographic concentration enables centralized kitchen, shared management, route efficiency.'],
              ['Founder profile.', 'Data scientist + SWE — rare combination in QSR roll-ups.'],
              ['Capital efficiency proven.', '~$380K of LP cash deployed → $1.12M of store-level value created.'],
            ].map(([head, body], i) => (
              <li key={i} className="flex gap-3">
                <span className="shrink-0 mt-1.5 w-1 h-1 rounded-full" style={{ backgroundColor: C.gold }}></span>
                <span><strong style={{ color: C.ink, fontWeight: 600 }}>{head}</strong> {body}</span>
              </li>
            ))}
          </ul>
        </Card>
        <Card>
          <div className="flex items-center gap-2.5 mb-4 pb-3" style={{ borderBottom: `1px solid ${C.borderSoft}` }}>
            <AlertCircle size={18} style={{ color: C.goldDeep }} />
            <H2>Gaps to close</H2>
          </div>
          <ul className="space-y-3" style={{ fontSize: '13px', lineHeight: 1.55, color: C.text }}>
            {[
              ['Cap table fragmentation.', '7 separate LLCs. PE diligence killer. Roll-up is the priority.'],
              ['Brand identity.', 'Regional roll-up with no distinct positioning. Brand work in next 18 months unlocks 1.5–2× exit multiple.'],
              ['Securities compliance.', 'Need accreditation questionnaires on file for all 14 LPs.'],
              ['No written waterfall.', 'GP got 50% with no preferred return for LPs. Capital floor fixes this.'],
              ['Tech stack unbuilt.', 'Golden POS is concept, not product. Has to ship before franchise pitch lands.'],
            ].map(([head, body], i) => (
              <li key={i} className="flex gap-3">
                <span className="shrink-0 mt-1.5 w-1 h-1 rounded-full" style={{ backgroundColor: C.gold }}></span>
                <span><strong style={{ color: C.ink, fontWeight: 600 }}>{head}</strong> {body}</span>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </div>
  );
}

// ============= TAB 4: TEAM =============
function TabTeam() {
  const founders = [
    {
      mono: 'JK',
      name: 'Jack',
      role: 'Founder & CEO',
      currentLabel: 'Previously',
      currentRole: 'VP, Asset & Wealth Management',
      company: 'Goldman Sachs',
      focus: [
        'Capital structure + investor relations',
        'Deal structuring (M&A, SAFE, Series A)',
        'Financial planning + capital strategy',
        'HNW investor and family office relationships',
      ],
    },
    {
      mono: 'YY',
      name: 'Youyou',
      role: 'Co-founder & COO',
      currentLabel: 'Currently',
      currentRole: 'SVP, Data Analytics',
      company: 'Top-tier Management Consulting Firm',
      focus: [
        'Operations across the 7-shop portfolio',
        'M&A pipeline + acquisition playbook',
        'Data + analytics infrastructure',
        'Operational turnaround methodology',
      ],
    },
    {
      mono: 'PY',
      name: 'Peiyun',
      role: 'Co-founder, Engineering',
      currentLabel: 'Currently',
      currentRole: 'Software Engineer',
      company: 'Building Golden POS in parallel',
      focus: [
        'Golden POS — the proprietary tech stack',
        'Customer loyalty + demand forecasting',
        'Data infrastructure across all shops',
        'Engineering hiring as we scale',
      ],
    },
    {
      mono: 'MX',
      name: 'Max',
      role: 'Co-founder · Analysis',
      currentLabel: 'Currently',
      currentRole: 'Business Analyst',
      company: 'Right-hand on the daily decisions',
      focus: [
        'Operational + financial analysis',
        'M&A pipeline + deal evaluation',
        'Scenario modeling + diligence',
        'The "second pair of eyes" on every call',
      ],
    },
  ];

  const activeOperatingPartner = {
    mono: 'MP',
    name: 'Muypin',
    role: 'Active Operating Partner · 6% GGP',
    org: 'Current donut shop owner · Full-time on the ground',
    focus: 'Day-to-day operations leadership across multiple shops. Existing shop owner who chose to join Golden Glaze full-time. The most active non-founder partner — runs operational execution while founders focus on capital, strategy, and tech.',
  };

  const advisors = [
    { mono: 'LK', name: 'Luke',     role: 'Strategy · 3% GGP',          org: 'Manager, Verizon Innovation Lab',    focus: 'Strategic guidance, technical architecture, and ongoing operational support. Large-org operating experience and vendor relationships. Part-time advisor while at Verizon.' },
    { mono: 'CH', name: 'Chanda',   role: 'Master FOH Operator · 2% GGP', org: 'Owns her own shop · Mutual-aid partner', focus: 'Front-of-house operational discipline, customer experience standards, staff training. Industry network and credibility — we help each other across our shops.' },
    { mono: 'JN', name: 'Jonathan', role: 'Operations · 2% GGP',         org: '15+ yrs multi-unit production floor leadership', focus: 'Production floor expertise from a multi-million-dollar operating environment. Currently advisor; converts to full-time MIP hire when SAFE proceeds enable a competitive offer.' },
    { mono: 'LA', name: 'Lam',      role: 'Senior Baker · 1% GGP',       org: '5+ years bakery operations',         focus: 'Production training, recipe execution, and quality consistency across new acquisitions. Part-time on a mutual-help basis.' },
  ];

  const ggpAllocations = [
    { name: 'Youyou',  pct: '35%', role: 'Founder · CEO/COO',               detail: 'Operating leadership across the 7-shop portfolio, M&A pipeline, data infrastructure.', accent: 'gold' },
    { name: 'Jack',    pct: '25%', role: 'Founder & CEO',                   detail: 'Capital structure, investor relations, deal structuring across SAFE and Series A.', accent: 'gold' },
    { name: 'Peiyun',  pct: '15%', role: 'Co-founder · Engineering',        detail: 'Golden POS platform, customer loyalty, data infrastructure across all shops.', accent: 'gold' },
    { name: 'Max',     pct: '5%',  role: 'Co-founder · Analysis',           detail: 'Operational and financial analysis, M&A pipeline evaluation, scenario modeling. Formalized at HoldCo from previous informal arrangement.', accent: 'gold' },
    { name: 'Muypin',  pct: '6%',  role: 'Active Operating Partner',        detail: 'Full-time donut operations across multiple shops. Existing shop owner who joined the team — most active non-founder partner.', accent: 'neutral' },
    { name: 'Luke',    pct: '3%',  role: 'Strategic Advisor · Strategy',    detail: 'Strategic guidance, technical architecture, vendor relationships. Part-time while at Verizon Innovation Lab.', accent: 'soft' },
    { name: 'Chanda',  pct: '2%',  role: 'Strategic Advisor · FOH Ops',     detail: 'Master FOH operator, owns her own shop. Mutual-aid arrangement bringing industry network and operational discipline.', accent: 'soft' },
    { name: 'Jonathan',pct: '2%',  role: 'Strategic Advisor · Operations',  detail: '15+ years multi-unit production floor leadership. Currently advisor; converts to MIP when full-time hire happens (slot reallocates to reserves).', accent: 'soft' },
    { name: 'Lam',     pct: '1%',  role: 'Strategic Advisor · Bakery',      detail: '5+ years bakery operations experience. Part-time advisor on production training and recipe execution.', accent: 'soft' },
    { name: 'Future advisors', pct: '6%', role: 'Reserved · institutional-grade board',  detail: 'Reserved for board-level / institutional advisors recruited as the platform scales — industry veterans, former QSR executives, M&A specialists. Critical for institutional credibility at Series A.', accent: 'reserved' },
  ];

  const incomingHires = [
    {
      mono: 'JN',
      name: 'Jonathan',
      role: 'Incoming Operations Manager · Pending offer',
      exp: '15+ years multi-unit production floor leadership at a multi-million-dollar company',
      focus: 'Joining as Operations Manager once SAFE proceeds enable a competitive offer. Currently contributing as a strategic advisor (2% GGP). When hired full-time, his slot moves to MIP and the advisor slot reallocates to future advisor recruitment. This is the kind of resume that becomes the credible answer at PE diligence to "who runs operations as you scale to 30+ shops?" — exactly the institutional-grade ops hire most early QSR roll-ups can\'t attract.',
      mip: 'Advisor pool 2% today · MIP allocation 1.5% on full-time hire',
    },
  ];

  const mipAllocations = [
    { name: 'Pheak',          pct: '2%',   role: 'Master Baker · Full-time',          detail: 'Recipe development, baker training, quality standards across all shops. 10+ years experience anchoring Arlington baking. The only currently full-time non-partner employee at the master-craft level.', alloc: 'Allocated' },
    { name: 'Future hires',   pct: '8%',   role: 'CFO · COO · CMO · GMs',             detail: 'Reserved for the institutional-grade executive operators we will need to recruit between now and Series A. May also absorb Jonathan when he transitions from advisor to full-time hire (~1.5%).', alloc: 'Reserved' },
  ];

  const shopTeams = [
    { shop: 'Arlington',          team: [{name:'Pheak', baker:true},{name:'Salana'},{name:'Rahual'},{name:'Jem'}] },
    { shop: 'NRH (Rufe Snow)',    team: [{name:'Tech'},{name:'Lama'}] },
    { shop: 'Fort Worth',         team: [{name:'Dina', baker:true},{name:'Ruth'},{name:'Sayu'}] },
    { shop: 'Grapevine',          team: [{name:'Kanha'},{name:'James', baker:true}] },
    { shop: 'Carrollton',         team: [{name:'Dipika'},{name:'Sarina'},{name:'Yangzhou', floating:true}] },
    { shop: 'Bluemound',          team: [{name:'Shital'},{name:'Ipsa'}] },
    { shop: 'Dallas (Frankford)', team: [{name:'Aasiya'},{name:'Lilly'},{name:'Yangzhou', floating:true}] },
  ];

  return (
    <div>
      <SectionTitle
        eyebrow="04 — The Team"
        title="The operators behind the playbook."
        lede="A rare combination: institutional pedigree, real engineering and data capability, and donut industry expertise — including master bakers and existing shop owners on the team. Most QSR roll-ups have one of these. We have all three."
      />

      {/* Hero stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-10">
        <Stat label="Total Team" value="28+" sub="founders to floor" tone="accent" />
        <Stat label="Founders" value="4" sub="80% of GGP combined" />
        <Stat label="Strategic Advisors" value="4 + reserve" sub="14% of GGP · 6% reserved" />
        <Stat label="Shop-Level Team" value="18+" sub="across 7 stores" />
      </div>

      {/* Founders */}
      <div className="mb-12">
        <H2>Founders</H2>
        <p className="mt-1 mb-6" style={{ fontSize: '13px', color: C.textSoft }}>Four co-founders setting strategy, running operations, building technology, and grinding the daily decisions. Combined 80% of GGP.</p>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {founders.map(f => (
            <Card key={f.name}>
              <div className="flex items-start gap-3 mb-4">
                <div className="w-12 h-12 rounded-2xl grid place-items-center shrink-0" style={{ backgroundColor: C.gold, color: C.ink }}>
                  <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '15px', fontWeight: 700, letterSpacing: '-0.02em' }}>{f.mono}</span>
                </div>
                <div className="min-w-0 flex-1">
                  <div style={{ fontSize: '17px', fontWeight: 700, color: C.ink, lineHeight: 1.1, letterSpacing: '-0.01em' }}>{f.name}</div>
                  <div style={{ fontSize: '10.5px', fontWeight: 700, color: C.goldDeep, letterSpacing: '0.1em', textTransform: 'uppercase', marginTop: '5px' }}>{f.role}</div>
                </div>
              </div>
              <div className="mb-4 pb-4" style={{ borderBottom: `1px solid ${C.borderSoft}` }}>
                <div style={{ fontSize: '9.5px', fontWeight: 700, color: C.textMuted, letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: '6px' }}>{f.currentLabel}</div>
                <div style={{ fontSize: '13.5px', fontWeight: 700, color: C.ink, lineHeight: 1.25 }}>{f.currentRole}</div>
                <div style={{ fontSize: '12px', color: C.text, marginTop: '2px', fontWeight: 500 }}>{f.company}</div>
              </div>
              <div>
                <div style={{ fontSize: '9.5px', fontWeight: 700, color: C.textMuted, letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: '8px' }}>What they own at Golden Glaze</div>
                <ul className="space-y-1.5">
                  {f.focus.map(item => (
                    <li key={item} className="flex gap-2.5" style={{ fontSize: '11.5px', color: C.text, lineHeight: 1.45 }}>
                      <span className="mt-1.5 shrink-0 w-1 h-1 rounded-full" style={{ backgroundColor: C.gold }}></span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Active Operating Partner */}
      <div className="mb-12">
        <H2>Active operating partner</H2>
        <p className="mt-1 mb-6" style={{ fontSize: '13px', color: C.textSoft }}>The only non-founder working full-time at owner-commitment level. Permanent equity in GGP at 6%.</p>
        <Card>
          <div className="flex items-start gap-5 flex-wrap">
            <div className="w-14 h-14 rounded-2xl grid place-items-center shrink-0" style={{ backgroundColor: C.gold, color: C.ink }}>
              <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '18px', fontWeight: 700, letterSpacing: '-0.02em' }}>{activeOperatingPartner.mono}</span>
            </div>
            <div className="flex-1 min-w-0" style={{ minWidth: '280px' }}>
              <div className="flex items-baseline justify-between gap-3 flex-wrap mb-2">
                <div>
                  <div style={{ fontSize: '20px', fontWeight: 700, color: C.ink, lineHeight: 1.1, letterSpacing: '-0.01em' }}>{activeOperatingPartner.name}</div>
                  <div style={{ fontSize: '11px', fontWeight: 700, color: C.goldDeep, letterSpacing: '0.12em', textTransform: 'uppercase', marginTop: '6px' }}>{activeOperatingPartner.role}</div>
                </div>
                <Pill tone="gold">GGP partner · non-vesting</Pill>
              </div>
              <div style={{ fontSize: '11px', color: C.textMuted, letterSpacing: '0.14em', textTransform: 'uppercase', fontWeight: 600, marginTop: '10px', marginBottom: '10px' }}>{activeOperatingPartner.org}</div>
              <p style={{ fontSize: '13px', color: C.text, lineHeight: 1.55 }}>{activeOperatingPartner.focus}</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Strategic Advisors */}
      <div className="mb-12">
        <H2>Strategic advisors</H2>
        <p className="mt-1 mb-6" style={{ fontSize: '13px', color: C.textSoft }}>Part-time contributors with industry expertise, network access, or strategic value — currently 8% of GGP allocated, 6% reserved for institutional-grade board advisors recruited before Series A.</p>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {advisors.map(p => (
            <div key={p.name} className="rounded-xl p-5" style={{ backgroundColor: C.cardWarm, border: `1px solid ${C.border}` }}>
              <div className="flex items-center gap-3 mb-3.5">
                <div className="w-10 h-10 rounded-lg grid place-items-center shrink-0" style={{ backgroundColor: C.cream, color: C.text }}>
                  <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '12.5px', fontWeight: 700, letterSpacing: '-0.02em' }}>{p.mono}</span>
                </div>
                <div className="min-w-0 flex-1">
                  <div style={{ fontSize: '14px', fontWeight: 700, color: C.ink, lineHeight: 1.2 }}>{p.name}</div>
                  <div style={{ fontSize: '10.5px', color: C.goldDeep, fontWeight: 600, marginTop: '2px' }}>{p.role}</div>
                </div>
              </div>
              <div style={{ fontSize: '9.5px', color: C.textMuted, letterSpacing: '0.12em', textTransform: 'uppercase', fontWeight: 600, marginBottom: '8px' }}>{p.org}</div>
              <p style={{ fontSize: '12px', color: C.text, lineHeight: 1.5 }}>{p.focus}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Incoming Hires — Jonathan callout */}
      <Card className="mb-12" tone="dark">
        <div className="flex items-center gap-2 mb-3">
          <UserCircle2 size={16} style={{ color: C.goldSoft }} />
          <span style={{ fontSize: '11px', fontWeight: 700, color: C.goldSoft, letterSpacing: '0.18em', textTransform: 'uppercase' }}>Incoming hire · Operations</span>
        </div>
        <h2 style={{ fontSize: '1.5rem', fontWeight: 700, color: C.bg, letterSpacing: '-0.01em', marginTop: '4px' }}>The institutional-grade ops hire most early roll-ups can't attract.</h2>
        <div className="mt-6 grid lg:grid-cols-[auto_1fr] gap-5 items-start">
          <div className="w-14 h-14 rounded-2xl grid place-items-center shrink-0" style={{ backgroundColor: C.gold, color: C.ink }}>
            <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '18px', fontWeight: 700, letterSpacing: '-0.02em' }}>{incomingHires[0].mono}</span>
          </div>
          <div>
            <div style={{ fontSize: '20px', fontWeight: 700, color: C.bg, lineHeight: 1.1, letterSpacing: '-0.01em' }}>{incomingHires[0].name}</div>
            <div style={{ fontSize: '11px', fontWeight: 700, color: C.goldSoft, letterSpacing: '0.12em', textTransform: 'uppercase', marginTop: '6px' }}>{incomingHires[0].role}</div>
            <div style={{ fontSize: '11px', color: 'rgba(245,226,184,0.6)', letterSpacing: '0.14em', textTransform: 'uppercase', fontWeight: 600, marginTop: '14px', marginBottom: '10px' }}>{incomingHires[0].exp}</div>
            <p style={{ fontSize: '13.5px', color: 'rgba(250,246,234,0.85)', lineHeight: 1.6, marginBottom: '14px' }}>{incomingHires[0].focus}</p>
            <Pill tone="gold">{incomingHires[0].mip}</Pill>
          </div>
        </div>
      </Card>

      {/* GGP Equity Allocations */}
      <Card className="mb-6">
        <div className="flex items-center gap-2 mb-3">
          <UserCircle2 size={16} style={{ color: C.goldDeep }} />
          <Eyebrow>GGP equity · 100% of operator entity</Eyebrow>
        </div>
        <h2 style={{ fontSize: '1.5rem', fontWeight: 700, color: C.ink, letterSpacing: '-0.01em', marginTop: '4px' }}>Who owns the operator entity, and at what percentage.</h2>
        <p className="mt-3 mb-6" style={{ fontSize: '13.5px', color: C.text, lineHeight: 1.55, maxWidth: '46rem' }}>
          GGP (Golden Glaze Operators LLC) holds the 50% operator slot in every shop. Inside GGP, equity is permanent and non-vesting — distributed across four tiers: <strong style={{ color: C.goldDeep }}>founders</strong> (the core builders), <strong style={{ color: C.text }}>active operating partners</strong> (full-time daily commitment), <strong style={{ color: C.textSoft }}>strategic advisors</strong> (part-time guidance + industry network), and <strong style={{ color: C.textMuted }}>reserved capacity</strong> for institutional advisors recruited before Series A.
        </p>
        <div className="space-y-2">
          {ggpAllocations.map(g => {
            const bg = g.accent === 'gold' ? 'rgba(217,156,43,0.08)'
                     : g.accent === 'neutral' ? C.cardWarm
                     : g.accent === 'soft' ? C.cream
                     : 'rgba(139,110,61,0.06)';
            const border = g.accent === 'gold' ? 'rgba(217,156,43,0.25)'
                         : g.accent === 'reserved' ? `1px dashed ${C.border}`
                         : C.border;
            const pctColor = g.accent === 'gold' ? C.goldDeep
                           : g.accent === 'reserved' ? C.textMuted
                           : C.ink;
            return (
              <div key={g.name} className="grid grid-cols-[auto_1fr] gap-4 items-center p-3.5 rounded-lg" style={{ backgroundColor: bg, border: g.accent === 'reserved' ? border : `1px solid ${border}` }}>
                <div className="min-w-[64px]">
                  <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '22px', fontWeight: 700, color: pctColor, lineHeight: 1, letterSpacing: '-0.02em' }}>{g.pct}</div>
                </div>
                <div className="min-w-0">
                  <div className="flex items-baseline gap-2 flex-wrap">
                    <span style={{ fontSize: '14px', fontWeight: 700, color: C.ink }}>{g.name}</span>
                    <span style={{ fontSize: '10.5px', fontWeight: 600, color: pctColor, letterSpacing: '0.08em', textTransform: 'uppercase' }}>{g.role}</span>
                  </div>
                  <p style={{ fontSize: '12px', color: C.textSoft, lineHeight: 1.5, marginTop: '4px' }}>{g.detail}</p>
                </div>
              </div>
            );
          })}
        </div>
        <div className="mt-5 pt-4 grid grid-cols-4 gap-3" style={{ borderTop: `1px solid ${C.borderSoft}` }}>
          <div>
            <div style={{ fontSize: '9.5px', fontWeight: 700, color: C.textMuted, letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: '4px' }}>Founders</div>
            <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '17px', fontWeight: 700, color: C.goldDeep }}>80%</div>
          </div>
          <div>
            <div style={{ fontSize: '9.5px', fontWeight: 700, color: C.textMuted, letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: '4px' }}>Active partner</div>
            <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '17px', fontWeight: 700, color: C.ink }}>6%</div>
          </div>
          <div>
            <div style={{ fontSize: '9.5px', fontWeight: 700, color: C.textMuted, letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: '4px' }}>Advisors</div>
            <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '17px', fontWeight: 700, color: C.textSoft }}>14%</div>
          </div>
          <div>
            <div style={{ fontSize: '9.5px', fontWeight: 700, color: C.textMuted, letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: '4px' }}>Total GGP</div>
            <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '17px', fontWeight: 700, color: C.text }}>100%</div>
          </div>
        </div>
      </Card>

      {/* MIP Pool details */}
      <Card className="mb-12">
        <div className="flex items-center gap-2 mb-3">
          <Award size={16} style={{ color: C.goldDeep }} />
          <Eyebrow>MIP Pool · 10% reserved at HoldCo</Eyebrow>
        </div>
        <h2 style={{ fontSize: '1.5rem', fontWeight: 700, color: C.ink, letterSpacing: '-0.01em', marginTop: '4px' }}>Vesting equity for full-time employees.</h2>
        <p className="mt-3 mb-6" style={{ fontSize: '13.5px', color: C.text, lineHeight: 1.55, maxWidth: '46rem' }}>
          The Management Incentive Plan reserves 10% of HoldCo for non-partner employees with significant roles. Profits interests vest over 4 years with a 1-year cliff. Currently only one allocation made (Pheak, full-time master baker). Eight percent is reserved for the institutional-grade executive operators we will need to recruit between now and Series A — CFO, COO, CMO, GMs.
        </p>
        <div className="space-y-2">
          {mipAllocations.map(a => (
            <div key={a.name} className="grid grid-cols-[auto_1fr_auto] gap-4 items-center p-3.5 rounded-lg" style={{ backgroundColor: C.cardWarm, border: `1px solid ${C.border}` }}>
              <div className="min-w-[64px]">
                <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '22px', fontWeight: 700, color: C.goldDeep, lineHeight: 1, letterSpacing: '-0.02em' }}>{a.pct}</div>
              </div>
              <div className="min-w-0">
                <div className="flex items-baseline gap-2 flex-wrap">
                  <span style={{ fontSize: '14px', fontWeight: 700, color: C.ink }}>{a.name}</span>
                  <span style={{ fontSize: '10.5px', fontWeight: 600, color: C.goldDeep, letterSpacing: '0.08em', textTransform: 'uppercase' }}>{a.role}</span>
                </div>
                <p style={{ fontSize: '12px', color: C.textSoft, lineHeight: 1.5, marginTop: '4px' }}>{a.detail}</p>
              </div>
              <Pill tone="gold">{a.alloc}</Pill>
            </div>
          ))}
        </div>
      </Card>

      {/* Shop Teams */}
      <Card className="mb-10">
        <H2>Shop teams</H2>
        <p className="mt-1 mb-6" style={{ fontSize: '13px', color: C.textSoft }}>The people running our seven locations day to day. <span style={{ color: C.goldDeep, fontWeight: 700 }}>▸</span> indicates baker.</p>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {shopTeams.map(s => (
            <div key={s.shop} className="rounded-xl p-4" style={{ backgroundColor: C.cardWarm, border: `1px solid ${C.border}` }}>
              <div className="flex items-baseline justify-between mb-3 pb-2.5 gap-2" style={{ borderBottom: `1px solid ${C.borderSoft}` }}>
                <span style={{ fontSize: '13.5px', fontWeight: 700, color: C.ink }}>{s.shop}</span>
                <span style={{ fontSize: '10px', fontWeight: 700, color: C.textMuted, letterSpacing: '0.12em', textTransform: 'uppercase' }}>{s.team.length} on team</span>
              </div>
              <ul className="space-y-1.5">
                {s.team.map((t, i) => (
                  <li key={i} className="flex items-center gap-2 flex-wrap" style={{ fontSize: '12.5px', color: C.text }}>
                    <span style={{ width: '10px', display: 'inline-block', textAlign: 'center', color: C.goldDeep, fontWeight: 700 }}>{t.baker ? '▸' : ''}</span>
                    <span style={{ fontWeight: t.baker ? 700 : 500 }}>{t.name}</span>
                    {t.floating && <Pill>floating</Pill>}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </Card>

      {/* Closing thesis */}
      <Card tone="dark">
        <div className="flex items-center gap-2 mb-3">
          <UserCircle2 size={16} style={{ color: C.goldSoft }} />
          <span style={{ fontSize: '11px', fontWeight: 700, color: C.goldSoft, letterSpacing: '0.18em', textTransform: 'uppercase' }}>Why this team</span>
        </div>
        <p style={{ fontSize: '15.5px', lineHeight: 1.65, color: C.bg, fontWeight: 400, marginTop: '14px' }}>
          Most QSR roll-ups are MBAs trying to operate businesses they do not fundamentally understand. We are different in three specific ways: <strong style={{ color: C.goldSoft, fontWeight: 700 }}>institutional capital pedigree</strong> (Goldman Sachs Asset & Wealth Management — Jack literally spoke to HNW investors and family offices for a living), <strong style={{ color: C.goldSoft, fontWeight: 700 }}>real engineering and data capability</strong> (a working software engineer building Golden POS, plus an SVP-level data analytics co-founder), and <strong style={{ color: C.goldSoft, fontWeight: 700 }}>actual donut industry expertise</strong> (master bakers and shop owners on the team, not just consultants of). The combination is what makes our turnaround playbook repeatable — and what positions us to scale into franchise + supply + tech without the operational blowups that kill most roll-ups.
        </p>
      </Card>
    </div>
  );
}

// ============= TAB 5: VISION =============
function TabVision({ scenario }) {
  return (
    <div>
      <SectionTitle
        eyebrow="05 — Vision & Target Exit"
        title={`A ${fmt$(scenario.exitValuation)} exit in 3–4 years. Shipley scale in 7.`}
        lede="The thesis: a vertically integrated specialty bakery platform — owned stores, franchise system, centralized kitchen, supply IP, and a real tech wedge. Same operational footprint, dramatically better exit math when the pieces stack."
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-8">
        <Stat label="Year 4 Target" value={fmt$(scenario.exitValuation)} sub="exit valuation" tone="accent" />
        <Stat label="Year 7 Target" value="$200–400M" sub="Shipley scale" />
        <Stat label="EBITDA Required" value="$7–10M" sub="at 10–12× multiple" />
        <Stat label="Total Units (Y4)" value="50–65" sub="owned + franchised" />
      </div>

      <Card className="mb-6">
        <H2>The four-pillar platform</H2>
        <p className="mt-1 mb-6" style={{ fontSize: '13px', color: C.textSoft }}>Each pillar adds revenue at a different multiple. Stacked, they unlock the multi-hundred-million exit.</p>
        <div className="grid sm:grid-cols-2 gap-3">
          {[
            { num: '01', title: 'Owned + Franchised Stores',  mult: '6–10× EBITDA', detail: '15–20 owned flagships + 30–50 franchisees by Y4. Royalty income at 80%+ margin. Franchisee capital funds growth.' },
            { num: '02', title: 'Centralized Kitchen + B2B',   mult: '6–8× EBITDA',  detail: 'Mandatory supply for all stores + wholesale to local independent coffee shops, hotels, schools, corporate accounts.' },
            { num: '03', title: 'Specialty Supply / Mix IP',    mult: '8–12× EBITDA', detail: 'Year 5+ business. Proprietary mixes licensed to other bakeries. Adjacent to Dawn — not competing.' },
            { num: '04', title: 'Tech Platform · Golden POS',   mult: '5–8× ARR',     detail: 'Internal POS + demand forecasting + customer data. Eventually licensed externally.' },
          ].map(p => (
            <div key={p.num} className="rounded-xl p-5" style={{ backgroundColor: C.cardWarm, border: `1px solid ${C.border}` }}>
              <div className="flex items-baseline justify-between mb-2.5">
                <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '11px', fontWeight: 700, color: C.goldDeep, letterSpacing: '0.08em' }}>{p.num}</span>
                <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '11px', fontWeight: 600, color: C.goldDeep }}>{p.mult}</span>
              </div>
              <h4 style={{ fontSize: '15px', fontWeight: 700, color: C.ink, marginBottom: '8px' }}>{p.title}</h4>
              <p style={{ fontSize: '12.5px', lineHeight: 1.55, color: C.textSoft }}>{p.detail}</p>
            </div>
          ))}
        </div>
      </Card>

      <Card className="mb-6">
        <H2>The roadmap</H2>
        <p className="mt-1 mb-6" style={{ fontSize: '13px', color: C.textSoft }}>Each phase is its own fundable narrative. Each phase adds margin layers on existing infrastructure.</p>
        <div className="space-y-4">
          {[
            { period: 'Now → Mo 12',   label: 'Foundation',         dot: C.text,     items: ['Roll-up complete', `${fmt$(scenario.safeAmount)} SAFE closed`, 'Brand investment', 'FDD work begun', 'Kitchen build started', '12–14 more shops'] },
            { period: 'Mo 12 → 24',     label: 'Franchise Launch',   dot: C.gold,     items: ['First 5–10 franchisees', 'Kitchen at scale', 'Series A closed', 'Brand system rolled', '20–25 owned'] },
            { period: 'Mo 24 → 36',     label: 'Acceleration',       dot: C.goldSoft, items: ['30–40 franchisees', 'B2B wholesale', 'Tech platform launched', 'First strategic talks'] },
            { period: 'Mo 36 → 48',     label: 'Exit Window Opens',  dot: C.goldDeep, items: ['50+ total units', '$7–10M EBITDA', 'Banker process', 'Multi-bidder situation', '$80–120M exit'] },
            { period: 'Year 5–7',       label: 'Shipley scale',      dot: C.textSoft, items: ['100+ units', 'Supply business operational', 'CPG / retail', '$200–400M exit'] },
          ].map((phase, i) => (
            <div key={i} className="flex gap-5">
              <div className="flex flex-col items-center pt-1.5">
                <div className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: phase.dot, boxShadow: `0 0 0 4px ${C.bg}` }}></div>
                {i < 4 && <div className="w-px flex-1 mt-1" style={{ backgroundColor: C.border }}></div>}
              </div>
              <div className="flex-1 pb-5">
                <div className="flex items-baseline gap-3 mb-2 flex-wrap">
                  <span style={{ fontSize: '10px', fontWeight: 700, color: C.goldDeep, letterSpacing: '0.14em', textTransform: 'uppercase', fontFamily: '"JetBrains Mono", monospace' }}>{phase.period}</span>
                  <span style={{ fontSize: '15px', fontWeight: 700, color: C.ink }}>{phase.label}</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {phase.items.map(item => <Pill key={item}>{item}</Pill>)}
                </div>
              </div>
            </div>
          ))}
        </div>
      </Card>

      <Card className="mb-6">
        <H2>The comps we're building toward</H2>
        <p className="mt-1 mb-6" style={{ fontSize: '13px', color: C.textSoft }}>Real QSR / specialty bakery exits and IPOs over the last 4 years that map directly to our model. Six comps, each illustrating a different piece of the trajectory.</p>

        {/* Direct model match */}
        <div className="mb-6">
          <Eyebrow>Direct model match</Eyebrow>
          <div className="mt-3 grid sm:grid-cols-2 gap-4">
            {[
              {
                name: 'Shipley Do-Nuts',
                subtitle: 'Donut franchise + Flour & Supply · Houston',
                body: 'Sold by family to Peak Rock Capital Jan 2021. Sold by Peak Rock to Levine Leichtman July 2025 after 4-year hold. Revenue more than doubled under PE ownership. ~380 stores across 14 states at second sale. Franchise + Flour & Supply Co. sold together — same vertical-integration thesis we are building.',
                stats: [['Hold', '4 yrs'], ['Sale 1 → Sale 2', '~2× value'], ['Stores at exit', '~380']],
                accent: C.gold,
              },
              {
                name: 'Mochinut',
                subtitle: 'Asian-American specialty bakery · Los Angeles',
                body: 'Founded 2017-2020 in LA / South Korea. Mochi donuts + Korean rice-flour hot dogs + bubble tea. 148+ units globally by 2023. $400K-$1M AUV per store. $189-336K initial franchise investment. Closest cultural / category comp to our identity-aligned positioning — proving the Asian-American specialty bakery thesis works at scale.',
                stats: [['Founded', '2017–20'], ['Units (2023)', '148+'], ['AUV', '$400K–$1M']],
                accent: C.gold,
              },
            ].map(c => (
              <div key={c.name} className="rounded-xl p-5" style={{ backgroundColor: 'rgba(217,156,43,0.06)', border: `1px solid rgba(217,156,43,0.25)` }}>
                <h4 style={{ fontSize: '15px', fontWeight: 700, color: C.ink, marginBottom: '4px' }}>{c.name}</h4>
                <p style={{ fontSize: '10.5px', fontWeight: 600, color: C.textMuted, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: '12px' }}>{c.subtitle}</p>
                <p style={{ fontSize: '12.5px', lineHeight: 1.55, color: C.text, marginBottom: '14px' }}>{c.body}</p>
                <div className="grid grid-cols-3 gap-2 pt-3" style={{ borderTop: `1px solid ${C.borderSoft}` }}>
                  {c.stats.map(([k, v], i) => (
                    <div key={i}>
                      <div style={{ fontSize: '9.5px', fontWeight: 700, color: C.textMuted, letterSpacing: '0.1em', textTransform: 'uppercase' }}>{k}</div>
                      <div style={{ fontSize: '13px', fontWeight: 700, color: C.goldDeep, fontFamily: '"JetBrains Mono", monospace', marginTop: '2px' }}>{v}</div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Pace + scale benchmarks */}
        <div className="mb-6">
          <Eyebrow>Pace + scale benchmarks</Eyebrow>
          <div className="mt-3 grid sm:grid-cols-2 gap-4">
            {[
              {
                name: "Dave's Hot Chicken",
                subtitle: 'QSR franchise roll-up · 2017 LA parking lot',
                body: 'Started 2017 with $900. 7 stores by 2020 doing $22M total systemwide sales. 315 units by 2025 doing $617M (+156% YoY at peak). Roark Capital acquired June 2025 at ~$1B (8× revenue multiple). Franchisee economics: $3M AUV, 18–20% EBITDA margins, <2-yr payback. The fastest QSR roll-up to billion-dollar exit in recent memory.',
                stats: [['2020 sales', '$22M'], ['2024 sales', '$617M'], ['Exit (2025)', '$1B']],
              },
              {
                name: 'Krispy Kreme',
                subtitle: 'Direct category · PE → public trajectory',
                body: 'JAB Holdings took private Aug 2016 for $1.35B. Focused on Delivered Fresh Daily (DFD) hub-and-spoke model — exactly the centralized-kitchen-plus-distributed-retail thesis we are building. Returned public June 2021 at ~$3.6-4B. PE roughly tripled the value in 5 years on a clean strategy of supply + retail. Annual revenue at IPO: $1.12B.',
                stats: [['PE acquired', '$1.35B'], ['IPO 2021', '~$3.8B'], ['Hold', '5 yrs · 2.8×']],
              },
            ].map(c => (
              <div key={c.name} className="rounded-xl p-5" style={{ backgroundColor: C.cardWarm, border: `1px solid ${C.border}` }}>
                <h4 style={{ fontSize: '15px', fontWeight: 700, color: C.ink, marginBottom: '4px' }}>{c.name}</h4>
                <p style={{ fontSize: '10.5px', fontWeight: 600, color: C.textMuted, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: '12px' }}>{c.subtitle}</p>
                <p style={{ fontSize: '12.5px', lineHeight: 1.55, color: C.text, marginBottom: '14px' }}>{c.body}</p>
                <div className="grid grid-cols-3 gap-2 pt-3" style={{ borderTop: `1px solid ${C.borderSoft}` }}>
                  {c.stats.map(([k, v], i) => (
                    <div key={i}>
                      <div style={{ fontSize: '9.5px', fontWeight: 700, color: C.textMuted, letterSpacing: '0.1em', textTransform: 'uppercase' }}>{k}</div>
                      <div style={{ fontSize: '13px', fontWeight: 700, color: C.text, fontFamily: '"JetBrains Mono", monospace', marginTop: '2px' }}>{v}</div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Public market reality check */}
        <div className="mb-2">
          <Eyebrow>Public market reality · what multiples actually settle at</Eyebrow>
          <div className="mt-3 grid sm:grid-cols-2 gap-4">
            {[
              {
                name: 'Cava',
                subtitle: 'Mediterranean fast-casual · IPO 2023',
                body: 'Founded 2011 as Greek build-your-own bowls. IPO June 2023 at $28/share, $2.4B valuation on $700M revenue → ~3.5× revenue multiple. Reasonable, sustainable multiple for a fast-casual brand with proven unit economics (24.8% restaurant-level margins, 18% same-store sales growth). The sane public-market comp.',
                stats: [['IPO', '$2.4B'], ['Revenue', '$700M'], ['Multiple', '3.5×']],
                tone: 'neutral',
              },
              {
                name: 'Sweetgreen',
                subtitle: 'Cautionary tale · 2021 bubble multiple compression',
                body: 'IPO\'d Nov 2021 at $3B valuation on ~$200M revenue → 15× revenue multiple at the peak of the venture bubble. Same company today trades at ~$1.08B — a 2.4× revenue multiple. Lost 66% of value when investors sobered up. We model exit on sane multiples, not bubble peaks.',
                stats: [['IPO 2021', '$3B'], ['Today', '$1.08B'], ['Lost', '–66%']],
                tone: 'caution',
              },
            ].map(c => (
              <div key={c.name} className="rounded-xl p-5" style={{ backgroundColor: C.cardWarm, border: `1px solid ${C.border}` }}>
                <h4 style={{ fontSize: '15px', fontWeight: 700, color: C.ink, marginBottom: '4px' }}>{c.name}</h4>
                <p style={{ fontSize: '10.5px', fontWeight: 600, color: C.textMuted, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: '12px' }}>{c.subtitle}</p>
                <p style={{ fontSize: '12.5px', lineHeight: 1.55, color: C.text, marginBottom: '14px' }}>{c.body}</p>
                <div className="grid grid-cols-3 gap-2 pt-3" style={{ borderTop: `1px solid ${C.borderSoft}` }}>
                  {c.stats.map(([k, v], i) => (
                    <div key={i}>
                      <div style={{ fontSize: '9.5px', fontWeight: 700, color: C.textMuted, letterSpacing: '0.1em', textTransform: 'uppercase' }}>{k}</div>
                      <div style={{ fontSize: '13px', fontWeight: 700, color: c.tone === 'caution' ? C.textMuted : C.text, fontFamily: '"JetBrains Mono", monospace', marginTop: '2px' }}>{v}</div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Where Golden Glaze fits */}
        <div className="mt-7 rounded-2xl p-5" style={{ backgroundColor: C.ink, color: C.bg }}>
          <div style={{ fontSize: '11px', fontWeight: 700, color: C.goldSoft, letterSpacing: '0.18em', textTransform: 'uppercase', marginBottom: '12px' }}>Where Golden Glaze fits today</div>
          <p style={{ fontSize: '14px', lineHeight: 1.65, color: 'rgba(250,246,234,0.92)', marginBottom: '16px' }}>
            We are at ~$1.3M net ARR ($1.5M gross estimated) and 7 shops. Conservative aggregate valuation: $1.20M (0.83-0.92× annual revenue). That is the <strong style={{ color: C.goldSoft }}>"distressed acquisition cohort"</strong> on the BizBuySell donut shop median (0.5× revenue) — slightly above, because we have proven turnaround.
          </p>
          <p style={{ fontSize: '14px', lineHeight: 1.65, color: 'rgba(250,246,234,0.92)', marginBottom: '16px' }}>
            <strong style={{ color: C.goldSoft }}>The forward path:</strong> Mochinut hit 148+ units in ~3 years. Dave's Hot Chicken went from $22M (2020) to $617M (2024). Krispy Kreme tripled valuation under PE in 5 years on a hub-and-spoke supply model. None of these were pre-revenue unicorns — they built revenue first, then multiples followed.
          </p>
          <p style={{ fontSize: '14px', lineHeight: 1.65, color: 'rgba(250,246,234,0.92)' }}>
            <strong style={{ color: C.goldSoft }}>Our trajectory:</strong> 25–35 shops at $400-500K AUV by Year 4 → ~$10-15M ARR → 6-10× multiple at exit = <strong style={{ color: C.goldSoft }}>{fmt$(scenario.exitValuation)}</strong> exit. Year 7 Shipley scale (100+ units) targets $200-400M. These are not unicorn dreams — they are realistic comps applied to our model.
          </p>
        </div>
      </Card>

      <Card>
        <H2>Untapped levers</H2>
        <p className="mt-1 mb-6" style={{ fontSize: '13px', color: C.textSoft }}>Multiple expanders, not extra businesses.</p>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {[
            ['Glaze Pass membership',   '$20–30/mo recurring. Customer LTV + lock-in. PE pays 12–18× for recurring vs 6–8× transactional.'],
            ['Asian-American identity', 'Mochi donuts, boba, fusion kolaches. Free differentiation aligned with founder story.'],
            ['Real estate hold-co',     'Buy buildings on new acquisitions. Splits exit into operating co + RE assets.'],
            ['Equipment leasing',       'Lease to franchisees. Recurring monthly revenue. Industry-standard.'],
            ['GPO rebates',             'Be the buying group for franchisees. Suppliers pay 1–5% rebates.'],
            ['Catering / events',       'Donut walls at weddings, corporate breakfasts. Texas market loves this.'],
            ['Founder PR',              'Free brand equity. Two Asian-American operators in tired category.'],
            ['Drive-thru express',      'Smaller footprint, lower capex, faster expansion.'],
            ['B2B wholesale donuts',    'Sell finished product to coffee shops, hotels, schools. 30–40% margins.'],
          ].map(([name, detail]) => (
            <div key={name} className="rounded-xl p-4" style={{ backgroundColor: C.cardWarm, border: `1px solid ${C.border}` }}>
              <h5 style={{ fontSize: '13.5px', fontWeight: 700, color: C.ink, marginBottom: '6px' }}>{name}</h5>
              <p style={{ fontSize: '12px', lineHeight: 1.55, color: C.textSoft }}>{detail}</p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

// ============= TAB 6: ROLL-UP =============
function TabRollup({ scenario }) {
  return (
    <div>
      <SectionTitle
        eyebrow="06 — The Roll-Up"
        title="One HoldCo. Three cap-table lines. Tax-free contributions."
        lede="Why we have to do this before institutional capital, what the structure looks like, and how to walk through it without legal jargon getting in the way."
      />

      <Card className="mb-6">
        <H2>Why roll up now</H2>
        <div className="space-y-3 mt-5" style={{ fontSize: '13.5px', lineHeight: 1.6, color: C.text }}>
          {[
            ['Institutional capital won\'t touch a 7-LLC mess.', 'The SAFE investor is fine with the current structure; the Series A investor next year will not be.'],
            ['Clean exits require single-entity sales.', 'A buyer pays one wire to one entity. Buyers discount fragmented structures by 20–30%.'],
            ['Shared services need a parent.', 'Centralized kitchen, brand, tech platform — all of these serve every shop.'],
            ['§721 makes it tax-free.', 'Done correctly, the roll-up itself triggers no tax for any LP.'],
          ].map(([head, body], i) => (
            <p key={i}><strong style={{ color: C.ink, fontWeight: 600 }}>{head}</strong> {body}</p>
          ))}
        </div>
      </Card>

      <Card className="mb-6">
        <H2>Target structure</H2>
        <p className="mt-1 mb-6" style={{ fontSize: '13px', color: C.textSoft }}>Three-line cap table on day one. Everything else is wholly-owned subsidiaries.</p>

        <div className="rounded-2xl p-5 mb-4" style={{ backgroundColor: C.cardWarm, border: `1px solid ${C.border}` }}>
          <div className="rounded-xl p-5 mb-4" style={{ backgroundColor: C.ink, color: C.bg }}>
            <div className="flex items-center justify-between mb-1.5">
              <span style={{ fontSize: '10px', fontWeight: 600, color: C.goldSoft, letterSpacing: '0.18em', textTransform: 'uppercase' }}>Top-level</span>
              <span style={{ fontSize: '10px', fontWeight: 600, color: 'rgba(245,226,184,0.5)', letterSpacing: '0.16em', textTransform: 'uppercase' }}>Delaware LLC</span>
            </div>
            <div style={{ fontSize: '20px', fontWeight: 700, letterSpacing: '-0.01em' }}>Golden Glaze Holdings LLC</div>
          </div>

          <div className="grid sm:grid-cols-3 gap-3 mb-5">
            {[
              { label: 'GGP (Operators)',    pct: '~50%',      detail: '6 partners · founders + active partners' },
              { label: 'Passive SPV (LPs)',  pct: '~36%',      detail: '14 LPs pooled · UU+Jack as LP in founder shops' },
              { label: 'MIP Pool',           pct: '10% reserve', detail: 'Pheak, Chanda, Jonathan, Lam, future hires' },
            ].map((line, i) => (
              <div key={i} className="rounded-xl p-4 text-center" style={{ backgroundColor: C.card, border: `1px solid ${C.border}` }}>
                <div style={{ fontSize: '10px', fontWeight: 600, color: C.textMuted, letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: '8px' }}>{line.label}</div>
                <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '24px', fontWeight: 700, color: C.gold, lineHeight: 1, letterSpacing: '-0.02em' }}>{line.pct}</div>
                <div style={{ fontSize: '11px', color: C.textSoft, marginTop: '6px' }}>{line.detail}</div>
              </div>
            ))}
          </div>

          <div className="text-center mb-2.5" style={{ color: C.textMuted }}>
            <ChevronRight size={18} className="inline rotate-90" />
          </div>
          <div className="text-center mb-2.5" style={{ fontSize: '10px', fontWeight: 600, color: C.textMuted, letterSpacing: '0.18em', textTransform: 'uppercase' }}>Wholly-owned subsidiaries</div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {['Shop LLCs (×7)', 'Kitchen LLC', 'Golden POS LLC', 'Real Estate LLC'].map(sub => (
              <div key={sub} className="rounded-lg p-2.5 text-center" style={{ backgroundColor: C.card, border: `1px solid ${C.border}`, fontSize: '11.5px', fontWeight: 600, color: C.text }}>{sub}</div>
            ))}
          </div>
        </div>

        <p style={{ fontSize: '12px', color: C.textSoft, lineHeight: 1.55 }}>
          <strong style={{ color: C.text }}>Founders' direct stakes:</strong> Bluemound, Carrollton, and Dallas were 100% founder-funded. At rollup, founders take the 50% "LP slot" in those shops (mirroring the LP structure), with GGP getting the other 50%. The $30K founder note in Arlington/NRH ($15K each, UU + Jack) converts to additional founder equity at HoldCo formation — clean cap table, no founder debt sitting on HoldCo books.
        </p>
      </Card>

      {/* CAPITAL TIMING - The "what if 300K wants to come in NOW" answer */}
      <Card className="mb-6" tone="cream">
        <div className="flex items-center gap-2 mb-3">
          <Clock size={16} style={{ color: C.goldDeep }} />
          <Eyebrow>Capital timing</Eyebrow>
        </div>
        <H2>What if the {fmt$(scenario.safeAmount)}–500K wants to come in now?</H2>
        <p style={{ fontSize: '14px', color: C.text, marginTop: '8px', marginBottom: '20px', lineHeight: 1.55 }}>
          The investor doesn't have to wait for the rollup to complete. Three viable paths — one is clearly best.
        </p>

        <div className="space-y-4">
          {[
            {
              tag: 'RECOMMENDED',
              title: 'Form HoldCo first, take SAFE there, complete rollup over 60–90 days',
              steps: [
                'Wk 1–2: Form Golden Glaze Holdings LLC (Delaware) — 1–2 weeks, ~$500',
                'Wk 2–3: SAFE closes into HoldCo · proceeds available immediately',
                'Wk 3–6: Type B shops (Bluemound, Carrollton, Dallas) roll into HoldCo via §721',
                'Wk 6–12: Type A shops (Arl/NRH, FW, Grapevine) roll in after LP consents',
              ],
              pros: 'Cleanest. SAFE investor has equity claim in HoldCo from day one. Proceeds fund the rollup itself. No new entity needed later.',
              cons: 'HoldCo briefly holds cash but no operating assets (a few weeks). Most investors are fine with this — it\'s standard for platform LLCs.',
              accent: C.gold,
            },
            {
              tag: 'BACKUP',
              title: 'Bridge promissory note now, convert to SAFE at HoldCo formation',
              steps: [
                'Wk 1: Investor wires money as a short-term promissory note (debt) to GGP or a holding entity',
                'Wk 2: Form HoldCo',
                'Wk 3: Note converts to SAFE in HoldCo at agreed terms',
                'Wk 3–12: Rollup proceeds normally',
              ],
              pros: 'Money flows in immediately. Useful if HoldCo formation is delayed for any reason.',
              cons: 'More legal complexity. Investor pays interest in the gap. Two papering events instead of one.',
              accent: C.textSoft,
            },
            {
              tag: 'AVOID',
              title: 'Wait until rollup completes, then SAFE into HoldCo',
              steps: [
                'Wk 1–12: Rollup completes',
                'Wk 12+: SAFE closes',
              ],
              pros: 'Simplest legal mechanic.',
              cons: 'Investors hate waiting 90 days while terms could shift. Risks losing the deal entirely if better opportunities surface.',
              accent: C.textMuted,
            },
          ].map((path, i) => (
            <div key={i} className="rounded-xl p-5" style={{ backgroundColor: C.card, border: `1px solid ${path.accent === C.gold ? 'rgba(217,156,43,0.4)' : C.border}` }}>
              <div className="flex items-center gap-2 mb-3">
                <Pill tone={path.tag === 'RECOMMENDED' ? 'gold' : 'neutral'}>{path.tag}</Pill>
              </div>
              <h4 style={{ fontSize: '15px', fontWeight: 700, color: C.ink, marginBottom: '12px' }}>{path.title}</h4>
              <div className="mb-4">
                {path.steps.map((step, j) => (
                  <div key={j} className="flex gap-3 mb-1.5" style={{ fontSize: '12.5px', color: C.text }}>
                    <span style={{ fontFamily: '"JetBrains Mono", monospace', color: C.goldDeep, fontWeight: 600, minWidth: '60px' }}>{step.split(':')[0]}</span>
                    <span>{step.split(':').slice(1).join(':').trim()}</span>
                  </div>
                ))}
              </div>
              <div className="grid sm:grid-cols-2 gap-3 pt-3" style={{ borderTop: `1px solid ${C.borderSoft}` }}>
                <div>
                  <div style={{ fontSize: '10px', fontWeight: 700, color: C.goldDeep, letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: '6px' }}>Pros</div>
                  <p style={{ fontSize: '12px', color: C.textSoft, lineHeight: 1.5 }}>{path.pros}</p>
                </div>
                <div>
                  <div style={{ fontSize: '10px', fontWeight: 700, color: C.textSoft, letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: '6px' }}>Cons</div>
                  <p style={{ fontSize: '12px', color: C.textSoft, lineHeight: 1.5 }}>{path.cons}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Card>

      <Card className="mb-6">
        <H2>Sequencing · shell HoldCo first, then 6–12 months to fully roll up</H2>
        <p className="mt-1 mb-6" style={{ fontSize: '13px', color: C.textSoft }}>HoldCo entity gets formed first so it can issue the SAFE. Subsidiary LLCs roll in on their own timelines as lender/landlord consents and LP signatures clear.</p>
        <div className="space-y-3">
          {[
            ['Mo 1',     'Form Golden Glaze Holdings LLC in Delaware (shell)', 'Counsel + Founders'],
            ['Mo 1–2',   `${fmt$(scenario.safeAmount)} SAFE closes into HoldCo · proceeds released for legal fees`, 'Founders + investor'],
            ['Mo 1–3',   `Send accreditation questionnaires to all 14 LPs`, 'Founders'],
            ['Mo 2–4',   'Roll founder-funded shops (Bluemound, Carrollton, Dallas) into HoldCo', 'Counsel · §721'],
            ['Mo 3–6',   'LP consent process for Arl/NRH, FW, Grapevine', 'Capital floor + Arlington 10% pref preserved as protection'],
            ['Mo 4–8',   `$30K founder note converts to equity at HoldCo formation`, 'Founders (UU + Jack)'],
            ['Mo 6–10',  'Type A LP-shop rollups executed once LP consents complete', 'Counsel · §721'],
            ['Mo 8–12',  'HoldCo OA finalized — drag-along, ROFR, capital floor, MIP terms', 'Counsel'],
            ['Mo 10–12', 'May raise the remaining Grapevine $60K at HoldCo level (SAFE participants instead of late LPs)', 'Founders'],
          ].map(([week, task, who], i, arr) => (
            <div key={i} className="flex items-start gap-4 pb-3" style={{ borderBottom: i < arr.length - 1 ? `1px solid ${C.borderSoft}` : 'none' }}>
              <div style={{ width: '64px', flexShrink: 0, fontSize: '11px', fontWeight: 700, color: C.goldDeep, letterSpacing: '0.08em', textTransform: 'uppercase', fontFamily: '"JetBrains Mono", monospace', paddingTop: '2px' }}>{week}</div>
              <div className="flex-1">
                <div style={{ fontSize: '13.5px', fontWeight: 600, color: C.ink, marginBottom: '2px' }}>{task}</div>
                <div style={{ fontSize: '11px', color: C.textMuted, letterSpacing: '0.06em', textTransform: 'uppercase', fontWeight: 500 }}>{who}</div>
              </div>
            </div>
          ))}
        </div>
      </Card>

      <Card className="mb-6" tone="cream">
        <div className="flex items-start gap-4">
          <DonutLogo size={36} />
          <div>
            <H2>Capital floor + Arlington pref · honoring the original deal</H2>
            <p className="mt-3" style={{ fontSize: '13.5px', lineHeight: 1.6, color: C.text, marginBottom: '12px' }}>
              <strong style={{ color: C.ink }}>Arlington LPs were our earliest believers.</strong> When we closed the Arlington / NRH joint LLC in September 2025, we made an additional commitment to those 8 LPs: a <strong style={{ color: C.goldDeep }}>10% preferred return per year</strong> on top of their equity stake. That commitment was made informally as part of the original deal terms, and we intend to honor it formally through the HoldCo rollup. This is not a renegotiation — it is preservation of what was promised.
            </p>
            <p style={{ fontSize: '13.5px', lineHeight: 1.6, color: C.text, marginBottom: '12px' }}>
              <strong style={{ color: C.ink }}>The mechanic at exit:</strong> each LP receives the GREATER of (a) their pro-rata equity share in HoldCo, OR (b) original investment + accrued pref (Arlington only). For Arlington LPs, the pref-adjusted floor of <strong style={{ color: C.goldDeep }}>~$37.50K per LP at 5 years</strong> is the protected minimum. For FW and Grapevine LPs (no pref promised), the floor is their original $30K investment. GGP absorbs any difference from the floor — this is the operator partners taking on the risk so passive LPs have certainty.
            </p>
            <p style={{ fontSize: '13.5px', lineHeight: 1.6, color: C.text }}>
              <strong style={{ color: C.ink }}>Why this matters:</strong> at any reasonable exit, your equity share will dominate the floor — meaning you get more than the floor, much more. The floor protects against the unlikely downside scenario. The pref ensures Arlington LPs are specifically recognized for backing us when we had nothing but a plan and a few shops. We see you, and you remain protected through whatever happens next.
            </p>
          </div>
        </div>
      </Card>

      <div className="grid sm:grid-cols-2 gap-4">
        <Card>
          <H2>Costs (deferred to SAFE close)</H2>
          <div className="space-y-2 mt-4">
            {[
              ['Legal · formation + §721', '$25–40K'],
              ['Tax / accounting setup', '$10–15K'],
              ['Audit prep', '$15–25K'],
              ['Securities compliance', '$5–10K'],
            ].map(([k, v], i) => (
              <div key={k} className="flex justify-between pb-2" style={{ borderBottom: i < 3 ? `1px solid ${C.borderSoft}` : 'none', fontSize: '13px' }}>
                <span style={{ color: C.text }}>{k}</span>
                <span style={{ color: C.ink, fontWeight: 600, fontFamily: '"JetBrains Mono", monospace' }}>{v}</span>
              </div>
            ))}
            <div className="flex justify-between pt-3" style={{ borderTop: `2px solid ${C.text}`, fontSize: '13px' }}>
              <span style={{ fontWeight: 700, color: C.ink, letterSpacing: '0.06em', textTransform: 'uppercase' }}>Total</span>
              <span style={{ fontWeight: 700, color: C.goldDeep, fontFamily: '"JetBrains Mono", monospace' }}>$55–90K</span>
            </div>
          </div>
          <p className="mt-4" style={{ fontSize: '11.5px', color: C.textSoft, lineHeight: 1.55 }}>
            All deferred until SAFE proceeds land. Out-of-pocket cost today: <strong style={{ color: C.goldDeep }}>$0</strong>.
          </p>
        </Card>
        <Card>
          <H2>Risks to manage</H2>
          <ul className="space-y-3 mt-4" style={{ fontSize: '13px', lineHeight: 1.55, color: C.text }}>
            {[
              'LP holdouts — capital floor is the answer.',
              'Lender/landlord consents on each shop\'s debt and lease.',
              '§721 must be done correctly or it triggers tax events.',
              'HoldCo OA is a one-time chance to set governance — drag-along, ROFR, GGP vesting, MIP terms.',
            ].map((r, i) => (
              <li key={i} className="flex gap-3">
                <span className="shrink-0 mt-1.5 w-1 h-1 rounded-full" style={{ backgroundColor: C.gold }}></span>
                <span>{r}</span>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </div>
  );
}

// ============= TAB 7: MODELER =============
function TabModeler({ scenario, setScenario }) {
  const calc = useMemo(() => calcScenario(scenario), [scenario]);

  const update = (k, v) => setScenario(prev => ({ ...prev, [k]: v }));

  const stages = [
    { key: 'day1',   label: 'Day 1',     data: calc.day1 },
    { key: 'stage2', label: '+ MIP',     data: calc.stage2 },
    { key: 'stage3', label: '+ SAFE',    data: calc.stage3 },
    { key: 'stage4', label: '+ Series A', data: calc.stage4 },
  ];

  const stakeholderColors = {
    uuJack:   C.ink,
    advisors: C.textSoft,
    lps:      C.gold,
    mip:      C.goldDeep,
    safe:     C.goldSoft,
    seriesA:  C.text,
  };
  const stakeholderLabels = {
    uuJack:   'Founders',
    advisors: 'Advisors',
    lps:      'Passive LPs',
    mip:      'MIP Pool',
    safe:     'SAFE',
    seriesA:  'Series A',
  };

  return (
    <div>
      <SectionTitle
        eyebrow="07 — Modeler"
        title="Adjust any parameter. Watch the cap table evolve."
        lede="A live sandbox for what-if conversations with Jack and the team. Change the SAFE amount, the Series A pre-money, GGP split, MIP pool, exit valuation — everything recalculates in real time."
      />

      {/* Quick scenario summary */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-8">
        <Stat label="Founders combined at exit" value={fmt$(calc.exit.uuJack)} sub={`${fmtPct(calc.stage4.uuJack)} of HoldCo`} tone="accent" />
        <Stat label="Per LP at exit" value={fmt$(calc.perLPExit)} sub={`${calc.lpMOIC.toFixed(1)}× MOIC`} />
        <Stat label="SAFE return" value={fmt$(calc.exit.safe)} sub={`${calc.safeMOIC.toFixed(1)}× MOIC on ${fmt$(scenario.safeAmount)}`} />
        <Stat label="Series A return" value={fmt$(calc.exit.seriesA)} sub={`${calc.seriesAMOIC.toFixed(1)}× MOIC on ${fmt$(scenario.seriesAAmount)}`} />
      </div>

      <div className="grid lg:grid-cols-2 gap-4 mb-6">
        {/* Capital structure */}
        <Card>
          <div className="flex items-center gap-2 mb-5">
            <Coins size={16} style={{ color: C.goldDeep }} />
            <H2>Incoming SAFE</H2>
          </div>
          <div className="space-y-3.5">
            {[
              ['Amount',   'safeAmount',   50, 100, 1000, 'K', true],
              ['Cap',      'safeCap',      250, 500, 10000, 'K', true],
              ['Discount', 'safeDiscount', 5, 0, 50, '%', false],
            ].map(([label, key, step, min, max, suffix, wide]) => (
              <div key={key} className="flex items-center justify-between gap-4">
                <span style={{ fontSize: '13px', color: C.text, fontWeight: 500 }}>{label}</span>
                <Stepper value={scenario[key]} onChange={(v) => update(key, v)} step={step} min={min} max={max} suffix={suffix} wide={wide} />
              </div>
            ))}
          </div>
          <div className="mt-4 pt-3" style={{ borderTop: `1px solid ${C.borderSoft}`, fontSize: '11px', color: C.textMuted, fontFamily: '"JetBrains Mono", monospace' }}>
            SAFE converts to <span style={{ color: C.goldDeep, fontWeight: 700 }}>{fmtPct(calc.safePct)}</span> at conversion · {fmtPct(calc.safePct * (1 - calc.seriesAPct))} post-Series A
          </div>
        </Card>

        <Card>
          <div className="flex items-center gap-2 mb-5">
            <TrendingUp size={16} style={{ color: C.goldDeep }} />
            <H2>Series A</H2>
          </div>
          <div className="space-y-3.5">
            <div className="flex items-center justify-between gap-4">
              <span style={{ fontSize: '13px', color: C.text, fontWeight: 500 }}>Raise amount</span>
              <Stepper value={scenario.seriesAAmount} onChange={(v) => update('seriesAAmount', v)} step={250} min={250} max={10000} suffix="K" wide />
            </div>
            <div className="flex items-center justify-between gap-4">
              <span style={{ fontSize: '13px', color: C.text, fontWeight: 500 }}>Pre-money</span>
              <Stepper value={scenario.seriesAPreMoney} onChange={(v) => update('seriesAPreMoney', v)} step={500} min={1000} max={50000} suffix="K" wide />
            </div>
          </div>
          <div className="mt-4 pt-3" style={{ borderTop: `1px solid ${C.borderSoft}`, fontSize: '11px', color: C.textMuted, fontFamily: '"JetBrains Mono", monospace' }}>
            Series A takes <span style={{ color: C.goldDeep, fontWeight: 700 }}>{fmtPct(calc.seriesAPct)}</span> of post-money cap table
          </div>
        </Card>

        <Card>
          <div className="flex items-center gap-2 mb-5">
            <Sliders size={16} style={{ color: C.goldDeep }} />
            <H2>Structure</H2>
          </div>
          <div className="space-y-3.5">
            {[
              ['GGP slot per shop',     'ggpToShop',     5, 0, 100, '%'],
              ["Founders' share of GGP", 'ggpUUJackPct', 5, 0, 100, '%'],
              ['MIP pool reserve',      'mipPoolPct',   1, 0, 25,  '%'],
            ].map(([label, key, step, min, max, suffix]) => (
              <div key={key} className="flex items-center justify-between gap-4">
                <span style={{ fontSize: '13px', color: C.text, fontWeight: 500 }}>{label}</span>
                <Stepper value={scenario[key]} onChange={(v) => update(key, v)} step={step} min={min} max={max} suffix={suffix} />
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <div className="flex items-center gap-2 mb-5">
            <Target size={16} style={{ color: C.goldDeep }} />
            <H2>Exit valuation</H2>
          </div>
          <div className="flex items-center justify-between gap-4 mb-4">
            <span style={{ fontSize: '13px', color: C.text, fontWeight: 500 }}>Target</span>
            <Stepper value={scenario.exitValuation} onChange={(v) => update('exitValuation', v)} step={5000} min={2000} max={500000} suffix="K" wide />
          </div>
          <input
            type="range"
            min="20000"
            max="200000"
            step="5000"
            value={scenario.exitValuation}
            onChange={(e) => update('exitValuation', Number(e.target.value))}
            className="w-full"
            style={{ accentColor: C.gold }}
          />
          <div className="flex justify-between mt-2" style={{ fontSize: '10px', color: C.textMuted, letterSpacing: '0.1em', textTransform: 'uppercase', fontWeight: 500 }}>
            <span>$20M</span><span>$80M</span><span>$150M</span><span>$200M</span>
          </div>
        </Card>

        {/* Preferred return controls */}
        <Card>
          <div className="flex items-center gap-2 mb-5">
            <Award size={16} style={{ color: C.goldDeep }} />
            <H2>Preferred return</H2>
          </div>
          <p className="mb-4" style={{ fontSize: '12px', color: C.textSoft, lineHeight: 1.5 }}>
            Arlington/NRH LPs are entitled to a <strong style={{ color: C.text }}>{scenario.prefRate}% preferred return</strong> per year. Adjusts the capital floor in the Walkthrough.
          </p>
          <div className="space-y-3.5">
            <div className="flex items-center justify-between gap-4">
              <span style={{ fontSize: '13px', color: C.text, fontWeight: 500 }}>Pref rate</span>
              <Stepper value={scenario.prefRate} onChange={(v) => update('prefRate', v)} step={1} min={0} max={30} suffix="%" />
            </div>
            <div className="flex items-center justify-between gap-4">
              <span style={{ fontSize: '13px', color: C.text, fontWeight: 500 }}>Years to exit</span>
              <Stepper value={scenario.prefYears} onChange={(v) => update('prefYears', v)} step={1} min={1} max={10} suffix="y" />
            </div>
          </div>
          <div className="mt-4 pt-3" style={{ borderTop: `1px solid ${C.borderSoft}`, fontSize: '11px', color: C.textMuted, fontFamily: '"JetBrains Mono", monospace' }}>
            Per-LP pref floor: ${(25 * (1 + scenario.prefRate / 100 * scenario.prefYears)).toFixed(2)}K
            <span style={{ color: C.textSoft, marginLeft: '8px' }}>($25K + {scenario.prefRate}% × {scenario.prefYears}y simple)</span>
          </div>
        </Card>
      </div>

      {/* Cap table waterfall */}
      <Card className="mb-6">
        <H2>Cap table waterfall</H2>
        <p className="mt-1 mb-5" style={{ fontSize: '13px', color: C.textSoft }}>How ownership shifts at each stage.</p>

        <div className="space-y-3 mb-5">
          {stages.map(stage => (
            <div key={stage.key}>
              <div className="flex items-baseline justify-between mb-1.5">
                <span style={{ fontSize: '11px', fontWeight: 700, color: C.text, letterSpacing: '0.14em', textTransform: 'uppercase' }}>{stage.label}</span>
              </div>
              <div className="flex h-7 rounded-md overflow-hidden" style={{ border: `1px solid ${C.border}` }}>
                {Object.keys(stakeholderColors).map(k => {
                  const pct = stage.data[k];
                  if (pct < 0.001) return null;
                  return (
                    <div
                      key={k}
                      className="flex items-center justify-center"
                      style={{ width: `${pct * 100}%`, backgroundColor: stakeholderColors[k], color: '#FFF', fontSize: '10px', fontFamily: '"JetBrains Mono", monospace', fontWeight: 600 }}
                      title={`${stakeholderLabels[k]}: ${(pct * 100).toFixed(1)}%`}
                    >
                      {pct > 0.06 ? `${(pct * 100).toFixed(0)}%` : ''}
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-2 pt-4" style={{ borderTop: `1px solid ${C.borderSoft}` }}>
          {Object.keys(stakeholderColors).map(k => (
            <div key={k} className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-sm shrink-0" style={{ backgroundColor: stakeholderColors[k] }}></div>
              <span style={{ fontSize: '12px', color: C.textSoft, fontWeight: 500 }}>{stakeholderLabels[k]}</span>
            </div>
          ))}
        </div>
      </Card>

      {/* Exit outcomes */}
      <Card>
        <H2>Exit outcomes at {fmt$(scenario.exitValuation)}</H2>
        <p className="mt-1 mb-5" style={{ fontSize: '13px', color: C.textSoft }}>Per-stakeholder dollars and MOIC.</p>
        <div className="-mx-6 sm:-mx-7 px-6 sm:px-7 overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ borderBottom: `1px solid ${C.border}` }}>
                {['Holder', '% Final', '$ at Exit', 'Per Person'].map((h, i) => (
                  <th key={h} style={{ fontSize: '10px', fontWeight: 700, color: C.textMuted, letterSpacing: '0.14em', textTransform: 'uppercase', textAlign: i === 0 ? 'left' : 'right', padding: '10px 8px' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[
                ['Founders',        calc.stage4.uuJack,   calc.exit.uuJack,   `${fmt$(calc.exit.uuJack / 2)} each`],
                ['Advisors (×8)',   calc.stage4.advisors, calc.exit.advisors, `~${fmt$(calc.exit.advisors / 8)} each`],
                ['Passive LPs (×16)', calc.stage4.lps,    calc.exit.lps,      `${fmt$(calc.perLPExit)} · ${calc.lpMOIC.toFixed(1)}× MOIC`],
                ['MIP Pool',        calc.stage4.mip,      calc.exit.mip,      'allocated to operators'],
                [`SAFE (${fmt$(scenario.safeAmount)})`, calc.stage4.safe, calc.exit.safe, `${calc.safeMOIC.toFixed(1)}× MOIC`],
                [`Series A (${fmt$(scenario.seriesAAmount)})`, calc.stage4.seriesA, calc.exit.seriesA, `${calc.seriesAMOIC.toFixed(1)}× MOIC`],
              ].map((row, i) => (
                <tr key={i} style={{ borderBottom: `1px solid ${C.borderSoft}` }}>
                  <td className="py-3" style={{ fontSize: '13px', color: C.ink, fontWeight: 600 }}>{row[0]}</td>
                  <td className="py-3 text-right" style={{ fontSize: '12.5px', color: C.text, fontFamily: '"JetBrains Mono", monospace' }}>{(row[1] * 100).toFixed(2)}%</td>
                  <td className="py-3 text-right" style={{ fontSize: '13.5px', color: C.ink, fontWeight: 700, fontFamily: '"JetBrains Mono", monospace' }}>{fmt$(row[2])}</td>
                  <td className="py-3 text-right" style={{ fontSize: '11.5px', color: C.goldDeep, fontWeight: 600 }}>{row[3]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {calc.seriesAMOIC < 3 && scenario.exitValuation < 120000 && (
          <div className="mt-5 p-4 rounded-lg" style={{ backgroundColor: C.cream, border: `1px solid rgba(168,118,24,0.2)` }}>
            <div className="flex items-start gap-3">
              <AlertCircle size={16} style={{ color: C.goldDeep, marginTop: '2px', flexShrink: 0 }} />
              <p style={{ fontSize: '12.5px', color: C.text, lineHeight: 1.55 }}>
                <strong>Series A MOIC is {calc.seriesAMOIC.toFixed(1)}×.</strong> Institutional Series A investors typically expect 3×+ at exit. Push exit higher, lower Series A pre-money, or add liquidation preference to make the math work for them.
              </p>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}

// ============= TAB 8: WALKTHROUGH =============
function TabWalkthrough({ scenario, setScenario }) {
  const [lpShop, setLpShop] = useState('arlnrh');
  const [showMath, setShowMath] = useState(true);

  const updateValuation = (id, val) => {
    setScenario(prev => ({
      ...prev,
      storeValuations: { ...prev.storeValuations, [id]: val },
    }));
  };
  const resetValuations = () => {
    setScenario(prev => ({
      ...prev,
      storeValuations: STORES.reduce((acc, s) => ({ ...acc, [s.id]: s.valuation }), {}),
    }));
  };

  const valOf = (id) => scenario.storeValuations?.[id] ?? STORES.find(s => s.id === id)?.valuation ?? 0;
  const arlnrhVal = valOf('arl') + valOf('nrh');
  const fwStore = STORES.find(s => s.id === 'fw');
  const grpStore = STORES.find(s => s.id === 'grp');
  const shopMap = {
    arlnrh: { id: 'arlnrh', name: 'Arlington / NRH',     short: 'Arl/NRH',   shopVal: arlnrhVal, lpCount: 8, perLP: 25 },
    fw:     { id: 'fw',     name: 'Fort Worth',           short: 'FW',        shopVal: valOf('fw'), lpCount: fwStore.lpCount, perLP: fwStore.lpInvest },
    grp:    { id: 'grp',    name: 'Grapevine',            short: 'Grapevine', shopVal: valOf('grp'), lpCount: grpStore.lpCount, perLP: grpStore.lpInvest },
  };
  const sel = shopMap[lpShop];
  const calc = useMemo(() => calcScenario(scenario), [scenario]);

  // This LP's HoldCo equity value (pre-MIP)
  const lpEquityValue = (sel.shopVal * (100 - scenario.ggpToShop) / 100) / sel.lpCount;
  const lpDay1Pct = lpEquityValue / calc.totalShop;
  const lpAfterMip = lpDay1Pct * (1 - scenario.mipPoolPct / 100);
  const lpAfterSafe = lpAfterMip * (1 - calc.safePct);
  const lpAfterA = lpAfterSafe * (1 - calc.seriesAPct);

  const lpStages = [
    { label: 'HoldCo Day 1',                                 sub: `Roll-up complete · all ${STORES.length} shops contributed`, pct: lpDay1Pct },
    { label: `+ MIP Pool (${scenario.mipPoolPct}%)`,         sub: 'Active operators reserved',                                  pct: lpAfterMip },
    { label: `+ ${fmt$(scenario.safeAmount)} SAFE`,          sub: `Converts at ${fmt$(scenario.safeCap)} cap`,                  pct: lpAfterSafe },
    { label: `+ Series A (${fmt$(scenario.seriesAAmount)})`, sub: `${fmt$(scenario.seriesAPreMoney)} pre-money`,                pct: lpAfterA },
  ];

  // Exit scenarios for this LP
  const exitVals = [50000, 80000, 100000, 150000, 200000];
  const lpExits = exitVals.map(exit => {
    const equity = lpAfterA * exit;
    const floor = prefFloor;
    const received = Math.max(equity, floor);
    const moic = received / sel.perLP;
    const floorEffective = floor > equity;
    return { exit, equity, floor, received, moic, floorEffective };
  });

  // Where does the floor stop kicking in?
  const hasPref = scenario.prefShops?.includes(sel.id) ?? false;
  const prefAccrued = hasPref ? sel.perLP * (scenario.prefRate / 100) * scenario.prefYears : 0;
  const prefFloor = sel.perLP + prefAccrued;
  const floorBreakeven = lpAfterA > 0 ? prefFloor / lpAfterA : 0;

  // SAFE walkthrough
  const safePresets = [200, 300, 400, 500];
  const safePctFinal = calc.stage4.safe;
  const safeExits = exitVals.map(exit => {
    const value = safePctFinal * exit;
    const moic = value / scenario.safeAmount;
    return { exit, value, moic };
  });

  return (
    <div>
      <SectionTitle
        eyebrow="08 — Walkthrough"
        title="Personalized stake walkthroughs."
        lede="Two side-by-side calculators for the conversations that close the deal: walking each existing LP through their post-rollup outcome, and walking the new SAFE investor through theirs."
      />

      {/* SECTION A: LP Walkthrough */}
      <div className="mb-14">
        <div className="flex items-center gap-2 mb-3">
          <Users size={16} style={{ color: C.goldDeep }} />
          <Eyebrow>Section A · Existing LP</Eyebrow>
        </div>
        <h2 style={{ fontSize: 'clamp(1.5rem, 3.5vw, 2rem)', fontWeight: 700, color: C.ink, letterSpacing: '-0.015em', marginBottom: '8px' }}>Walking through with one of your sixteen LPs.</h2>
        <p className="mb-6" style={{ fontSize: '14px', color: C.textSoft, lineHeight: 1.55, maxWidth: '46rem' }}>
          Pick which shop your LP invested in. The numbers update for that exact LP — what they invested, what they own at each stage, what they get at exit.
        </p>

        {/* Shop picker */}
        <div className="grid grid-cols-3 gap-2 sm:gap-3 mb-6">
          {Object.values(shopMap).map(s => {
            const active = s.id === lpShop;
            return (
              <button
                key={s.id}
                onClick={() => setLpShop(s.id)}
                className="rounded-xl p-4 text-left transition-all"
                style={{
                  backgroundColor: active ? C.ink : C.card,
                  color: active ? C.bg : C.text,
                  border: active ? `2px solid ${C.gold}` : `1px solid ${C.border}`,
                }}
              >
                <div style={{ fontSize: '13.5px', fontWeight: 700, color: active ? '#FFF' : C.ink, marginBottom: '6px' }}>{s.name}</div>
                <div style={{ fontSize: '11px', color: active ? C.goldSoft : C.textMuted, fontFamily: '"JetBrains Mono", monospace', fontWeight: 500 }}>
                  ${s.perLP}K × {s.lpCount} LPs
                </div>
              </button>
            );
          })}
        </div>

        {/* Hero punchline */}
        <Card tone="dark" className="mb-5">
          <div className="grid sm:grid-cols-3 gap-4 sm:gap-6">
            <div>
              <div style={{ fontSize: '10.5px', color: C.goldSoft, fontWeight: 700, letterSpacing: '0.18em', textTransform: 'uppercase', marginBottom: '8px' }}>Investment</div>
              <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '36px', fontWeight: 700, lineHeight: 1, letterSpacing: '-0.02em' }}>${sel.perLP}K</div>
              <div style={{ fontSize: '12px', color: 'rgba(245,226,184,0.7)', marginTop: '6px' }}>in {sel.name}</div>
            </div>
            <div>
              <div style={{ fontSize: '10.5px', color: C.goldSoft, fontWeight: 700, letterSpacing: '0.18em', textTransform: 'uppercase', marginBottom: '8px' }}>Final HoldCo stake</div>
              <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '36px', fontWeight: 700, lineHeight: 1, letterSpacing: '-0.02em' }}>{(lpAfterA * 100).toFixed(2)}%</div>
              <div style={{ fontSize: '12px', color: 'rgba(245,226,184,0.7)', marginTop: '6px' }}>post-everything</div>
            </div>
            <div>
              <div style={{ fontSize: '10.5px', color: C.goldSoft, fontWeight: 700, letterSpacing: '0.18em', textTransform: 'uppercase', marginBottom: '8px' }}>At {fmt$(scenario.exitValuation)} exit</div>
              <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '36px', fontWeight: 700, lineHeight: 1, letterSpacing: '-0.02em', color: C.goldSoft }}>{fmt$(lpAfterA * scenario.exitValuation)}</div>
              <div style={{ fontSize: '12px', color: 'rgba(245,226,184,0.7)', marginTop: '6px' }}>{((lpAfterA * scenario.exitValuation) / sel.perLP).toFixed(0)}× MOIC</div>
            </div>
          </div>
        </Card>

        {/* Walkthrough stages */}
        <Card className="mb-5">
          <H2>Their stake, stage by stage</H2>
          <p className="mt-1 mb-6" style={{ fontSize: '13px', color: C.textSoft }}>Walk through this with the LP. Each step shows where their ownership goes and why.</p>

          <div className="space-y-3">
            {lpStages.map((stage, i) => {
              const equityValue = stage.pct * scenario.exitValuation;
              return (
                <div key={i} className="flex items-stretch gap-4">
                  <div className="flex flex-col items-center pt-1.5 shrink-0">
                    <div className="w-8 h-8 rounded-full grid place-items-center" style={{ backgroundColor: C.gold, color: C.ink, fontSize: '12px', fontWeight: 700, fontFamily: '"JetBrains Mono", monospace' }}>{i + 1}</div>
                    {i < 3 && <div className="w-px flex-1 mt-2" style={{ backgroundColor: C.border }}></div>}
                  </div>
                  <div className="flex-1 rounded-xl p-4 sm:p-5" style={{ backgroundColor: C.cardWarm, border: `1px solid ${C.border}` }}>
                    <div className="flex items-baseline justify-between gap-3 flex-wrap">
                      <div>
                        <div style={{ fontSize: '14px', fontWeight: 700, color: C.ink, marginBottom: '2px' }}>{stage.label}</div>
                        <div style={{ fontSize: '11.5px', color: C.textMuted, fontWeight: 500 }}>{stage.sub}</div>
                      </div>
                      <div className="text-right">
                        <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '22px', fontWeight: 700, color: C.ink, lineHeight: 1, letterSpacing: '-0.02em' }}>{(stage.pct * 100).toFixed(3)}%</div>
                        <div style={{ fontSize: '11px', color: C.goldDeep, marginTop: '4px', fontFamily: '"JetBrains Mono", monospace', fontWeight: 600 }}>≈ {fmt$(equityValue)} at {fmt$(scenario.exitValuation)} exit</div>
                      </div>
                    </div>
                    <div className="mt-3 h-1 rounded-full overflow-hidden" style={{ backgroundColor: C.borderSoft }}>
                      <div style={{ width: `${(stage.pct / lpStages[0].pct) * 100}%`, height: '100%', backgroundColor: C.gold }}></div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        {/* Exit outcomes */}
        <Card className="mb-5">
          <H2>What this LP gets at exit</H2>
          <p className="mt-1 mb-5" style={{ fontSize: '13px', color: C.textSoft }}>{hasPref ? <>Pref-adjusted floor of <strong style={{ color: C.goldDeep }}>${prefFloor.toFixed(2)}K</strong> (capital ${sel.perLP}K + {scenario.prefRate}% pref × {scenario.prefYears}y = ${prefAccrued.toFixed(2)}K). Above {fmt$(floorBreakeven)} exit, equity share dominates.</> : <>Capital floor of <strong style={{ color: C.goldDeep }}>${sel.perLP}K</strong> protects against very low exits. Above {fmt$(floorBreakeven)} exit, equity share dominates.</>}</p>
          <div className="-mx-6 sm:-mx-7 px-6 sm:px-7 overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr style={{ borderBottom: `1px solid ${C.border}` }}>
                  {['Exit', 'Equity Share', hasPref ? 'Pref Floor' : 'Capital Floor', 'LP Receives', 'MOIC'].map((h, i) => (
                    <th key={h} style={{ fontSize: '10px', fontWeight: 700, color: C.textMuted, letterSpacing: '0.14em', textTransform: 'uppercase', textAlign: i === 0 ? 'left' : 'right', padding: '10px 8px' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {lpExits.map((r, i) => (
                  <tr key={i} style={{ borderBottom: `1px solid ${C.borderSoft}` }}>
                    <td className="py-3" style={{ fontSize: '13.5px', color: C.ink, fontWeight: 700, fontFamily: '"JetBrains Mono", monospace' }}>{fmt$(r.exit)}</td>
                    <td className="py-3 text-right" style={{ fontSize: '13px', color: r.floorEffective ? C.textMuted : C.text, fontFamily: '"JetBrains Mono", monospace', textDecoration: r.floorEffective ? 'line-through' : 'none' }}>{fmt$(r.equity)}</td>
                    <td className="py-3 text-right" style={{ fontSize: '13px', color: r.floorEffective ? C.goldDeep : C.textMuted, fontFamily: '"JetBrains Mono", monospace', fontWeight: r.floorEffective ? 700 : 500 }}>${r.floor % 1 === 0 ? r.floor : r.floor.toFixed(2)}K</td>
                    <td className="py-3 text-right" style={{ fontSize: '14px', color: C.ink, fontWeight: 700, fontFamily: '"JetBrains Mono", monospace' }}>{fmt$(r.received)}</td>
                    <td className="py-3 text-right" style={{ fontSize: '13px', color: C.goldDeep, fontWeight: 700, fontFamily: '"JetBrains Mono", monospace' }}>{r.moic.toFixed(0)}×</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="mt-4" style={{ fontSize: '11.5px', color: C.textSoft, lineHeight: 1.55 }}>
            <strong style={{ color: C.text }}>How to walk through this:</strong> "Today you own a slice of {sel.name}. Post-rollup, that slice converts to {(lpAfterA * 100).toFixed(2)}% of the whole platform. At our base-case $100M exit, that's ~{fmt$(lpAfterA * 100000)} — about {(lpAfterA * 100000 / sel.perLP).toFixed(0)}× your money."
          </p>
        </Card>

        {/* WHY DOES IT VARY BY SHOP — interactive math card with show/hide */}
        <Card className="mb-5" style={showMath ? {} : { backgroundColor: C.cardWarm }}>
          <div className="flex items-start justify-between gap-3 flex-wrap mb-3">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-2">
                <Eyebrow>Internal · Hide before showing investors</Eyebrow>
              </div>
              <H2>The math behind per-LP stake</H2>
            </div>
            <button
              onClick={() => setShowMath(v => !v)}
              className="px-3 py-2 rounded-lg transition-colors shrink-0"
              style={{
                backgroundColor: showMath ? C.ink : C.gold,
                color: showMath ? C.bg : C.ink,
                border: 'none',
                fontSize: '12px',
                fontWeight: 700,
                letterSpacing: '0.04em',
              }}
            >
              {showMath ? 'Hide math' : 'Show math'}
            </button>
          </div>

          {showMath && (
            <>
              <p className="mt-1 mb-4" style={{ fontSize: '13px', color: C.textSoft }}>Per-LP equity = (shop fair value × 50%) ÷ LPs in pool. Adjust any valuation to see how the ranking shifts. Changes propagate everywhere in the doc.</p>

              {/* Cash vs equity distinction */}
              <div className="rounded-lg p-3 mb-5" style={{ backgroundColor: C.cardWarm, border: `1px solid ${C.border}` }}>
                <p style={{ fontSize: '11.5px', color: C.text, lineHeight: 1.55 }}>
                  <strong style={{ color: C.ink }}>LP cash vs LP equity, two different things:</strong> "LP cash invested" is what they paid (e.g., 8 × $25K = $200K for Arlington/NRH). "LP equity" is what they own at current fair value (50% of $440K = $220K for Arlington/NRH). The shop appreciated post-turnaround, so equity exceeds cash. Per-LP equity is each LP's slice of that equity pool.
                </p>
              </div>

              {/* 3-up shop math with editable inputs */}
              <div className="grid sm:grid-cols-3 gap-3 mb-5">
                {Object.values(shopMap).map((s, idx) => {
                  const lpEq = (s.shopVal * 0.5) / s.lpCount;
                  const ratio = lpEq / s.perLP;
                  const isSelected = s.id === lpShop;
                  const sHasPref = scenario.prefShops?.includes(s.id) ?? false;
                  const sPrefAccrued = sHasPref ? s.perLP * (scenario.prefRate / 100) * scenario.prefYears : 0;
                  const sPrefFloor = s.perLP + sPrefAccrued;
                  const lpCashTotal = s.perLP * s.lpCount;
                  const lpEquityTotal = s.shopVal * 0.5;
                  return (
                    <div key={s.id} className="rounded-xl p-4" style={{ backgroundColor: isSelected ? C.cream : C.card, border: `1px solid ${isSelected ? 'rgba(168,118,24,0.35)' : C.border}` }}>
                      <div className="flex items-baseline justify-between mb-3 gap-2">
                        <div style={{ fontSize: '13px', fontWeight: 700, color: C.ink }}>{s.name}</div>
                        <div style={{ fontSize: '10px', fontWeight: 700, color: C.goldDeep, letterSpacing: '0.1em', textTransform: 'uppercase', fontFamily: '"JetBrains Mono", monospace' }}>#{idx + 1}</div>
                      </div>

                      {/* Editable valuation inputs */}
                      {s.id === 'arlnrh' ? (
                        <div className="mb-3 pb-3" style={{ borderBottom: `1px solid ${C.borderSoft}` }}>
                          <div className="flex justify-between items-center mb-1.5">
                            <span style={{ fontSize: '11px', color: C.textSoft, fontFamily: '"JetBrains Mono", monospace' }}>Arlington</span>
                            <Stepper value={scenario.storeValuations?.arl ?? 330} onChange={(v) => updateValuation('arl', v)} step={10} min={50} max={2000} suffix="K" wide />
                          </div>
                          <div className="flex justify-between items-center mb-1.5">
                            <span style={{ fontSize: '11px', color: C.textSoft, fontFamily: '"JetBrains Mono", monospace' }}>NRH</span>
                            <Stepper value={scenario.storeValuations?.nrh ?? 110} onChange={(v) => updateValuation('nrh', v)} step={10} min={20} max={1000} suffix="K" wide />
                          </div>
                          <div className="flex justify-between pt-1.5" style={{ borderTop: `1px dashed ${C.borderSoft}` }}>
                            <span style={{ fontSize: '11px', color: C.text, fontFamily: '"JetBrains Mono", monospace', fontWeight: 600 }}>Combined fair value</span>
                            <span style={{ fontSize: '12px', fontWeight: 700, color: C.ink, fontFamily: '"JetBrains Mono", monospace' }}>${s.shopVal}K</span>
                          </div>
                        </div>
                      ) : (
                        <div className="mb-3 pb-3 flex justify-between items-center" style={{ borderBottom: `1px solid ${C.borderSoft}` }}>
                          <span style={{ fontSize: '11px', color: C.textSoft, fontFamily: '"JetBrains Mono", monospace' }}>Shop fair value</span>
                          <Stepper value={s.shopVal} onChange={(v) => updateValuation(s.id, v)} step={10} min={50} max={2000} suffix="K" wide />
                        </div>
                      )}

                      <div className="space-y-1.5" style={{ fontSize: '11.5px', color: C.text, fontFamily: '"JetBrains Mono", monospace' }}>
                        <div className="flex justify-between"><span style={{ color: C.textSoft }}>LP cash invested</span><span style={{ fontWeight: 600, color: C.text }}>${lpCashTotal}K</span></div>
                        <div className="flex justify-between"><span style={{ color: C.textSoft }}>LP equity (50% of FV)</span><span style={{ fontWeight: 700, color: C.ink }}>${lpEquityTotal.toFixed(0)}K</span></div>
                        <div className="flex justify-between"><span style={{ color: C.textSoft }}>÷ LPs in pool</span><span style={{ fontWeight: 700, color: C.ink }}>{s.lpCount}</span></div>
                        <div className="flex justify-between pt-1.5" style={{ borderTop: `1px solid ${C.borderSoft}` }}><span style={{ color: C.text, fontWeight: 600 }}>Per-LP equity</span><span style={{ fontWeight: 700, color: C.goldDeep, fontSize: '12.5px' }}>${lpEq.toFixed(2)}K</span></div>
                        <div className="flex justify-between"><span style={{ color: C.textSoft }}>Per-LP cash invested</span><span style={{ fontWeight: 600, color: C.text }}>${s.perLP}K</span></div>
                        {sHasPref && (
                          <>
                            <div className="flex justify-between"><span style={{ color: C.textSoft }}>+ {scenario.prefRate}% pref × {scenario.prefYears}y</span><span style={{ fontWeight: 600, color: C.text }}>+${sPrefAccrued.toFixed(2)}K</span></div>
                            <div className="flex justify-between pt-1.5" style={{ borderTop: `1px dashed ${C.borderSoft}` }}><span style={{ color: C.text, fontWeight: 600 }}>Pref-adjusted floor</span><span style={{ fontWeight: 700, color: C.goldDeep }}>${sPrefFloor.toFixed(2)}K</span></div>
                          </>
                        )}
                        <div className="flex justify-between"><span style={{ color: C.textSoft }}>Equity / cash ratio</span><span style={{ fontWeight: 700, color: ratio >= 1 ? C.goldDeep : '#B85940' }}>{ratio.toFixed(2)}×</span></div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Dynamic ranking advisor */}
              {(() => {
                const arlPerLP = (shopMap.arlnrh.shopVal * 0.5) / shopMap.arlnrh.lpCount;
                const fwPerLP = (shopMap.fw.shopVal * 0.5) / shopMap.fw.lpCount;
                const grpPerLP = (shopMap.grp.shopVal * 0.5) / shopMap.grp.lpCount;
                const desiredOrder = arlPerLP > fwPerLP && fwPerLP > grpPerLP;
                const arlNeeded = (2 * shopMap.fw.shopVal) - shopMap.arlnrh.shopVal;
                const fwNeeded = shopMap.grp.shopVal - shopMap.fw.shopVal;

                return (
                  <div className="rounded-xl p-4 mb-3" style={{ backgroundColor: desiredOrder ? 'rgba(217,156,43,0.10)' : 'rgba(184,89,64,0.08)', border: `1px solid ${desiredOrder ? 'rgba(168,118,24,0.25)' : 'rgba(184,89,64,0.25)'}` }}>
                    {desiredOrder ? (
                      <p style={{ fontSize: '12.5px', color: C.text, lineHeight: 1.6 }}>
                        <strong style={{ color: C.goldDeep }}>✓ Ranking achieved:</strong> Arlington/NRH (${arlPerLP.toFixed(1)}K per LP) &gt; Fort Worth (${fwPerLP.toFixed(1)}K) &gt; Grapevine (${grpPerLP.toFixed(1)}K). Math is consistent with the story you'd want to tell investors and existing LPs.
                      </p>
                    ) : (
                      <div style={{ fontSize: '12.5px', color: C.text, lineHeight: 1.6 }}>
                        <strong style={{ color: '#B85940' }}>Current ranking:</strong>{' '}
                        Arl/NRH ${arlPerLP.toFixed(1)}K · FW ${fwPerLP.toFixed(1)}K · Grp ${grpPerLP.toFixed(1)}K per LP. To get <strong>Arl &gt; FW &gt; Grp</strong>:
                        <ul className="mt-2 space-y-1" style={{ paddingLeft: '16px' }}>
                          {arlPerLP <= fwPerLP && (
                            <li>Arlington/NRH combined needs to be &gt; <strong style={{ fontFamily: '"JetBrains Mono", monospace' }}>${(2 * shopMap.fw.shopVal).toFixed(0)}K</strong> (currently ${shopMap.arlnrh.shopVal}K — increase by ${arlNeeded.toFixed(0)}K+).</li>
                          )}
                          {fwPerLP <= grpPerLP && (
                            <li>Fort Worth needs to be &gt; <strong style={{ fontFamily: '"JetBrains Mono", monospace' }}>${shopMap.grp.shopVal}K</strong> (currently ${shopMap.fw.shopVal}K — increase by ${fwNeeded.toFixed(0)}K+).</li>
                          )}
                        </ul>
                      </div>
                    )}
                  </div>
                );
              })()}

              {/* The relationship explained */}
              <div className="rounded-xl p-4 mb-3" style={{ backgroundColor: C.cream, border: `1px solid rgba(168,118,24,0.2)` }}>
                <p style={{ fontSize: '12.5px', color: C.text, lineHeight: 1.6 }}>
                  <strong style={{ color: C.ink }}>The honest read:</strong> Per-LP equity is structurally tied to (shop value) ÷ (number of LPs). Arlington/NRH has 8 LPs splitting the pool while Fort Worth and Grapevine have 4 each. To get Arl &gt; FW per-LP, Arlington/NRH combined must be more than <strong>2× Fort Worth's</strong> valuation. The Arlington shop genuinely is the highest-performing — pushing its valuation up to reflect that is defensible (Arlington grew +67% MRR, NRH grew +267%; a 1.4× revenue multiple isn't out of bounds for proven turnaround assets).
                </p>
              </div>

              {/* Reset */}
              <div className="flex justify-end">
                <button
                  onClick={resetValuations}
                  className="px-3 py-1.5 rounded-md transition-colors"
                  style={{ backgroundColor: 'transparent', color: C.textSoft, border: `1px solid ${C.border}`, fontSize: '11.5px', fontWeight: 600 }}
                >
                  Reset to defaults
                </button>
              </div>
            </>
          )}

          {!showMath && (
            <p className="mt-2" style={{ fontSize: '12.5px', color: C.textSoft, lineHeight: 1.5 }}>
              Math is hidden. Click "Show math" above to expose the per-LP equity breakdown and adjust shop valuations.
            </p>
          )}
        </Card>

        <Card tone="cream">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <div style={{ fontSize: '13px', fontWeight: 700, color: C.ink, marginBottom: '4px' }}>Want to test a different scenario for this LP?</div>
              <p style={{ fontSize: '12px', color: C.text, lineHeight: 1.5 }}>
                Adjust the SAFE amount, Series A terms, MIP pool, or exit valuation in the Modeler tab. Numbers here update live.
              </p>
            </div>
            <div className="px-4 py-2 rounded-lg text-sm font-semibold" style={{ backgroundColor: C.ink, color: C.bg, fontFamily: '"JetBrains Mono", monospace', fontSize: '12px' }}>
              Current: {fmt$(scenario.safeAmount)} SAFE · {fmt$(scenario.exitValuation)} exit
            </div>
          </div>
        </Card>
      </div>

      {/* DIVIDER */}
      <div className="my-12 flex items-center gap-4">
        <div className="flex-1 h-px" style={{ backgroundColor: C.border }}></div>
        <DonutLogo size={28} />
        <div className="flex-1 h-px" style={{ backgroundColor: C.border }}></div>
      </div>

      {/* SECTION B: SAFE Walkthrough */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Coins size={16} style={{ color: C.goldDeep }} />
          <Eyebrow>Section B · New SAFE investor</Eyebrow>
        </div>
        <h2 style={{ fontSize: 'clamp(1.5rem, 3.5vw, 2rem)', fontWeight: 700, color: C.ink, letterSpacing: '-0.015em', marginBottom: '8px' }}>Walking through with the {fmt$(scenario.safeAmount)} investor.</h2>
        <p className="mb-6" style={{ fontSize: '14px', color: C.textSoft, lineHeight: 1.55, maxWidth: '46rem' }}>
          The same conversation but for the new investor. Toggle the SAFE amount to see how their stake and returns change.
        </p>

        {/* SAFE amount picker */}
        <div className="mb-6">
          <div style={{ fontSize: '11px', fontWeight: 700, color: C.textSoft, letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: '10px' }}>SAFE amount</div>
          <div className="flex flex-wrap gap-2 items-center">
            {safePresets.map(amt => {
              const active = scenario.safeAmount === amt;
              return (
                <button
                  key={amt}
                  onClick={() => setScenario(prev => ({ ...prev, safeAmount: amt }))}
                  className="px-4 py-2.5 rounded-lg transition-colors"
                  style={{
                    backgroundColor: active ? C.gold : C.card,
                    color: active ? C.ink : C.text,
                    border: active ? `1px solid ${C.gold}` : `1px solid ${C.border}`,
                    fontSize: '13.5px',
                    fontWeight: 700,
                    fontFamily: '"JetBrains Mono", monospace',
                    letterSpacing: '-0.01em',
                  }}
                >
                  ${amt}K
                </button>
              );
            })}
            <div className="flex items-center gap-2 ml-2">
              <span style={{ fontSize: '12px', color: C.textMuted, fontWeight: 500 }}>Custom:</span>
              <Stepper value={scenario.safeAmount} onChange={(v) => setScenario(prev => ({ ...prev, safeAmount: v }))} step={50} min={50} max={5000} suffix="K" wide />
            </div>
          </div>
        </div>

        {/* Hero punchline for SAFE */}
        <Card tone="dark" className="mb-5">
          <div className="grid sm:grid-cols-3 gap-4 sm:gap-6">
            <div>
              <div style={{ fontSize: '10.5px', color: C.goldSoft, fontWeight: 700, letterSpacing: '0.18em', textTransform: 'uppercase', marginBottom: '8px' }}>Investment</div>
              <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '36px', fontWeight: 700, lineHeight: 1, letterSpacing: '-0.02em' }}>{fmt$(scenario.safeAmount)}</div>
              <div style={{ fontSize: '12px', color: 'rgba(245,226,184,0.7)', marginTop: '6px' }}>SAFE @ {fmt$(scenario.safeCap)} cap</div>
            </div>
            <div>
              <div style={{ fontSize: '10.5px', color: C.goldSoft, fontWeight: 700, letterSpacing: '0.18em', textTransform: 'uppercase', marginBottom: '8px' }}>Final HoldCo stake</div>
              <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '36px', fontWeight: 700, lineHeight: 1, letterSpacing: '-0.02em' }}>{(safePctFinal * 100).toFixed(2)}%</div>
              <div style={{ fontSize: '12px', color: 'rgba(245,226,184,0.7)', marginTop: '6px' }}>post-Series A</div>
            </div>
            <div>
              <div style={{ fontSize: '10.5px', color: C.goldSoft, fontWeight: 700, letterSpacing: '0.18em', textTransform: 'uppercase', marginBottom: '8px' }}>At {fmt$(scenario.exitValuation)} exit</div>
              <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '36px', fontWeight: 700, lineHeight: 1, letterSpacing: '-0.02em', color: C.goldSoft }}>{fmt$(safePctFinal * scenario.exitValuation)}</div>
              <div style={{ fontSize: '12px', color: 'rgba(245,226,184,0.7)', marginTop: '6px' }}>{(safePctFinal * scenario.exitValuation / scenario.safeAmount).toFixed(1)}× MOIC</div>
            </div>
          </div>
        </Card>

        {/* SAFE conversion math card */}
        <Card className="mb-5">
          <H2>The conversion math</H2>
          <p className="mt-1 mb-5" style={{ fontSize: '13px', color: C.textSoft }}>How {fmt$(scenario.safeAmount)} becomes equity.</p>
          <div className="grid sm:grid-cols-2 gap-3">
            <div className="rounded-xl p-4" style={{ backgroundColor: C.cardWarm, border: `1px solid ${C.border}` }}>
              <div style={{ fontSize: '10.5px', fontWeight: 700, color: C.textMuted, letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: '8px' }}>Cap route</div>
              <div style={{ fontSize: '13px', color: C.text, marginBottom: '8px' }}>{fmt$(scenario.safeAmount)} ÷ {fmt$(scenario.safeCap)} cap</div>
              <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '20px', fontWeight: 700, color: C.ink }}>= {((scenario.safeAmount / scenario.safeCap) * 100).toFixed(2)}%</div>
            </div>
            <div className="rounded-xl p-4" style={{ backgroundColor: C.cardWarm, border: `1px solid ${C.border}` }}>
              <div style={{ fontSize: '10.5px', fontWeight: 700, color: C.textMuted, letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: '8px' }}>Discount route</div>
              <div style={{ fontSize: '13px', color: C.text, marginBottom: '8px' }}>{fmt$(scenario.safeAmount)} ÷ ({fmt$(scenario.seriesAPreMoney)} × {100 - scenario.safeDiscount}%)</div>
              <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '20px', fontWeight: 700, color: C.ink }}>= {((scenario.safeAmount / (scenario.seriesAPreMoney * (100 - scenario.safeDiscount) / 100)) * 100).toFixed(2)}%</div>
            </div>
          </div>
          <div className="mt-4 p-4 rounded-lg" style={{ backgroundColor: C.cream, border: `1px solid rgba(168,118,24,0.2)` }}>
            <div style={{ fontSize: '11.5px', color: C.text, lineHeight: 1.55 }}>
              <strong style={{ color: C.ink }}>SAFE holder gets the better of the two:</strong> <span style={{ fontFamily: '"JetBrains Mono", monospace', fontWeight: 700, color: C.goldDeep }}>{fmtPct(calc.safePct)}</span> at conversion (pre-Series A cap table). After Series A dilution, this becomes <span style={{ fontFamily: '"JetBrains Mono", monospace', fontWeight: 700, color: C.goldDeep }}>{fmtPct(safePctFinal)}</span> of the post-money cap table.
            </div>
          </div>
        </Card>

        {/* SAFE exit scenarios */}
        <Card>
          <H2>What the SAFE investor gets at exit</H2>
          <p className="mt-1 mb-5" style={{ fontSize: '13px', color: C.textSoft }}>{fmt$(scenario.safeAmount)} in. Stake of {fmtPct(safePctFinal)} of HoldCo.</p>
          <div className="-mx-6 sm:-mx-7 px-6 sm:px-7 overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr style={{ borderBottom: `1px solid ${C.border}` }}>
                  {['Exit', 'SAFE Receives', 'MOIC', 'IRR (4-yr)'].map((h, i) => (
                    <th key={h} style={{ fontSize: '10px', fontWeight: 700, color: C.textMuted, letterSpacing: '0.14em', textTransform: 'uppercase', textAlign: i === 0 ? 'left' : 'right', padding: '10px 8px' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {safeExits.map((r, i) => {
                  const irr = (Math.pow(r.moic, 1/4) - 1) * 100;
                  return (
                    <tr key={i} style={{ borderBottom: `1px solid ${C.borderSoft}` }}>
                      <td className="py-3" style={{ fontSize: '13.5px', color: C.ink, fontWeight: 700, fontFamily: '"JetBrains Mono", monospace' }}>{fmt$(r.exit)}</td>
                      <td className="py-3 text-right" style={{ fontSize: '14px', color: C.ink, fontWeight: 700, fontFamily: '"JetBrains Mono", monospace' }}>{fmt$(r.value)}</td>
                      <td className="py-3 text-right" style={{ fontSize: '13.5px', color: C.goldDeep, fontWeight: 700, fontFamily: '"JetBrains Mono", monospace' }}>{r.moic.toFixed(1)}×</td>
                      <td className="py-3 text-right" style={{ fontSize: '13px', color: C.text, fontFamily: '"JetBrains Mono", monospace' }}>{irr.toFixed(0)}%</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <p className="mt-4" style={{ fontSize: '11.5px', color: C.textSoft, lineHeight: 1.55 }}>
            <strong style={{ color: C.text }}>The pitch:</strong> "Your {fmt$(scenario.safeAmount)} converts to {fmtPct(calc.safePct)} of the cap table at Series A. After Series A dilution, that's {fmtPct(safePctFinal)} of HoldCo. At our base-case $100M exit, that's {fmt$(safePctFinal * 100000)} — a {(safePctFinal * 100000 / scenario.safeAmount).toFixed(1)}× MOIC over ~4 years."
          </p>
        </Card>
      </div>
    </div>
  );
}

// ============= TAB 9: FOR EXISTING LPs =============
function TabExistingLPs({ scenario }) {
  const calc = useMemo(() => calcScenario(scenario), [scenario]);
  const lpReturns = [50, 80, scenario.exitValuation / 1000, 150, 200].map(v => v * 1000)
    .filter((v, i, arr) => arr.indexOf(v) === i)
    .sort((a, b) => a - b)
    .map(exitVal => {
      const tempCalc = calcScenario({ ...scenario, exitValuation: exitVal });
      return {
        exit: exitVal / 1000,
        perLP: tempCalc.perLPExit,
        moic: tempCalc.lpMOIC,
      };
    });

  return (
    <div>
      <SectionTitle
        eyebrow="09 — For Existing LPs"
        title="A note to our investors."
        lede="Where we are, where we're going, and what we need from you over the next 90 days. The plan protects your downside and dramatically expands your upside — but it requires your consent and a small amount of paperwork."
      />

      <Card tone="dark" className="mb-8">
        <div className="flex items-start gap-5">
          <DonutLogo size={48} />
          <div className="flex-1">
            <p style={{ fontSize: '15px', lineHeight: 1.65, color: C.bg, fontWeight: 400, marginBottom: '16px' }}>
              We started with one shop in September. Eight months later we have seven, with monthly revenue growing from roughly fifty thousand to one hundred ten thousand combined. The next chapter — institutional capital, franchise system, exit — requires us to consolidate the business under one parent. Here is how it works and what it means for you.
            </p>
            <div style={{ fontSize: '11px', fontWeight: 700, color: C.goldSoft, letterSpacing: '0.2em', textTransform: 'uppercase' }}>— Jack & Youyou</div>
          </div>
        </div>
      </Card>

      <Card className="mb-6">
        <H2>Performance update</H2>
        <p className="mt-1 mb-6" style={{ fontSize: '13px', color: C.textSoft }}>Through April 2026 — what your capital has built.</p>
        <div className="grid sm:grid-cols-3 gap-3 mb-5">
          <Stat label="Stores Acquired" value="7" sub="in 8 months" />
          <Stat label="Revenue Growth" value="+120%" sub="across portfolio" tone="accent" />
          <Stat label="Annual Run-Rate" value={fmt$(ANNUAL_RUNRATE)} sub="from ~$600K at start" />
        </div>
        <div className="space-y-3" style={{ fontSize: '13.5px', lineHeight: 1.6, color: C.text }}>
          <p>NRH went from <strong style={{ color: C.goldDeep }}>$3K/month to $11K</strong>. Arlington from <strong style={{ color: C.goldDeep }}>$18K to $30K</strong>. Bluemound, zero at acquisition, hit <strong style={{ color: C.goldDeep }}>$8K/month</strong> within weeks of opening.</p>
          <p>We're adding <strong style={{ color: C.goldDeep }}>boba</strong> at select stores, building the centralized kitchen plan, and have started conversations with a {fmt$(scenario.safeAmount)} SAFE investor.</p>
        </div>
      </Card>

      <Card className="mb-6">
        <H2>What we're asking</H2>
        <p className="mt-1 mb-6" style={{ fontSize: '13px', color: C.textSoft }}>Three small actions. None cost money.</p>
        <div className="space-y-3">
          {[
            ['1', 'Sign the §721 contribution agreement', 'Your shop LLC interest converts to a proportional interest in HoldCo. Tax-free. You become a member of the Passive SPV that holds 35% of HoldCo.'],
            ['2', 'Complete the accreditation questionnaire', 'SEC compliance for Reg D 506(b). Required before we can take new institutional capital.'],
            ['3', 'Sign the new HoldCo operating agreement', 'Includes the capital floor protection, drag-along, tag-along, and waterfall.'],
          ].map(([num, title, detail]) => (
            <div key={num} className="flex items-start gap-4 p-5 rounded-xl" style={{ backgroundColor: C.cardWarm, border: `1px solid ${C.border}` }}>
              <div className="w-9 h-9 grid place-items-center rounded-lg shrink-0" style={{ backgroundColor: C.gold, color: C.ink, fontWeight: 700, fontFamily: '"JetBrains Mono", monospace', fontSize: '15px' }}>{num}</div>
              <div>
                <h4 style={{ fontSize: '14px', fontWeight: 700, color: C.ink, marginBottom: '4px' }}>{title}</h4>
                <p style={{ fontSize: '12.5px', lineHeight: 1.55, color: C.textSoft }}>{detail}</p>
              </div>
            </div>
          ))}
        </div>
      </Card>

      <Card className="mb-6">
        <H2>What changes for you</H2>
        <p className="mt-1 mb-6" style={{ fontSize: '13px', color: C.textSoft }}>All upside, with new downside protection.</p>
        <div className="grid sm:grid-cols-2 gap-4">
          {[
            ['Capital floor protection', 'You get the GREATER of (a) pro-rata equity share at exit, or (b) original investment back. This protection did not exist before.'],
            ['Pro-rata exposure to all assets', 'Currently you own a slice of one shop. Post-roll-up, a slice of all 7 + kitchen + brand + tech + every future shop.'],
            ['Single liquidity event', 'When we exit, one wire from one buyer at one closing.'],
            ['Acceleration via institutional capital', 'The clean structure unlocks SAFE/Series A capital we cannot access today.'],
          ].map(([title, detail]) => (
            <div key={title} className="pl-5 py-1" style={{ borderLeft: `2px solid ${C.gold}` }}>
              <h4 style={{ fontSize: '14px', fontWeight: 700, color: C.ink, marginBottom: '6px' }}>{title}</h4>
              <p style={{ fontSize: '12.5px', lineHeight: 1.55, color: C.textSoft }}>{detail}</p>
            </div>
          ))}
        </div>
      </Card>

      <Card className="mb-6">
        <H2>Your potential returns</H2>
        <p className="mt-1 mb-6" style={{ fontSize: '13px', color: C.textSoft }}>Per LP at different exit valuations. Average $25–30K invested, ~21.6% combined LP equity post-everything.</p>
        <div className="-mx-6 sm:-mx-7 px-6 sm:px-7 overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ borderBottom: `1px solid ${C.border}` }}>
                {['Exit', 'Per LP', 'MOIC', 'Likelihood'].map((h, i) => (
                  <th key={h} style={{ fontSize: '10px', fontWeight: 700, color: C.textMuted, letterSpacing: '0.14em', textTransform: 'uppercase', textAlign: i === 0 ? 'left' : 'right', padding: '10px 8px' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {lpReturns.map((r, i) => (
                <tr key={i} style={{ borderBottom: `1px solid ${C.borderSoft}` }}>
                  <td className="py-3" style={{ fontSize: '14px', color: C.ink, fontWeight: 700, fontFamily: '"JetBrains Mono", monospace' }}>${r.exit}M</td>
                  <td className="py-3 text-right" style={{ fontSize: '14px', color: C.ink, fontWeight: 700, fontFamily: '"JetBrains Mono", monospace' }}>{fmt$(r.perLP)}</td>
                  <td className="py-3 text-right" style={{ fontSize: '14px', color: C.goldDeep, fontWeight: 700, fontFamily: '"JetBrains Mono", monospace' }}>{r.moic.toFixed(0)}×</td>
                  <td className="py-3 text-right" style={{ fontSize: '11px', color: C.textSoft, fontWeight: 500 }}>
                    {r.exit <= 80 ? 'High' : r.exit <= 120 ? 'Base case' : r.exit <= 200 ? 'Aggressive' : 'Stretch'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <Card>
        <H2>Timeline</H2>
        <div className="space-y-2 mt-4">
          {[
            ['Next 30 days', 'Accreditation questionnaires returned'],
            ['Next 60 days', 'New HoldCo operating agreement signed'],
            ['Next 90 days', `Roll-up complete · ${fmt$(scenario.safeAmount)} SAFE closes`],
            ['6–12 months', 'Series A round'],
            ['36–48 months', 'Exit window opens'],
          ].map(([when, what], i) => (
            <div key={when} className="flex justify-between items-center pb-2.5" style={{ borderBottom: i < 4 ? `1px solid ${C.borderSoft}` : 'none' }}>
              <span style={{ fontSize: '13px', color: C.text, fontWeight: 500 }}>{what}</span>
              <span style={{ fontSize: '10.5px', fontWeight: 700, color: C.goldDeep, letterSpacing: '0.12em', textTransform: 'uppercase', fontFamily: '"JetBrains Mono", monospace' }}>{when}</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

// ============= TAB 10: FOR NEW INVESTORS =============
function TabNewInvestors({ scenario }) {
  const [checkSize, setCheckSize] = useState(500); // K — default to anchor amount
  const calc = useMemo(() => calcScenario(scenario), [scenario]);

  // This investor's stake math
  const capRoute = checkSize / scenario.safeCap;
  const discRoute = checkSize / (scenario.seriesAPreMoney * (100 - scenario.safeDiscount) / 100);
  const investorPctAtConversion = Math.max(capRoute, discRoute);
  const investorPctFinal = investorPctAtConversion * (1 - calc.seriesAPct);
  const conversionRoute = capRoute >= discRoute ? 'cap' : 'discount';

  // Exit returns for this investor
  const investorExits = [50000, 80000, 100000, 150000, 200000].map(exit => {
    const dollars = investorPctFinal * exit;
    const moic = dollars / checkSize;
    const irr = (Math.pow(moic, 1/4) - 1) * 100;
    return { exit, dollars, moic, irr };
  });

  // Total round target — fixed reference, not parameterized
  const TOTAL_ROUND = 1000; // K
  const uofItems = [
    ['Centralized kitchen build-out', TOTAL_ROUND * 0.40],
    ['FDD legal / franchise infrastructure', TOTAL_ROUND * 0.20],
    ['Brand investment (positioning, design, PR)', TOTAL_ROUND * 0.18],
    ['Roll-up legal & compliance', TOTAL_ROUND * 0.12],
    ['Working capital + reserves', TOTAL_ROUND * 0.10],
  ];

  const checkPresets = [30, 100, 250, 500];

  return (
    <div>
      <SectionTitle
        eyebrow="10 — For New Investors"
        title="The opportunity."
        lede={`An open SAFE round, $30K minimum check. ${fmt$(scenario.safeCap)} cap, ${scenario.safeDiscount}% discount, MFN — same terms for everyone. Funds the kitchen, the FDD, the brand investment that unlocks an $80–120M exit in 4 years and Shipley scale in 7.`}
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-8">
        <Stat label="Stores Today" value="7" sub="DFW metro" />
        <Stat label="Run-Rate" value={fmt$(ANNUAL_RUNRATE)} sub="annualized · growing" tone="accent" />
        <Stat label="Revenue Growth" value="+120%" sub="post-acquisition avg" />
        <Stat label="Time to $1.3M ARR" value="8 mo" sub="from zero" />
      </div>

      <Card tone="dark" className="mb-6">
        <Eyebrow>The thesis · 60 seconds</Eyebrow>
        <p style={{ fontSize: '15.5px', lineHeight: 1.6, color: C.bg, fontWeight: 400, marginTop: '16px' }}>
          Vertically integrated specialty bakery platform. Seven acquisitions in eight months in DFW. Proven turnaround playbook (revenue +50–267% post-acquisition). Path to franchise system + centralized kitchen + supply IP + tech moat. Targeting <span style={{ color: C.goldSoft, fontWeight: 700 }}>$80–120M exit in 4 years</span>; Shipley scale ($200–400M) in 5–7. Two recent comps prove the model: Shipley sold to PE in 2021 and again in 2025; Dave's Hot Chicken sold for $1B in 2025 from a 2017 parking-lot start.
        </p>
      </Card>

      <Card className="mb-6">
        <H2>The team</H2>
        <p className="mt-1 mb-5" style={{ fontSize: '13px', color: C.textSoft }}>Rare combination in QSR roll-ups: institutional capital pedigree, data-driven operators, and real engineering capability.</p>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            { name: 'Jack',   role: 'Founder & CEO',           sub: 'Former VP, Asset & Wealth Mgmt — Goldman Sachs',     detail: 'Capital structure, deal structuring, investor relations. Spent his career advising HNW investors and family offices — the same audience we are now raising from.' },
            { name: 'Youyou', role: 'Co-founder & COO',        sub: 'SVP, Data Analytics — Top consulting firm',          detail: 'Operations across the portfolio, M&A pipeline, turnaround playbook. Background in Tableau, SQL, Python, Databricks — applied to QSR unit economics.' },
            { name: 'Peiyun', role: 'Co-founder, Engineering', sub: 'Software Engineer · Building Golden POS',            detail: 'Owns the tech stack — Golden POS, customer loyalty, demand forecasting. Building operational systems that scale across multi-unit ops.' },
          ].map(p => (
            <div key={p.name} className="rounded-xl p-5" style={{ backgroundColor: C.cardWarm, border: `1px solid ${C.border}` }}>
              <div className="flex items-baseline justify-between mb-1.5 flex-wrap gap-2">
                <h4 style={{ fontSize: '15px', fontWeight: 700, color: C.ink }}>{p.name}</h4>
                <Pill tone="gold">{p.role}</Pill>
              </div>
              <p style={{ fontSize: '10.5px', fontWeight: 600, color: C.textMuted, letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: '12px' }}>{p.sub}</p>
              <p style={{ fontSize: '13px', lineHeight: 1.55, color: C.text }}>{p.detail}</p>
            </div>
          ))}
        </div>
      </Card>

      <Card className="mb-6">
        <H2>Track record · 8 months in</H2>
        <p className="mt-1 mb-5" style={{ fontSize: '13px', color: C.textSoft }}>Per-store revenue growth. Each shop acquired distressed; each turned around.</p>
        <div className="grid sm:grid-cols-2 gap-3">
          {STORES.filter(s => s.startMRR !== null && s.startMRR > 0).map(s => {
            const growth = ((s.currentMRR - s.startMRR) / s.startMRR * 100);
            return (
              <div key={s.id} className="rounded-xl p-4" style={{ backgroundColor: C.cardWarm, border: `1px solid ${C.border}` }}>
                <div className="flex items-baseline justify-between mb-2.5 flex-wrap gap-2">
                  <h4 style={{ fontSize: '13.5px', fontWeight: 700, color: C.ink }}>{s.name}</h4>
                  <span style={{ fontSize: '10.5px', color: C.textMuted, fontWeight: 500 }}>{s.acquired}</span>
                </div>
                <div className="flex items-baseline gap-2 flex-wrap" style={{ fontFamily: '"JetBrains Mono", monospace' }}>
                  <span style={{ fontSize: '14px', color: C.textSoft, fontWeight: 600 }}>${s.startMRR}K</span>
                  <ArrowRight size={14} style={{ color: C.gold }} />
                  <span style={{ fontSize: '14px', color: C.ink, fontWeight: 700 }}>${s.currentMRR}K</span>
                  <span style={{ fontSize: '13px', color: C.goldDeep, fontWeight: 700, marginLeft: 'auto' }}>+{growth.toFixed(0)}%</span>
                </div>
              </div>
            );
          })}
          {STORES.filter(s => s.startMRR === 0).map(s => (
            <div key={s.id} className="rounded-xl p-4" style={{ backgroundColor: C.cream, border: `1px solid rgba(168,118,24,0.25)` }}>
              <div className="flex items-baseline justify-between mb-2.5 flex-wrap gap-2">
                <h4 style={{ fontSize: '13.5px', fontWeight: 700, color: C.ink }}>{s.name}</h4>
                <span style={{ fontSize: '10.5px', color: C.textMuted, fontWeight: 500 }}>{s.acquired}</span>
              </div>
              <div style={{ fontSize: '14px', color: C.ink, fontWeight: 700, fontFamily: '"JetBrains Mono", monospace', marginBottom: '4px' }}>$0K → ${s.currentMRR}K</div>
              <div style={{ fontSize: '10px', fontWeight: 700, color: C.goldDeep, letterSpacing: '0.14em', textTransform: 'uppercase' }}>New build · ramping</div>
            </div>
          ))}
        </div>
      </Card>

      {/* INTERACTIVE: Your Deal */}
      <Card className="mb-6" tone="cream">
        <div className="flex items-center gap-2 mb-3">
          <Sliders size={16} style={{ color: C.goldDeep }} />
          <Eyebrow>Your deal · interactive</Eyebrow>
        </div>
        <h3 style={{ fontSize: 'clamp(1.75rem, 4vw, 2.5rem)', fontWeight: 700, color: C.ink, lineHeight: 1.05, letterSpacing: '-0.02em', marginBottom: '8px' }}>
          What you'd own.
        </h3>
        <p style={{ fontSize: '13.5px', color: C.text, lineHeight: 1.55, maxWidth: '46rem', marginBottom: '24px' }}>
          Pick your check size. The numbers update — your stake, your exit returns, your MOIC and IRR. Same SAFE terms apply to all checks ${30}K and up.
        </p>

        {/* Check size picker */}
        <div className="mb-6">
          <div style={{ fontSize: '11px', fontWeight: 700, color: C.textSoft, letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: '10px' }}>Your check</div>
          <div className="flex flex-wrap gap-2 items-center">
            {checkPresets.map(amt => {
              const active = checkSize === amt;
              return (
                <button
                  key={amt}
                  onClick={() => setCheckSize(amt)}
                  className="px-4 py-2.5 rounded-lg transition-colors"
                  style={{
                    backgroundColor: active ? C.gold : C.card,
                    color: active ? C.ink : C.text,
                    border: active ? `1px solid ${C.gold}` : `1px solid rgba(168,118,24,0.2)`,
                    fontSize: '13.5px',
                    fontWeight: 700,
                    fontFamily: '"JetBrains Mono", monospace',
                    letterSpacing: '-0.01em',
                  }}
                >
                  ${amt}K{amt === 30 ? ' · min' : amt === 500 ? ' · anchor' : ''}
                </button>
              );
            })}
            <div className="flex items-center gap-2 ml-2">
              <span style={{ fontSize: '12px', color: C.textMuted, fontWeight: 500 }}>Custom:</span>
              <Stepper value={checkSize} onChange={setCheckSize} step={10} min={30} max={5000} suffix="K" wide />
            </div>
          </div>
        </div>

        {/* Hero stats */}
        <div className="rounded-2xl p-5 sm:p-6 mb-5" style={{ backgroundColor: C.ink, color: C.bg }}>
          <div className="grid sm:grid-cols-3 gap-4 sm:gap-6">
            <div>
              <div style={{ fontSize: '10.5px', color: C.goldSoft, fontWeight: 700, letterSpacing: '0.18em', textTransform: 'uppercase', marginBottom: '8px' }}>Your check</div>
              <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '36px', fontWeight: 700, lineHeight: 1, letterSpacing: '-0.02em' }}>${checkSize}K</div>
              <div style={{ fontSize: '12px', color: 'rgba(245,226,184,0.7)', marginTop: '6px' }}>SAFE · {fmt$(scenario.safeCap)} cap</div>
            </div>
            <div>
              <div style={{ fontSize: '10.5px', color: C.goldSoft, fontWeight: 700, letterSpacing: '0.18em', textTransform: 'uppercase', marginBottom: '8px' }}>Your stake</div>
              <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '36px', fontWeight: 700, lineHeight: 1, letterSpacing: '-0.02em' }}>{(investorPctFinal * 100).toFixed(2)}%</div>
              <div style={{ fontSize: '12px', color: 'rgba(245,226,184,0.7)', marginTop: '6px' }}>of HoldCo · post-Series A</div>
            </div>
            <div>
              <div style={{ fontSize: '10.5px', color: C.goldSoft, fontWeight: 700, letterSpacing: '0.18em', textTransform: 'uppercase', marginBottom: '8px' }}>At $100M exit</div>
              <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '36px', fontWeight: 700, lineHeight: 1, letterSpacing: '-0.02em', color: C.goldSoft }}>{fmt$(investorPctFinal * 100000)}</div>
              <div style={{ fontSize: '12px', color: 'rgba(245,226,184,0.7)', marginTop: '6px' }}>{(investorPctFinal * 100000 / checkSize).toFixed(1)}× MOIC · base case</div>
            </div>
          </div>
        </div>

        {/* Conversion math */}
        <div className="grid sm:grid-cols-2 gap-3 mb-5">
          <div className="rounded-xl p-4" style={{ backgroundColor: conversionRoute === 'cap' ? C.gold : C.card, border: `1px solid ${conversionRoute === 'cap' ? C.gold : 'rgba(168,118,24,0.2)'}` }}>
            <div className="flex items-baseline justify-between mb-2">
              <span style={{ fontSize: '10.5px', fontWeight: 700, color: conversionRoute === 'cap' ? C.ink : C.textMuted, letterSpacing: '0.14em', textTransform: 'uppercase' }}>Cap route</span>
              {conversionRoute === 'cap' && <Pill tone="neutral">winner</Pill>}
            </div>
            <div style={{ fontSize: '12.5px', color: conversionRoute === 'cap' ? C.ink : C.text, marginBottom: '6px' }}>${checkSize}K ÷ {fmt$(scenario.safeCap)}</div>
            <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '20px', fontWeight: 700, color: C.ink }}>= {(capRoute * 100).toFixed(2)}%</div>
          </div>
          <div className="rounded-xl p-4" style={{ backgroundColor: conversionRoute === 'discount' ? C.gold : C.card, border: `1px solid ${conversionRoute === 'discount' ? C.gold : 'rgba(168,118,24,0.2)'}` }}>
            <div className="flex items-baseline justify-between mb-2">
              <span style={{ fontSize: '10.5px', fontWeight: 700, color: conversionRoute === 'discount' ? C.ink : C.textMuted, letterSpacing: '0.14em', textTransform: 'uppercase' }}>Discount route</span>
              {conversionRoute === 'discount' && <Pill tone="neutral">winner</Pill>}
            </div>
            <div style={{ fontSize: '12.5px', color: conversionRoute === 'discount' ? C.ink : C.text, marginBottom: '6px' }}>${checkSize}K ÷ ({fmt$(scenario.seriesAPreMoney)} × {100 - scenario.safeDiscount}%)</div>
            <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '20px', fontWeight: 700, color: C.ink }}>= {(discRoute * 100).toFixed(2)}%</div>
          </div>
        </div>

        {/* Exit returns */}
        <div className="rounded-xl p-5" style={{ backgroundColor: C.card, border: `1px solid rgba(168,118,24,0.2)` }}>
          <h4 style={{ fontSize: '13px', fontWeight: 700, color: C.ink, letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: '14px' }}>Your returns at exit</h4>
          <div className="overflow-x-auto -mx-5 px-5">
            <table className="w-full">
              <thead>
                <tr style={{ borderBottom: `1px solid rgba(168,118,24,0.2)` }}>
                  {['Exit', 'You receive', 'MOIC', 'IRR (4-yr)'].map((h, i) => (
                    <th key={h} style={{ fontSize: '10px', fontWeight: 700, color: C.textMuted, letterSpacing: '0.14em', textTransform: 'uppercase', textAlign: i === 0 ? 'left' : 'right', padding: '8px 8px' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {investorExits.map((r, i) => {
                  const isBaseCase = r.exit === 100000;
                  return (
                    <tr key={i} style={{ borderBottom: i < 4 ? `1px solid rgba(168,118,24,0.1)` : 'none', backgroundColor: isBaseCase ? 'rgba(217,156,43,0.06)' : 'transparent' }}>
                      <td className="py-3" style={{ fontSize: '13.5px', color: C.ink, fontWeight: 700, fontFamily: '"JetBrains Mono", monospace' }}>{fmt$(r.exit)}{isBaseCase && <span style={{ color: C.goldDeep, fontSize: '10px', marginLeft: '6px', fontWeight: 700 }}>BASE</span>}</td>
                      <td className="py-3 text-right" style={{ fontSize: '14px', color: C.ink, fontWeight: 700, fontFamily: '"JetBrains Mono", monospace' }}>{fmt$(r.dollars)}</td>
                      <td className="py-3 text-right" style={{ fontSize: '13.5px', color: C.goldDeep, fontWeight: 700, fontFamily: '"JetBrains Mono", monospace' }}>{r.moic.toFixed(1)}×</td>
                      <td className="py-3 text-right" style={{ fontSize: '13px', color: C.text, fontFamily: '"JetBrains Mono", monospace' }}>{r.irr.toFixed(0)}%</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        <p className="mt-5" style={{ fontSize: '12.5px', color: C.text, lineHeight: 1.6 }}>
          <strong style={{ color: C.ink }}>The walkthrough:</strong> "Your ${checkSize}K SAFE converts at the {conversionRoute === 'cap' ? `${fmt$(scenario.safeCap)} cap` : `${scenario.safeDiscount}% discount`} — you get {(investorPctAtConversion * 100).toFixed(2)}% of the cap table at Series A. After Series A dilution, that's {(investorPctFinal * 100).toFixed(2)}% of HoldCo. At our base-case $100M exit in 4 years, that's {fmt$(investorPctFinal * 100000)} — a {(investorPctFinal * 100000 / checkSize).toFixed(1)}× return, roughly {((Math.pow(investorPctFinal * 100000 / checkSize, 1/4) - 1) * 100).toFixed(0)}% IRR."
        </p>
      </Card>

      {/* ROUND STRUCTURE + USE OF FUNDS */}
      <Card className="mb-6">
        <H2>Round structure · {fmt$(TOTAL_ROUND)} target</H2>
        <p className="mt-1 mb-5" style={{ fontSize: '13px', color: C.textSoft }}>One anchor + a small pool of strategic checks. Same SAFE terms across the round, MFN-protected.</p>

        <div className="grid sm:grid-cols-2 gap-3 mb-6">
          <div className="rounded-xl p-4" style={{ backgroundColor: C.cardWarm, border: `1px solid ${C.border}` }}>
            <div style={{ fontSize: '10.5px', fontWeight: 700, color: C.goldDeep, letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: '8px' }}>Anchor</div>
            <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '24px', fontWeight: 700, color: C.ink, lineHeight: 1, letterSpacing: '-0.02em', marginBottom: '8px' }}>$500K · 1 investor</div>
            <p style={{ fontSize: '12px', color: C.textSoft, lineHeight: 1.5 }}>Sets the round terms. Largest check, deepest engagement.</p>
          </div>
          <div className="rounded-xl p-4" style={{ backgroundColor: C.cardWarm, border: `1px solid ${C.border}` }}>
            <div style={{ fontSize: '10.5px', fontWeight: 700, color: C.goldDeep, letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: '8px' }}>Pool</div>
            <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '24px', fontWeight: 700, color: C.ink, lineHeight: 1, letterSpacing: '-0.02em', marginBottom: '8px' }}>$30K min · multiple</div>
            <p style={{ fontSize: '12px', color: C.textSoft, lineHeight: 1.5 }}>Strategic operators, advisors, smaller checks. Same SAFE terms.</p>
          </div>
        </div>

        <h4 style={{ fontSize: '13px', fontWeight: 700, color: C.ink, letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: '12px', paddingBottom: '10px', borderBottom: `1px solid ${C.borderSoft}` }}>Use of funds · {fmt$(TOTAL_ROUND)} round</h4>
        <div className="space-y-2">
          {uofItems.map(([k, v], i) => (
            <div key={k} className="flex justify-between pb-2" style={{ borderBottom: i < 4 ? `1px solid ${C.borderSoft}` : 'none', fontSize: '13px' }}>
              <span style={{ color: C.text }}>{k}</span>
              <span style={{ color: C.ink, fontWeight: 700, fontFamily: '"JetBrains Mono", monospace' }}>{fmt$(v)}</span>
            </div>
          ))}
        </div>
      </Card>

      <Card>
        <H2>Why now</H2>
        <p className="mt-1 mb-5" style={{ fontSize: '13px', color: C.textSoft }}>Category timing, founder profile, market opportunity, and PE appetite — rare combination.</p>
        <div className="grid sm:grid-cols-2 gap-4">
          {[
            ['Category timing',           'Asian-influenced bakery (mochi donuts, fusion pastries) is hot. Boba expanding margin per ticket.'],
            ['Founder profile',           'Two Asian-American operators (data scientist + SWE) doing operational turnarounds in a category nobody is innovating on.'],
            ['Market opportunity',        'DFW = 4th largest US metro. No dominant local donut brand. Independents selling at distressed valuations.'],
            ['PE appetite is hot',        'Roark just bought Dave\'s for $1B. Levine Leichtman just bought Shipley. Active checks in this space.'],
            ['Capital efficiency proven', '$380K of LP cash deployed → $1.12M of store-level value created. Pre-ramp.'],
            ['Clean structure forming',   'Roll-up in flight. Capital floor protection for LPs. Series A-ready by month 6.'],
          ].map(([title, detail]) => (
            <div key={title} className="pl-5 py-1" style={{ borderLeft: `2px solid ${C.gold}` }}>
              <h4 style={{ fontSize: '13.5px', fontWeight: 700, color: C.ink, marginBottom: '6px' }}>{title}</h4>
              <p style={{ fontSize: '12.5px', lineHeight: 1.55, color: C.textSoft }}>{detail}</p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

// ============= MAIN APP =============
export default function GoldenGlazeStrategy() {
  const [activeTab, setActiveTab] = useState('welcome');
  const [scenario, setScenario] = useState({
    safeAmount: 300,
    safeCap: 2000,
    safeDiscount: 20,
    seriesAAmount: 1000,
    seriesAPreMoney: 4000,
    ggpToShop: 50,
    ggpUUJackPct: 80,
    mipPoolPct: 10,
    exitValuation: 100000,
    storeValuations: STORES.reduce((acc, s) => ({ ...acc, [s.id]: s.valuation }), {}),
    prefRate: 10,            // % per year preferred return
    prefYears: 5,            // years from acquisition to exit (~Sep 2025 → ~Sep 2030)
    prefShops: ['arlnrh'],   // which shopMap keys carry the pref
  });

  const tabs = [
    { id: 'welcome',        label: 'Welcome',           icon: BookOpen,    num: '01' },
    { id: 'foundations',    label: 'Foundations',       icon: BookOpen,    num: '02' },
    { id: 'where-we-are',   label: 'Where We Are',      icon: MapPin,      num: '03' },
    { id: 'team',           label: 'The Team',          icon: UserCircle2, num: '04' },
    { id: 'vision',         label: 'Vision & Exit',     icon: Target,      num: '05' },
    { id: 'rollup',         label: 'The Roll-Up',       icon: GitMerge,    num: '06' },
    { id: 'modeler',        label: 'Modeler',           icon: Sliders,     num: '07' },
    { id: 'walkthrough',    label: 'Walkthrough',       icon: ChevronRight, num: '08' },
    { id: 'lp-update',      label: 'For Existing LPs',  icon: Users,       num: '09' },
    { id: 'new-investors',  label: 'For New Investors', icon: TrendingUp,  num: '10' },
  ];

  // Map tab number → tab id for the Welcome tab's navigation buttons
  const numToId = Object.fromEntries(tabs.map(t => [t.num, t.id]));
  const navigateByNum = (num) => setActiveTab(numToId[num] || 'welcome');

  return (
    <>
      <style>{FONT_IMPORT}</style>
      <div className="min-h-screen pb-20" style={{ fontFamily: '"Montserrat", sans-serif', backgroundColor: C.bg, color: C.ink, fontWeight: 400 }}>

        {/* HEADER */}
        <header style={{ borderBottom: `1px solid ${C.border}` }}>
          <div className="max-w-6xl mx-auto px-5 sm:px-10 py-7 sm:py-10">
            {/* Logo lockup + scenario chip */}
            <div className="flex items-center justify-between gap-4 mb-10 flex-wrap">
              <div className="flex items-center gap-3.5">
                <DonutLogo size={48} />
                <div className="leading-none">
                  <ScriptWordmark size="md" color={C.text} />
                  <div style={{ fontFamily: '"Montserrat", sans-serif', fontSize: '0.65rem', color: C.textSoft, letterSpacing: '0.42em', fontWeight: 700, marginTop: '4px' }}>DONUTS</div>
                </div>
              </div>

              {/* Live scenario indicator — clickable hint to Modeler */}
              <button
                onClick={() => setActiveTab('modeler')}
                className="flex items-center gap-2 px-3.5 py-2 rounded-full transition-colors"
                style={{ backgroundColor: C.card, border: `1px solid ${C.border}` }}
              >
                <Sliders size={11} style={{ color: C.goldDeep }} />
                <span style={{ fontSize: '11px', color: C.textSoft, fontWeight: 500 }}>Scenario:</span>
                <span style={{ fontSize: '11px', color: C.ink, fontWeight: 700, fontFamily: '"JetBrains Mono", monospace' }}>
                  {fmt$(scenario.safeAmount)} SAFE · {fmt$(scenario.exitValuation)} exit
                </span>
              </button>
            </div>

            {/* Editorial headline */}
            <Eyebrow>Strategic memorandum · Confidential</Eyebrow>
            <H1 size="xl">From seven shops <br className="hidden sm:block"/>to a {fmt$(scenario.exitValuation)} exit.</H1>
            <p className="mt-5 max-w-2xl leading-relaxed" style={{ fontSize: '15px', color: C.textSoft, fontWeight: 400 }}>
              Internal thinking document and external pitch deck. Discuss with Jack, present to existing LPs, pitch new investors.
            </p>
          </div>
        </header>

        {/* TAB NAVIGATION */}
        <nav className="sticky top-0 z-10" style={{ backgroundColor: 'rgba(250,246,234,0.92)', backdropFilter: 'blur(10px)', WebkitBackdropFilter: 'blur(10px)', borderBottom: `1px solid ${C.border}` }}>
          <div className="max-w-6xl mx-auto px-5 sm:px-10">
            <div className="flex gap-0 overflow-x-auto" style={{ scrollbarWidth: 'none' }}>
              {tabs.map(tab => {
                const Icon = tab.icon;
                const active = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className="shrink-0 flex items-center gap-2 px-3 sm:px-4 py-4 transition-all"
                    style={{
                      borderBottom: `2px solid ${active ? C.gold : 'transparent'}`,
                      color: active ? C.ink : C.textSoft,
                      fontWeight: active ? 700 : 500,
                      fontSize: '13px',
                    }}>
                    <span style={{ fontSize: '10px', color: active ? C.goldDeep : C.textMuted, fontFamily: '"JetBrains Mono", monospace', fontWeight: 600 }}>{tab.num}</span>
                    <Icon size={14} strokeWidth={2} className="shrink-0" />
                    <span className="whitespace-nowrap">{tab.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </nav>

        {/* CONTENT */}
        <main className="max-w-6xl mx-auto px-5 sm:px-10 pt-10 sm:pt-14">
          {activeTab === 'welcome'       && <TabWelcome onNavigate={navigateByNum} scenario={scenario} />}
          {activeTab === 'foundations'   && <TabFoundations />}
          {activeTab === 'where-we-are'  && <TabWhereWeAre scenario={scenario} />}
          {activeTab === 'team'          && <TabTeam />}
          {activeTab === 'vision'        && <TabVision scenario={scenario} />}
          {activeTab === 'rollup'        && <TabRollup scenario={scenario} />}
          {activeTab === 'modeler'       && <TabModeler scenario={scenario} setScenario={setScenario} />}
          {activeTab === 'walkthrough'   && <TabWalkthrough scenario={scenario} setScenario={setScenario} />}
          {activeTab === 'lp-update'     && <TabExistingLPs scenario={scenario} />}
          {activeTab === 'new-investors' && <TabNewInvestors scenario={scenario} />}
        </main>

        {/* FOOTER */}
        <footer className="max-w-6xl mx-auto px-5 sm:px-10 mt-20 pt-7" style={{ borderTop: `1px solid ${C.border}` }}>
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-3">
              <DonutLogo size={28} />
              <div className="leading-none">
                <ScriptWordmark size="sm" color={C.text} />
                <div style={{ fontFamily: '"Montserrat", sans-serif', fontSize: '0.55rem', color: C.textSoft, letterSpacing: '0.4em', fontWeight: 700, marginTop: '3px' }}>DONUTS</div>
              </div>
            </div>
            <div className="flex items-center gap-6" style={{ fontSize: '10.5px', fontWeight: 600, color: C.textMuted, letterSpacing: '0.2em', textTransform: 'uppercase' }}>
              <span>Confidential</span>
              <span className="hidden sm:inline">v2.0 · May 2026</span>
            </div>
          </div>
        </footer>
      </div>
    </>
  );
}
