// Build: Standard Investor Deck — for small SAFE investors ($25K-$50K)
// Focus: story, founders, simple math, the ask
// 10 slides

const PptxGenJS = require('pptxgenjs');

const C = {
  ink: '1A1208',
  text: '3A2818',
  textSoft: '6B5840',
  textMuted: '8E7857',
  gold: 'D99C2B',
  goldDeep: 'A87618',
  goldSoft: 'F3D896',
  cream: 'FAF6EA',
  card: 'F8EFD7',
  white: 'FFFFFF',
  border: 'E8D9B8',
};

const FONT_DISPLAY = 'Georgia';
const FONT_BODY = 'Calibri';
const FONT_MONO = 'Consolas';

const pres = new PptxGenJS();
pres.layout = 'LAYOUT_WIDE'; // 13.33 x 7.5
pres.defineLayout({ name: 'WIDE16x9', width: 13.333, height: 7.5 });

const W = 13.333, H = 7.5;

// Helper: title slide layout
const addBg = (slide, color = C.cream) => {
  slide.background = { color };
};

const addFooter = (slide, num, total) => {
  slide.addText('Golden Glaze Donuts · Confidential', {
    x: 0.6, y: 7.0, w: 6, h: 0.3,
    fontSize: 10, fontFace: FONT_BODY, color: C.textMuted, italic: true,
  });
  slide.addText(`${num} / ${total}`, {
    x: W - 1.5, y: 7.0, w: 0.9, h: 0.3,
    fontSize: 10, fontFace: FONT_MONO, color: C.textMuted, align: 'right',
  });
};

const T = 10; // total slides

// ============ SLIDE 1: COVER ============
const s1 = pres.addSlide();
addBg(s1, C.ink);
s1.addShape('rect', { x: 0, y: 0, w: W, h: 1.8, fill: { color: C.gold }, line: { type: 'none' } });
s1.addText('GOLDEN GLAZE DONUTS', {
  x: 0.8, y: 0.5, w: 12, h: 0.8,
  fontSize: 36, fontFace: FONT_DISPLAY, bold: true, color: C.ink,
  charSpacing: 4,
});
s1.addText('A DFW donut shop roll-up — investment opportunity', {
  x: 0.8, y: 1.2, w: 12, h: 0.4,
  fontSize: 14, fontFace: FONT_BODY, italic: true, color: C.ink,
});

s1.addText('Seven shops. One brand. Built to exit.', {
  x: 0.8, y: 3.2, w: 12, h: 1,
  fontSize: 44, fontFace: FONT_DISPLAY, bold: true, color: C.cream,
  charSpacing: -1,
});

s1.addText(
  'We acquired seven under-performing donut shops in Dallas-Fort Worth between September 2025 and April 2026. We are turning them around, consolidating them under one brand, and building toward a private equity exit in the $80-120M range over the next four years. This is your invitation to participate.',
  {
    x: 0.8, y: 4.6, w: 11.5, h: 1.6,
    fontSize: 16, fontFace: FONT_BODY, color: C.cream, lineSpacingMultiple: 1.3,
  }
);

s1.addText('Youyou Chen, CEO  ·  Jack Zhou, Founder  ·  Peiyun Li, Engineering  ·  Max Yang, Analysis', {
  x: 0.8, y: 6.7, w: 12, h: 0.4,
  fontSize: 11, fontFace: FONT_BODY, color: C.goldSoft, charSpacing: 2,
});

// ============ SLIDE 2: WHAT WE'VE BUILT ============
const s2 = pres.addSlide();
addBg(s2);
s2.addText('What we have built — in eight months', {
  x: 0.6, y: 0.5, w: 12, h: 0.7,
  fontSize: 32, fontFace: FONT_DISPLAY, bold: true, color: C.ink, charSpacing: -0.5,
});
s2.addShape('rect', { x: 0.6, y: 1.25, w: 0.6, h: 0.04, fill: { color: C.gold }, line: { type: 'none' } });

// 4 stat boxes
const stats = [
  { label: 'Shops acquired', value: '7', sub: 'across DFW' },
  { label: 'Net ARR run rate', value: '$1.3M', sub: 'gross ~$1.5M' },
  { label: 'Acquisition timeline', value: '8 months', sub: 'Sep 2025 - Apr 2026' },
  { label: 'Founder cash invested', value: 'all-in', sub: 'real skin in the game' },
];
stats.forEach((s, i) => {
  const x = 0.6 + i * 3.15;
  s2.addShape('roundRect', { x, y: 1.7, w: 2.95, h: 1.6, fill: { color: C.white }, line: { color: C.border, pt: 1 }, rectRadius: 0.1 });
  s2.addText(s.label, { x: x + 0.2, y: 1.85, w: 2.55, h: 0.3, fontSize: 10, fontFace: FONT_BODY, color: C.textMuted, bold: true, charSpacing: 2 });
  s2.addText(s.value, { x: x + 0.2, y: 2.2, w: 2.55, h: 0.8, fontSize: 36, fontFace: FONT_MONO, bold: true, color: C.goldDeep, charSpacing: -2 });
  s2.addText(s.sub, { x: x + 0.2, y: 2.95, w: 2.55, h: 0.3, fontSize: 11, fontFace: FONT_BODY, italic: true, color: C.textSoft });
});

s2.addText('The shops', { x: 0.6, y: 3.6, w: 12, h: 0.4, fontSize: 14, fontFace: FONT_BODY, bold: true, color: C.ink, charSpacing: 1 });

const shops = [
  { name: 'Arlington',    date: 'Sep 2025' },
  { name: 'NRH',          date: 'Oct 2025' },
  { name: 'Fort Worth',   date: 'Dec 2025' },
  { name: 'Grapevine',    date: 'Jan 2026' },
  { name: 'Carrollton',   date: 'Feb 2026' },
  { name: 'Bluemound',    date: 'Mar 2026' },
  { name: 'Dallas',       date: 'Apr 2026' },
];
shops.forEach((shop, i) => {
  const x = 0.6 + i * 1.78;
  s2.addShape('roundRect', { x, y: 4.1, w: 1.65, h: 1.0, fill: { color: C.card }, line: { type: 'none' }, rectRadius: 0.08 });
  s2.addText(shop.name, { x: x + 0.1, y: 4.2, w: 1.45, h: 0.4, fontSize: 13, fontFace: FONT_BODY, bold: true, color: C.ink, align: 'center' });
  s2.addText(shop.date, { x: x + 0.1, y: 4.6, w: 1.45, h: 0.3, fontSize: 9, fontFace: FONT_MONO, color: C.textMuted, align: 'center' });
});

s2.addShape('roundRect', { x: 0.6, y: 5.4, w: 12.1, h: 1.3, fill: { color: C.ink }, line: { type: 'none' }, rectRadius: 0.1 });
s2.addText('This is real. The shops exist, the revenue exists, the operations are running. Every day. Right now.', {
  x: 1.0, y: 5.6, w: 11.4, h: 0.9,
  fontSize: 18, fontFace: FONT_DISPLAY, italic: true, color: C.cream, valign: 'middle',
});

addFooter(s2, 2, T);

// ============ SLIDE 3: THE THESIS ============
const s3 = pres.addSlide();
addBg(s3);
s3.addText('Why donuts. Why now. Why us.', {
  x: 0.6, y: 0.5, w: 12, h: 0.7,
  fontSize: 32, fontFace: FONT_DISPLAY, bold: true, color: C.ink, charSpacing: -0.5,
});
s3.addShape('rect', { x: 0.6, y: 1.25, w: 0.6, h: 0.04, fill: { color: C.gold }, line: { type: 'none' } });

const thesis = [
  {
    num: '01',
    title: 'A fragmented market with low entry prices',
    body: 'Donut shops sell for 0.4-0.8× revenue when buyers find tired owners — far below QSR average. Most are mom-and-pop, no brand, no tech. The roll-up opportunity is staring at us.',
  },
  {
    num: '02',
    title: 'A proven exit pattern',
    body: 'Shipley Do-Nuts — same DFW market, same product category — sold from one private equity firm to another in 2025 at ~2× their entry value. Krispy Kreme went from $1.35B private to $3.8B public in five years. The buyers exist.',
  },
  {
    num: '03',
    title: 'A team that actually executes',
    body: 'Ex-Goldman finance + active analytics consultant + working engineer + analyst. Plus master bakers and existing shop owners. We have done seven acquisitions in eight months. That is not a slide. That is a track record.',
  },
];

thesis.forEach((t, i) => {
  const y = 1.7 + i * 1.6;
  s3.addShape('roundRect', { x: 0.6, y, w: 12.1, h: 1.4, fill: { color: C.white }, line: { color: C.border, pt: 1 }, rectRadius: 0.08 });
  s3.addText(t.num, { x: 0.85, y: y + 0.2, w: 0.9, h: 1.0, fontSize: 38, fontFace: FONT_MONO, bold: true, color: C.gold, valign: 'middle' });
  s3.addText(t.title, { x: 1.9, y: y + 0.18, w: 10.5, h: 0.5, fontSize: 16, fontFace: FONT_DISPLAY, bold: true, color: C.ink });
  s3.addText(t.body, { x: 1.9, y: y + 0.65, w: 10.5, h: 0.7, fontSize: 12, fontFace: FONT_BODY, color: C.text, lineSpacingMultiple: 1.3 });
});

addFooter(s3, 3, T);

// ============ SLIDE 4: THE TEAM ============
const s4 = pres.addSlide();
addBg(s4);
s4.addText('The four founders', {
  x: 0.6, y: 0.5, w: 12, h: 0.7,
  fontSize: 32, fontFace: FONT_DISPLAY, bold: true, color: C.ink, charSpacing: -0.5,
});
s4.addShape('rect', { x: 0.6, y: 1.25, w: 0.6, h: 0.04, fill: { color: C.gold }, line: { type: 'none' } });
s4.addText('Combined 80% of the operator entity. The people you are actually backing.', {
  x: 0.6, y: 1.4, w: 12, h: 0.4, fontSize: 13, fontFace: FONT_BODY, italic: true, color: C.textSoft,
});

const team = [
  {
    initials: 'JZ',
    name: 'Jack Zhou',
    role: 'Founder & CEO',
    now: 'Previously: VP, Asset & Wealth Management at Goldman Sachs',
    focus: 'Capital structure, investor relations, deal structuring. The reason this looks institutional.',
  },
  {
    initials: 'YC',
    name: 'Youyou Chen',
    role: 'Co-founder & COO',
    now: 'Currently: SVP Data Analytics, top-tier consulting firm',
    focus: 'Operations across 7 shops, the M&A pipeline, the playbook. The reason this scales.',
  },
  {
    initials: 'PL',
    name: 'Peiyun Li',
    role: 'Co-founder, Engineering',
    now: 'Currently: Software Engineer · Building Golden POS',
    focus: 'The proprietary tech stack — loyalty, demand forecasting, POS data. The reason this defends.',
  },
  {
    initials: 'MY',
    name: 'Max Yang',
    role: 'Co-founder, Analysis',
    now: 'Currently: Business Analyst',
    focus: 'Financial modeling, M&A pipeline evaluation, scenario planning. The second pair of eyes on every call.',
  },
];

team.forEach((m, i) => {
  const x = 0.6 + (i % 2) * 6.2;
  const y = 2.0 + Math.floor(i / 2) * 2.4;
  s4.addShape('roundRect', { x, y, w: 6.0, h: 2.2, fill: { color: C.white }, line: { color: C.border, pt: 1 }, rectRadius: 0.1 });
  s4.addShape('ellipse', { x: x + 0.3, y: y + 0.3, w: 1.0, h: 1.0, fill: { color: C.gold }, line: { type: 'none' } });
  s4.addText(m.initials, { x: x + 0.3, y: y + 0.3, w: 1.0, h: 1.0, fontSize: 18, fontFace: FONT_MONO, bold: true, color: C.ink, align: 'center', valign: 'middle' });
  s4.addText(m.name, { x: x + 1.5, y: y + 0.25, w: 4.3, h: 0.4, fontSize: 18, fontFace: FONT_DISPLAY, bold: true, color: C.ink });
  s4.addText(m.role, { x: x + 1.5, y: y + 0.65, w: 4.3, h: 0.3, fontSize: 11, fontFace: FONT_BODY, bold: true, color: C.goldDeep, charSpacing: 1 });
  s4.addText(m.now, { x: x + 0.3, y: y + 1.4, w: 5.4, h: 0.35, fontSize: 10.5, fontFace: FONT_BODY, italic: true, color: C.textSoft });
  s4.addText(m.focus, { x: x + 0.3, y: y + 1.75, w: 5.4, h: 0.4, fontSize: 11, fontFace: FONT_BODY, color: C.text });
});

addFooter(s4, 4, T);

// ============ SLIDE 5: THE PLAYBOOK ============
const s5 = pres.addSlide();
addBg(s5);
s5.addText('The acquire-turn-around-roll-up playbook', {
  x: 0.6, y: 0.5, w: 12, h: 0.7,
  fontSize: 32, fontFace: FONT_DISPLAY, bold: true, color: C.ink, charSpacing: -0.5,
});
s5.addShape('rect', { x: 0.6, y: 1.25, w: 0.6, h: 0.04, fill: { color: C.gold }, line: { type: 'none' } });

const steps = [
  { num: '01', title: 'Acquire under-performing shops', body: 'Tired owners, deferred maintenance, broken recipes. We buy at 0.4-0.8× revenue — below market median.' },
  { num: '02', title: 'Operational turnaround', body: 'New recipes, better staff, clean facilities, real bookkeeping. Margins climb from underwater to 10-15% net.' },
  { num: '03', title: 'Consolidate under one brand', body: 'Golden Glaze identity, shared back-office, Golden POS deployed, centralized supply chain. Now it is a chain.' },
  { num: '04', title: 'Sell to PE', body: 'At 25-40 shops with $10-15M ARR, exit to a strategic or PE buyer at QSR multiples. Target $80-120M in 4 years.' },
];

steps.forEach((s, i) => {
  const y = 1.7 + i * 1.25;
  s5.addShape('roundRect', { x: 0.6, y, w: 12.1, h: 1.1, fill: { color: C.white }, line: { color: C.border, pt: 1 }, rectRadius: 0.08 });
  s5.addShape('roundRect', { x: 0.85, y: y + 0.2, w: 1.2, h: 0.7, fill: { color: C.gold }, line: { type: 'none' }, rectRadius: 0.06 });
  s5.addText(s.num, { x: 0.85, y: y + 0.2, w: 1.2, h: 0.7, fontSize: 22, fontFace: FONT_MONO, bold: true, color: C.ink, align: 'center', valign: 'middle' });
  s5.addText(s.title, { x: 2.25, y: y + 0.15, w: 10.2, h: 0.45, fontSize: 16, fontFace: FONT_DISPLAY, bold: true, color: C.ink });
  s5.addText(s.body, { x: 2.25, y: y + 0.55, w: 10.2, h: 0.5, fontSize: 12, fontFace: FONT_BODY, color: C.text, lineSpacingMultiple: 1.3 });
});

s5.addText('We are between steps 02 and 03. The first seven are operating. Now we consolidate and scale.', {
  x: 0.6, y: 6.85, w: 12, h: 0.4, fontSize: 13, fontFace: FONT_BODY, italic: true, color: C.goldDeep, align: 'center',
});

addFooter(s5, 5, T);

// ============ SLIDE 6: THE ROLL-UP STRUCTURE ============
const s6 = pres.addSlide();
addBg(s6);
s6.addText('How we are putting it all under one roof', {
  x: 0.6, y: 0.5, w: 12, h: 0.7,
  fontSize: 32, fontFace: FONT_DISPLAY, bold: true, color: C.ink, charSpacing: -0.5,
});
s6.addShape('rect', { x: 0.6, y: 1.25, w: 0.6, h: 0.04, fill: { color: C.gold }, line: { type: 'none' } });
s6.addText('Golden Glaze Holdings LLC — a Delaware holding company that owns 100% of every shop. Three clean lines on the cap table.', {
  x: 0.6, y: 1.4, w: 12, h: 0.5, fontSize: 13, fontFace: FONT_BODY, italic: true, color: C.textSoft, lineSpacingMultiple: 1.3,
});

// HoldCo box
s6.addShape('roundRect', { x: 4.5, y: 2.2, w: 4.3, h: 1.0, fill: { color: C.ink }, line: { type: 'none' }, rectRadius: 0.08 });
s6.addText('Golden Glaze Holdings LLC', { x: 4.5, y: 2.3, w: 4.3, h: 0.4, fontSize: 14, fontFace: FONT_DISPLAY, bold: true, color: C.cream, align: 'center' });
s6.addText('Delaware C-corp ready · the HoldCo', { x: 4.5, y: 2.75, w: 4.3, h: 0.35, fontSize: 10, fontFace: FONT_BODY, italic: true, color: C.goldSoft, align: 'center' });

// Three cap table lines
const lines = [
  { x: 0.6, name: 'GGP (operators)', pct: '~50%', sub: '4 founders + 1 active partner\n+ 4 strategic advisors' },
  { x: 4.95, name: 'Passive SPV (LPs)', pct: '~40%', sub: '14 existing LPs\npooled into one clean line' },
  { x: 9.3, name: 'MIP pool', pct: '10%', sub: 'Reserved for future hires\nCFO, COO, GMs' },
];
lines.forEach(l => {
  s6.addShape('roundRect', { x: l.x, y: 3.7, w: 3.6, h: 1.9, fill: { color: C.white }, line: { color: C.border, pt: 1 }, rectRadius: 0.08 });
  s6.addText(l.name, { x: l.x + 0.2, y: 3.85, w: 3.2, h: 0.4, fontSize: 14, fontFace: FONT_BODY, bold: true, color: C.ink, charSpacing: 1 });
  s6.addText(l.pct, { x: l.x + 0.2, y: 4.25, w: 3.2, h: 0.7, fontSize: 36, fontFace: FONT_MONO, bold: true, color: C.goldDeep, charSpacing: -2 });
  s6.addText(l.sub, { x: l.x + 0.2, y: 4.95, w: 3.2, h: 0.6, fontSize: 11, fontFace: FONT_BODY, italic: true, color: C.textSoft, lineSpacingMultiple: 1.2 });
});

s6.addShape('roundRect', { x: 0.6, y: 5.85, w: 12.1, h: 1.1, fill: { color: C.card }, line: { type: 'none' }, rectRadius: 0.08 });
s6.addText('What this means for you', { x: 0.85, y: 5.95, w: 11.6, h: 0.3, fontSize: 11, fontFace: FONT_BODY, bold: true, color: C.goldDeep, charSpacing: 1 });
s6.addText('Your SAFE converts into HoldCo equity at the next priced round — clean, institutional-standard structure that private equity buyers expect. No messy seven-shop cap table for them to untangle at exit.', {
  x: 0.85, y: 6.25, w: 11.6, h: 0.7, fontSize: 12.5, fontFace: FONT_BODY, color: C.text, lineSpacingMultiple: 1.3,
});

addFooter(s6, 6, T);

// ============ SLIDE 7: WHERE WE GO ============
const s7 = pres.addSlide();
addBg(s7);
s7.addText('The four-year path to exit', {
  x: 0.6, y: 0.5, w: 12, h: 0.7,
  fontSize: 32, fontFace: FONT_DISPLAY, bold: true, color: C.ink, charSpacing: -0.5,
});
s7.addShape('rect', { x: 0.6, y: 1.25, w: 0.6, h: 0.04, fill: { color: C.gold }, line: { type: 'none' } });

const phases = [
  { yr: 'Today', shops: '7', arr: '$1.3M', milestone: 'Acquired · operations running' },
  { yr: 'Year 1', shops: '12-15', arr: '$3-4M', milestone: 'Series A · Jonathan onboarded · brand launched' },
  { yr: 'Year 2', shops: '20-25', arr: '$6-8M', milestone: 'Franchise model tested · CFO/COO in place' },
  { yr: 'Year 4', shops: '30-40', arr: '$10-15M', milestone: 'PE-ready · multiple acquirer interest' },
];

const colW = 2.95;
phases.forEach((p, i) => {
  const x = 0.6 + i * 3.1;
  s7.addShape('roundRect', { x, y: 2.0, w: colW, h: 4.5, fill: { color: i === 3 ? C.ink : C.white }, line: { color: C.border, pt: 1 }, rectRadius: 0.1 });
  const textColor = i === 3 ? C.cream : C.text;
  const accentColor = i === 3 ? C.gold : C.goldDeep;
  s7.addText(p.yr, { x: x + 0.2, y: 2.15, w: colW - 0.4, h: 0.4, fontSize: 13, fontFace: FONT_BODY, bold: true, color: accentColor, charSpacing: 2 });
  s7.addShape('rect', { x: x + 0.2, y: 2.6, w: colW - 0.4, h: 0.03, fill: { color: i === 3 ? C.gold : C.border }, line: { type: 'none' } });

  s7.addText('Shops', { x: x + 0.2, y: 2.8, w: colW - 0.4, h: 0.3, fontSize: 10, fontFace: FONT_BODY, color: i === 3 ? C.goldSoft : C.textMuted, charSpacing: 1 });
  s7.addText(p.shops, { x: x + 0.2, y: 3.1, w: colW - 0.4, h: 0.6, fontSize: 28, fontFace: FONT_MONO, bold: true, color: i === 3 ? C.gold : C.goldDeep, charSpacing: -1 });

  s7.addText('ARR', { x: x + 0.2, y: 3.85, w: colW - 0.4, h: 0.3, fontSize: 10, fontFace: FONT_BODY, color: i === 3 ? C.goldSoft : C.textMuted, charSpacing: 1 });
  s7.addText(p.arr, { x: x + 0.2, y: 4.15, w: colW - 0.4, h: 0.55, fontSize: 24, fontFace: FONT_MONO, bold: true, color: i === 3 ? C.cream : C.ink, charSpacing: -1 });

  s7.addText('Milestone', { x: x + 0.2, y: 4.95, w: colW - 0.4, h: 0.3, fontSize: 10, fontFace: FONT_BODY, color: i === 3 ? C.goldSoft : C.textMuted, charSpacing: 1 });
  s7.addText(p.milestone, { x: x + 0.2, y: 5.25, w: colW - 0.4, h: 1.1, fontSize: 11, fontFace: FONT_BODY, color: textColor, lineSpacingMultiple: 1.3 });
});

addFooter(s7, 7, T);

// ============ SLIDE 8: THE EXIT ============
const s8 = pres.addSlide();
addBg(s8);
s8.addText('Real exits in our category', {
  x: 0.6, y: 0.5, w: 12, h: 0.7,
  fontSize: 32, fontFace: FONT_DISPLAY, bold: true, color: C.ink, charSpacing: -0.5,
});
s8.addShape('rect', { x: 0.6, y: 1.25, w: 0.6, h: 0.04, fill: { color: C.gold }, line: { type: 'none' } });
s8.addText('These are not hypothetical. These are donut and adjacent QSR roll-ups that actually exited.', {
  x: 0.6, y: 1.4, w: 12, h: 0.4, fontSize: 13, fontFace: FONT_BODY, italic: true, color: C.textSoft,
});

const comps = [
  { name: 'Shipley Do-Nuts', context: 'Same market (DFW), same product (donuts)', exit: 'Peak Rock → Levine Leichtman 2025\n~2× their entry · 4-year hold · ~380 stores', match: 'Most direct model' },
  { name: 'Krispy Kreme', context: 'Donuts + hub-and-spoke supply (like us)', exit: 'JAB acquired 2016 → IPO 2021\n$1.35B → $3.8B in 5 years', match: 'Category benchmark' },
  { name: "Dave's Hot Chicken", context: 'QSR roll-up, similar timeline + pace', exit: '$22M in 2020 → Roark 2025\n8× revenue multiple', match: 'Pace benchmark' },
];

comps.forEach((c, i) => {
  const y = 2.0 + i * 1.55;
  s8.addShape('roundRect', { x: 0.6, y, w: 12.1, h: 1.35, fill: { color: C.white }, line: { color: C.border, pt: 1 }, rectRadius: 0.08 });
  s8.addText(c.name, { x: 0.85, y: y + 0.15, w: 3.5, h: 0.5, fontSize: 16, fontFace: FONT_DISPLAY, bold: true, color: C.ink });
  s8.addText(c.match, { x: 0.85, y: y + 0.65, w: 3.5, h: 0.3, fontSize: 10, fontFace: FONT_BODY, bold: true, color: C.goldDeep, charSpacing: 1 });
  s8.addText(c.context, { x: 4.5, y: y + 0.2, w: 4.0, h: 0.5, fontSize: 11.5, fontFace: FONT_BODY, italic: true, color: C.textSoft, lineSpacingMultiple: 1.3 });
  s8.addText(c.exit, { x: 8.7, y: y + 0.2, w: 3.85, h: 0.95, fontSize: 11.5, fontFace: FONT_BODY, color: C.text, lineSpacingMultiple: 1.3 });
});

s8.addShape('roundRect', { x: 0.6, y: 6.65, w: 12.1, h: 0.55, fill: { color: C.card }, line: { type: 'none' }, rectRadius: 0.08 });
s8.addText('Target exit: $80M-120M to PE in 4 years. Conservative against these comps.', {
  x: 0.85, y: 6.7, w: 11.6, h: 0.45, fontSize: 13, fontFace: FONT_BODY, bold: true, color: C.ink, align: 'center', valign: 'middle',
});

addFooter(s8, 8, T);

// ============ SLIDE 9: THE ASK ============
const s9 = pres.addSlide();
addBg(s9);
s9.addText('The ask, and what you get', {
  x: 0.6, y: 0.5, w: 12, h: 0.7,
  fontSize: 32, fontFace: FONT_DISPLAY, bold: true, color: C.ink, charSpacing: -0.5,
});
s9.addShape('rect', { x: 0.6, y: 1.25, w: 0.6, h: 0.04, fill: { color: C.gold }, line: { type: 'none' } });

// Big ask card
s9.addShape('roundRect', { x: 0.6, y: 1.65, w: 12.1, h: 1.8, fill: { color: C.ink }, line: { type: 'none' }, rectRadius: 0.1 });
s9.addText('SAFE INVESTMENT', { x: 0.85, y: 1.85, w: 11.6, h: 0.4, fontSize: 11, fontFace: FONT_BODY, bold: true, color: C.goldSoft, charSpacing: 3 });
s9.addText('$25K-$50K typical check size', { x: 0.85, y: 2.25, w: 11.6, h: 0.6, fontSize: 28, fontFace: FONT_DISPLAY, bold: true, color: C.cream });
s9.addText('Converts to equity at the Series A — no valuation negotiation today. You buy in early, you get the founder price.', {
  x: 0.85, y: 2.9, w: 11.6, h: 0.5, fontSize: 13, fontFace: FONT_BODY, italic: true, color: C.goldSoft, lineSpacingMultiple: 1.3,
});

// Terms
const terms = [
  { label: 'Valuation cap', value: '$2M post-money', sub: 'Generous — protects you on the upside' },
  { label: 'Discount', value: '20%', sub: 'Off the Series A price' },
  { label: 'MFN clause', value: 'Yes', sub: 'You get the best terms any SAFE investor gets' },
];

terms.forEach((t, i) => {
  const x = 0.6 + i * 4.1;
  s9.addShape('roundRect', { x, y: 3.7, w: 3.95, h: 1.6, fill: { color: C.white }, line: { color: C.border, pt: 1 }, rectRadius: 0.08 });
  s9.addText(t.label, { x: x + 0.2, y: 3.85, w: 3.55, h: 0.3, fontSize: 11, fontFace: FONT_BODY, bold: true, color: C.textMuted, charSpacing: 1 });
  s9.addText(t.value, { x: x + 0.2, y: 4.2, w: 3.55, h: 0.6, fontSize: 22, fontFace: FONT_MONO, bold: true, color: C.goldDeep, charSpacing: -1 });
  s9.addText(t.sub, { x: x + 0.2, y: 4.85, w: 3.55, h: 0.5, fontSize: 11, fontFace: FONT_BODY, italic: true, color: C.textSoft, lineSpacingMultiple: 1.3 });
});

// Math
s9.addShape('roundRect', { x: 0.6, y: 5.5, w: 12.1, h: 1.4, fill: { color: C.card }, line: { type: 'none' }, rectRadius: 0.08 });
s9.addText('What your check could become', { x: 0.85, y: 5.6, w: 11.6, h: 0.35, fontSize: 11, fontFace: FONT_BODY, bold: true, color: C.goldDeep, charSpacing: 2 });

const scenarios = [
  { check: '$25K', e80: '$800K', e120: '$1.2M' },
  { check: '$30K', e80: '$960K', e120: '$1.4M' },
  { check: '$50K', e80: '$1.6M', e120: '$2.4M' },
];
scenarios.forEach((sc, i) => {
  const x = 0.85 + i * 3.95;
  s9.addText(`${sc.check} →`, { x, y: 5.95, w: 1.2, h: 0.45, fontSize: 15, fontFace: FONT_MONO, bold: true, color: C.ink });
  s9.addText(`${sc.e80} at $80M exit`, { x: x + 1.2, y: 5.95, w: 2.6, h: 0.45, fontSize: 13, fontFace: FONT_BODY, color: C.text });
  s9.addText(`${sc.e120} at $120M exit`, { x: x + 1.2, y: 6.4, w: 2.6, h: 0.4, fontSize: 13, fontFace: FONT_BODY, bold: true, color: C.goldDeep });
});
s9.addText('Each scenario = ~32× MOIC at $80M · ~48× MOIC at $120M', { x: 0.85, y: 6.85, w: 11.6, h: 0.35, fontSize: 10, fontFace: FONT_BODY, italic: true, color: C.textMuted, align: 'center' });

addFooter(s9, 9, T);

// Speaker notes for slide 9 — small investor talk track
s9.addNotes(`SMALL SAFE INVESTOR TALK TRACK ($25-50K):

This is the simplest slide in the deck. You want to land three points:

1. "The ask is small enough to be a yes — $25-50K range, similar to what early friends-and-family investors have already put in across our seven shops."

2. "The structure is founder-friendly to you. SAFE means we are not negotiating valuation today on a business that is only six months old — you get the next institutional investor's price, with a generous cap that protects you if we do well."

3. "The math is on the slide. We are not selling you a dream — Shipley and Krispy Kreme actually exited at these multiples. If we hit $80M, your $30K becomes $960K. If we hit $120M, $1.4M. We think we get to $120M based on what we are seeing on the ground."

If they ask about risk: "What kills this is execution — we stretch ourselves too thin, an operator quits, integration fails. We are mitigating with our incoming Operations Manager Jonathan, and Muypin running daily ops full-time. The actual ground-level risk is operational, not strategic."

If they ask about timing: "We want to close this round in 60 days. Lawyers are engaged, SAFE template is standard YC form, you would sign electronically. The bigger question is: are you in conceptually?"`);

// ============ SLIDE 10: CLOSING ============
const s10 = pres.addSlide();
addBg(s10, C.ink);
s10.addShape('rect', { x: 0, y: 0, w: W, h: 0.4, fill: { color: C.gold }, line: { type: 'none' } });

s10.addText('What is left to figure out together.', {
  x: 0.8, y: 1.0, w: 12, h: 1.0,
  fontSize: 38, fontFace: FONT_DISPLAY, bold: true, color: C.cream, charSpacing: -0.5,
});

s10.addText(
  'You have seven shops generating $1.3M ARR run rate. You have four founders with the right backgrounds to take this from local to brand. You have comparable exits at 2-5× your target. You have generous SAFE terms because we are raising before the brand is built.',
  {
    x: 0.8, y: 2.3, w: 11.7, h: 1.5,
    fontSize: 15, fontFace: FONT_BODY, color: C.goldSoft, lineSpacingMultiple: 1.4, italic: true,
  }
);

s10.addShape('rect', { x: 0.8, y: 4.0, w: 0.8, h: 0.04, fill: { color: C.gold }, line: { type: 'none' } });

s10.addText('Next steps', {
  x: 0.8, y: 4.2, w: 12, h: 0.5,
  fontSize: 18, fontFace: FONT_BODY, bold: true, color: C.gold, charSpacing: 3,
});

const nextSteps = [
  { num: '1', text: 'You tell us you are in (conceptually).' },
  { num: '2', text: 'We send an accreditation questionnaire — a 5-minute form required by SEC rules.' },
  { num: '3', text: 'Lawyer sends the SAFE document. You review with your own counsel.' },
  { num: '4', text: 'You wire funds. We send you a signed countersigned SAFE. You are an investor.' },
];

nextSteps.forEach((s, i) => {
  const y = 4.85 + i * 0.45;
  s10.addShape('ellipse', { x: 0.85, y, w: 0.35, h: 0.35, fill: { color: C.gold }, line: { type: 'none' } });
  s10.addText(s.num, { x: 0.85, y, w: 0.35, h: 0.35, fontSize: 14, fontFace: FONT_MONO, bold: true, color: C.ink, align: 'center', valign: 'middle' });
  s10.addText(s.text, { x: 1.4, y, w: 11.5, h: 0.35, fontSize: 14, fontFace: FONT_BODY, color: C.cream, valign: 'middle' });
});

s10.addText('Jack: jack@goldenglazedonuts.com  ·  Youyou: youyou@goldenglazedonuts.com', {
  x: 0.8, y: 6.85, w: 12, h: 0.3,
  fontSize: 10, fontFace: FONT_MONO, color: C.goldSoft, charSpacing: 1,
});

pres.writeFile({ fileName: '/home/claude/gg-package/docs/02-Investor-Deck-Standard.pptx' })
  .then(() => console.log('✓ Standard investor deck built'));
